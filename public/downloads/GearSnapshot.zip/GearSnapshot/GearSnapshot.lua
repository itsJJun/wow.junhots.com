-- Gear Snapshot: writes what you wear to
-- WTF\Account\<account>\<server>\<character>\SavedVariables\GearSnapshot.lua
-- Also saves the recipes you know when you open a profession window, and (1.4) your class, race, faction,
-- spec (Forever Leveling BiS's choice, else talent points per tree) and learned weapon types.
-- The game writes that file on /reload, logout or exit. Read-only: it never
-- changes anything in the game.

-- Game stat keys -> the keys Forever Leveling BiS weights use.
local STATS = {
    ITEM_MOD_STRENGTH_SHORT = "str", ITEM_MOD_AGILITY_SHORT = "agi", ITEM_MOD_STAMINA_SHORT = "sta",
    ITEM_MOD_INTELLECT_SHORT = "int", ITEM_MOD_SPIRIT_SHORT = "spi", RESISTANCE0_NAME = "armor",
    ITEM_MOD_SPELL_POWER_SHORT = "splpwr", ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "spldmg",
    ITEM_MOD_SPELL_HEALING_DONE_SHORT = "splheal",
    ITEM_MOD_ARCANE_DAMAGE_DONE_SHORT = "arcsplpwr", ITEM_MOD_FIRE_DAMAGE_DONE_SHORT = "firsplpwr",
    ITEM_MOD_FROST_DAMAGE_DONE_SHORT = "frosplpwr", ITEM_MOD_HOLY_DAMAGE_DONE_SHORT = "holsplpwr",
    ITEM_MOD_NATURE_DAMAGE_DONE_SHORT = "natsplpwr", ITEM_MOD_SHADOW_DAMAGE_DONE_SHORT = "shasplpwr",
    ITEM_MOD_HASTE_RATING_SHORT = "hastertng", ITEM_MOD_MANA_REGENERATION_SHORT = "manargn",
    ITEM_MOD_POWER_REGEN0_SHORT = "manargn", ITEM_MOD_ATTACK_POWER_SHORT = "atkpwr",
    ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "rgdatkpwr", ITEM_MOD_FERAL_ATTACK_POWER_SHORT = "feratkpwr",
    ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "defrtng", ITEM_MOD_BLOCK_VALUE_SHORT = "block",
    ITEM_MOD_HEALTH_REGEN_SHORT = "healthrgn", ITEM_MOD_HEALTH_REGENERATION_SHORT = "healthrgn",
    ITEM_MOD_SPELL_PENETRATION_SHORT = "splpen", ITEM_MOD_EXPERTISE_RATING_SHORT = "exprtng",
}
-- Hit and crit are flat percentages on Forever; the game may report them as rating.
local PCT = { ITEM_MOD_HIT_RATING_SHORT = { "hitPct", 10 }, ITEM_MOD_CRIT_RATING_SHORT = { "critPct", 14 },
              ITEM_MOD_DODGE_RATING_SHORT = { "dodgePct", 12 }, ITEM_MOD_PARRY_RATING_SHORT = { "parryPct", 15 },
              ITEM_MOD_BLOCK_RATING_SHORT = { "blockPct", 5 } }
local SLOTS = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 } -- not shirt (4) or tabard (19)

local GetStats = (C_Item and C_Item.GetItemStats) or GetItemStats
local GetInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo

local function ReadItem(slot, old)
    local id = GetInventoryItemID("player", slot)
    if not id then return nil end
    local link = GetInventoryItemLink("player", slot)
    if old and old.id == id and old.link == link and old.stats then return old end
    local e = { id = id, link = link, name = link and link:match("|h%[(.-)%]|h") }
    local name, _, quality, _, reqLevel, _, _, _, equipLoc = GetInfo(link or id)
    e.name, e.q, e.rl, e.loc = e.name or name, quality, reqLevel, equipLoc
    local raw = GetStats and link and GetStats(link)
    if raw and next(raw) then
        local st = {}
        for k, v in pairs(raw) do
            if STATS[k] then st[STATS[k]] = v
            elseif PCT[k] then st[PCT[k][1]] = v / PCT[k][2] end
        end
        e.stats, e.dps = st, raw.ITEM_MOD_DAMAGE_PER_SECOND_SHORT
    end
    return e
end

local function Skills()
    local out = {}
    if not GetNumSkillLines then return out end
    for i = 1, GetNumSkillLines() do
        local name, header, _, rank = GetSkillLineInfo(i)
        if name and not header and rank then out[name] = rank end
    end
    return out
end

-- Auction prices per random suffix ("Thistlefur Cap of Shadow Wrath"). Auctionator and TSM keep one price
-- per base item, so this records the cheapest buyout and the count for each suffixed name the game shows
-- you: an Auctionator full scan (or any full scan), and the auctions listed when you click an item in the
-- auction house. Read-only: it only reads results the auction house already sent.
local AH
local function LinkName(link) return link and link:match("|h%[(.-)%]|h") end
local function Suffixed(name) return name and name:find(" of ", 1, true) end
local function Note(store, name, unit, count)
    if not (Suffixed(name) and unit and unit > 0) then return end
    local e = store[name]
    if not e then e = { p = unit, n = 0 }; store[name] = e end
    if unit < e.p then e.p = unit end
    e.n = e.n + (count or 1); e.t = time()
end
local function AHStore()
    GearSnapshotDB = GearSnapshotDB or {}
    GearSnapshotDB.ah = GearSnapshotDB.ah or { items = {} }
    return GearSnapshotDB.ah
end
-- full scan (modern auction house): every auction, in batches so the game doesn't stall
local function ReadReplicate()
    local CA = C_AuctionHouse
    if not (CA and CA.GetNumReplicateItems) then return end
    local total = CA.GetNumReplicateItems()
    if not total or total == 0 then return end
    local seen, missing, i = {}, {}, 0
    local function Batch()
        local stop = math.min(i + 2000, total)
        for k = i, stop - 1 do
            local ok, _, _, count, _, _, _, _, _, _, buyout, _, _, _, _, _, _, itemID = pcall(CA.GetReplicateItemInfo, k)
            if ok and buyout and buyout > 0 then
                local link = CA.GetReplicateItemLink and CA.GetReplicateItemLink(k)
                if link then Note(seen, LinkName(link), math.floor(buyout / math.max(count or 1, 1)), count)
                else missing[#missing + 1] = k end
            end
        end
        i = stop
        if i < total then C_Timer.After(0.05, Batch) return end
        -- items the game hadn't loaded yet: one more pass a few seconds later
        C_Timer.After(4, function()
            for _, k in ipairs(missing) do
                local ok, _, _, count, _, _, _, _, _, _, buyout = pcall(CA.GetReplicateItemInfo, k)
                local link = ok and CA.GetReplicateItemLink and CA.GetReplicateItemLink(k)
                if link and buyout and buyout > 0 then Note(seen, LinkName(link), math.floor(buyout / math.max(count or 1, 1)), count) end
            end
            local store = AHStore()
            store.items, store.full, store.auctions = seen, time(), total
            local n = 0; for _ in pairs(seen) do n = n + 1 end
            print("|cff66ccffGear Snapshot:|r saved suffix prices for " .. n .. " items from the full scan. /reload to write the file.")
        end)
    end
    Batch()
end
-- one item's auctions (when you click it in the browse list): each listing has its own suffix
local function ReadItemSearch(itemKey)
    local CA = C_AuctionHouse
    if not (CA and CA.GetNumItemSearchResults and itemKey) then return end
    local n = CA.GetNumItemSearchResults(itemKey) or 0
    if n == 0 then return end
    local fresh = {}
    for k = 1, n do
        local r = CA.GetItemSearchResultInfo(itemKey, k)
        if r and r.itemLink and r.buyoutAmount then Note(fresh, LinkName(r.itemLink), r.buyoutAmount, r.quantity or 1) end
    end
    local items = AHStore().items
    for name, e in pairs(fresh) do items[name] = e end
end
-- old-style auction house list (and its "get all" scan)
local function ReadLegacy()
    if not (GetNumAuctionItems and GetAuctionItemInfo) then return end
    local n, total = GetNumAuctionItems("list")
    if not n or n == 0 then return end
    local fresh = {}
    for k = 1, n do
        local _, _, count, _, _, _, _, _, _, buyout = GetAuctionItemInfo("list", k)
        local link = GetAuctionItemLink and GetAuctionItemLink("list", k)
        if link and buyout and buyout > 0 then Note(fresh, LinkName(link), math.floor(buyout / math.max(count or 1, 1)), count) end
    end
    local store = AHStore()
    if total and n == total and n > 1000 then store.items, store.full, store.auctions = fresh, time(), n -- a full "get all" scan
    else for name, e in pairs(fresh) do store.items[name] = e end end
end


-- Known recipes: read when you open a profession window (Enchanting, Tailoring, ...), saved per profession as
-- recipes[<profession>] = { rank, max, t, known = { [spellID or name] = name } }. Read-only.
local function RecStore()
    GearSnapshotDB = GearSnapshotDB or {}
    GearSnapshotDB.recipes = GearSnapshotDB.recipes or {}
    return GearSnapshotDB.recipes
end
local function SpellFromLink(link)
    if not link then return nil end
    return tonumber(link:match("|H%a+:(%d+)"))
end
-- Recipes are never unlearned, so a list is merged into what was saved before: a half-loaded window or a
-- search/filter in it can't shrink the saved list.
local announce = {}
local function SaveList(prof, rank, max, list)
    if not prof or prof == "" or prof == "UNKNOWN" or not next(list) then return end
    local store = RecStore()
    local old = store[prof]
    if old and old.known then for k, v in pairs(old.known) do if list[k] == nil then list[k] = v end end end
    local n = 0; for _ in pairs(list) do n = n + 1 end
    store[prof] = { rank = rank, max = max, t = time(), known = list, n = n }
    local key = prof .. ":" .. tostring(rank) .. ":" .. n
    if announce[prof] ~= key then
        announce[prof] = key
        print("|cff66ccffGear Snapshot:|r " .. prof .. " " .. tostring(rank or "?") .. (max and ("/" .. max) or "") .. ", " .. n .. " recipes saved. /reload to write the file.")
    end
end
-- classic trade skill window (Tailoring, ...; on some clients Enchanting too)
local function ReadTradeSkills()
    if not (GetNumTradeSkills and GetTradeSkillInfo) then return end
    local prof, rank, max = GetTradeSkillLine()
    local list = {}
    for i = 1, GetNumTradeSkills() do
        local name, kind = GetTradeSkillInfo(i)
        if name and kind ~= "header" and kind ~= "subheader" then
            local id = GetTradeSkillRecipeLink and SpellFromLink(GetTradeSkillRecipeLink(i))
            list[id or name] = name
        end
    end
    SaveList(prof, rank, max, list)
end
-- classic craft window (Enchanting)
local function ReadCrafts()
    if not (GetNumCrafts and GetCraftInfo) then return end
    local prof, rank, max
    if GetCraftDisplaySkillLine then prof, rank, max = GetCraftDisplaySkillLine() end
    if (not prof) and GetCraftName then prof = GetCraftName() end
    local list = {}
    for i = 1, GetNumCrafts() do
        local name, _, kind = GetCraftInfo(i)
        if name and kind ~= "header" then
            local link = (GetCraftRecipeLink and GetCraftRecipeLink(i)) or (GetCraftItemLink and GetCraftItemLink(i))
            local id = link and link:find("|Henchant:") and SpellFromLink(link) or nil
            list[id or name] = name
        end
    end
    SaveList(prof, rank, max, list)
end
-- modern profession window
local function ReadModern()
    local T = C_TradeSkillUI
    if not (T and T.GetAllRecipeIDs and T.GetRecipeInfo) then return end
    local prof, rank, max
    if T.GetBaseProfessionInfo then local i = T.GetBaseProfessionInfo(); if i then prof, rank, max = i.professionName, i.skillLevel, i.maxSkillLevel end end
    if (not prof) and T.GetTradeSkillLine then local _, n, r, m = T.GetTradeSkillLine(); prof, rank, max = n, r, m end
    local list = {}
    for _, id in ipairs(T.GetAllRecipeIDs() or {}) do
        local r = T.GetRecipeInfo(id)
        if r and r.learned then list[id] = r.name end
    end
    SaveList(prof, rank, max, list)
end
local function ReadRecipes(ev)
    if ev == "CRAFT_SHOW" or ev == "CRAFT_UPDATE" then pcall(ReadCrafts) return end
    pcall(ReadTradeSkills)
    pcall(ReadModern)
end

-- Spec: the one picked in Forever Leveling BiS (Forever has no API for the talent spec), else talent points per tree.
local function BisSpec()
    local db = ForeverLevelingBiSDB
    if type(db) ~= "table" or type(db.chars) ~= "table" then return nil end
    local realm = GetRealmName()
    local full = (GetUnitName and GetUnitName("player", true)) or UnitName("player")
    local c = db.chars[full .. "-" .. realm] or db.chars[UnitName("player") .. "-" .. realm]
    return c and type(c.spec) == "string" and c.spec or nil
end
local function Talents()
    if not (GetNumTalentTabs and GetNumTalents and GetTalentInfo) then return nil end
    local out, any = {}, false
    for tab = 1, GetNumTalentTabs() or 0 do
        local pts = 0
        for i = 1, GetNumTalents(tab) or 0 do
            local rank = select(5, GetTalentInfo(tab, i))
            pts = pts + (tonumber(rank) or 0)
        end
        local name = GetTalentTabInfo and select(1, GetTalentTabInfo(tab))
        out[tab] = { points = pts, name = type(name) == "string" and name or nil }
        if pts > 0 then any = true end
    end
    return any and out or nil
end
-- Weapon types the character has learned (item subclass -> the spell that teaches it), as Forever Leveling BiS reads them.
local WEAPON_SKILL_SPELLS = { [0] = 196, [1] = 197, [2] = 264, [3] = 266, [4] = 198, [5] = 199, [6] = 200, [7] = 201, [8] = 202,
    [10] = 227, [13] = 15590, [15] = 1180, [16] = 2567, [18] = 5011, [19] = 5009 }
local function WeaponSkills()
    local Known = IsPlayerSpell or (C_SpellBook and C_SpellBook.IsSpellKnown) or IsSpellKnown
    if not Known then return nil end
    local out
    for sub, spell in pairs(WEAPON_SKILL_SPELLS) do
        local ok, known = pcall(Known, spell)
        if ok and known then out = out or {}; out[sub] = true end
    end
    return out
end

local function Snapshot()
    local old = GearSnapshotDB and GearSnapshotDB.gear or {}
    local db = {
        version = 3, name = UnitName("player"), realm = GetRealmName(),
        class = select(2, UnitClass("player")), level = UnitLevel("player"),
        race = select(2, UnitRace("player")), raceId = select(3, UnitRace("player")), faction = UnitFactionGroup("player"),
        money = GetMoney(), skills = Skills(), time = time(), date = date("%Y-%m-%d %H:%M"), gear = {},
        ah = GearSnapshotDB and GearSnapshotDB.ah or nil,
        recipes = GearSnapshotDB and GearSnapshotDB.recipes or nil,
    }
    for _, s in ipairs(SLOTS) do db.gear[s] = ReadItem(s, old[s]) end
    local ok, v = pcall(BisSpec); if ok then db.spec = v end
    -- Forever Leveling BiS version, so the Gear Upgrades page can warn when its item data is older than the addon
    ok, v = pcall(function()
        local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
        return get and get("ForeverLevelingBiS", "Version")
    end)
    if ok and v then db.bis = v end
    ok, v = pcall(Talents); if ok then db.talents = v end
    ok, v = pcall(WeaponSkills); if ok then db.wskills = v end
    GearSnapshotDB = db
end

local f = CreateFrame("Frame")
for _, ev in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_EQUIPMENT_CHANGED", "PLAYER_LEVEL_UP", "SKILL_LINES_CHANGED", "PLAYER_LOGOUT",
                      "REPLICATE_ITEM_LIST_UPDATE", "ITEM_SEARCH_RESULTS_UPDATED", "AUCTION_ITEM_LIST_UPDATE",
                      "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_UPDATE", "CRAFT_SHOW", "CRAFT_UPDATE" }) do
    pcall(f.RegisterEvent, f, ev) -- (an event this client doesn't have is skipped)
end
f:SetScript("OnEvent", function(_, ev, arg1)
    if ev == "REPLICATE_ITEM_LIST_UPDATE" then ReadReplicate()
    elseif ev == "ITEM_SEARCH_RESULTS_UPDATED" then pcall(ReadItemSearch, arg1)
    elseif ev == "AUCTION_ITEM_LIST_UPDATE" then pcall(ReadLegacy)
    elseif ev:find("^TRADE_SKILL") or ev:find("^CRAFT") then
        if ev == "TRADE_SKILL_SHOW" or ev == "CRAFT_SHOW" then wipe(announce) end -- say it again each time a window opens
        if f.recTimer then f.recTimer:Cancel() end -- wait until the list stops changing, then read it once
        local kind = ev:find("^CRAFT") and "CRAFT_SHOW" or "TRADE_SKILL_SHOW"
        f.recTimer = C_Timer.NewTimer(1, function() f.recTimer = nil; ReadRecipes(kind) end)
    elseif ev == "PLAYER_ENTERING_WORLD" then C_Timer.After(3, Snapshot)
    else Snapshot() end
end)

SLASH_GEARSNAPSHOT1 = "/gearsnap"
SlashCmdList.GEARSNAPSHOT = function()
    Snapshot()
    local n, p = 0, 0
    for _ in pairs(GearSnapshotDB.gear) do n = n + 1 end
    for _ in pairs(GearSnapshotDB.ah and GearSnapshotDB.ah.items or {}) do p = p + 1 end
    print("|cff66ccffGear Snapshot:|r saved " .. n .. " items, level " .. GearSnapshotDB.level .. " " .. tostring(GearSnapshotDB.class) .. (GearSnapshotDB.spec and (" (" .. GearSnapshotDB.spec .. ")") or "") .. ", suffix prices for " .. p .. " items. Recipes: " .. (function() local t = {}; for k, v in pairs(GearSnapshotDB.recipes or {}) do t[#t + 1] = k .. " " .. (v.n or 0) end; return #t > 0 and table.concat(t, ", ") or "open a profession window first" end)() .. ". Type /reload to write the file.")
end
