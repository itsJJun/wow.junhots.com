-- Gear Snapshot: writes what you wear to
-- WTF\Account\<account>\<server>\<character>\SavedVariables\GearSnapshot.lua
-- Also saves the recipes you know when you open a profession window, and (1.4) your class, race, faction,
-- spec (Forever Leveling BiS's choice, else talent points per tree) and learned weapon types.
-- (1.7) Also your bags, bank and mailbox (all your characters), for "I have" on the profession pages.
-- (1.6) Also your quests: every quest the game counts as finished, and your quest log, plus where you stand
-- and your hearthstone, for the Level route.
-- The game writes that file on /reload, logout or exit. Read-only: it never
-- changes anything in the game.

-- Game stat keys -> the keys Forever Leveling BiS weights use.
local STATS = {
    ITEM_MOD_STRENGTH_SHORT = "str", ITEM_MOD_AGILITY_SHORT = "agi", ITEM_MOD_STAMINA_SHORT = "sta",
    ITEM_MOD_INTELLECT_SHORT = "int", ITEM_MOD_SPIRIT_SHORT = "spi", RESISTANCE0_NAME = "armor",
    ITEM_MOD_SPELL_POWER_SHORT = "splpwr", ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "spldmg",
    ITEM_MOD_SPELL_HEALING_DONE_SHORT = "splheal",
    ITEM_MOD_ARCANE_DAMAGE_DONE_SHORT = "arcsplpwr", ITEM_MOD_FIRE_DAMAGE_DONE_SHORT = "firsplpwr",
    ITEM_MOD_FROST_DAMAGE_DONE_SHORT = "frosplpwr", ITEM_MOD_HOLY_DAMAGE_DONE_SHORT = "holsplpwr",
    ITEM_MOD_NATURE_DAMAGE_DONE_SHORT = "natsplpwr", ITEM_MOD_SHADOW_DAMAGE_DONE_SHORT = "shasplpwr",
    ITEM_MOD_HASTE_RATING_SHORT = "hastertng", ITEM_MOD_MANA_REGENERATION_SHORT = "manargn",
    ITEM_MOD_POWER_REGEN0_SHORT = "manargn", ITEM_MOD_ATTACK_POWER_SHORT = "atkpwr",
    ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "rgdatkpwr", ITEM_MOD_FERAL_ATTACK_POWER_SHORT = "feratkpwr",
    ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "defrtng", ITEM_MOD_BLOCK_VALUE_SHORT = "block",
    ITEM_MOD_HEALTH_REGEN_SHORT = "healthrgn", ITEM_MOD_HEALTH_REGENERATION_SHORT = "healthrgn",
    ITEM_MOD_SPELL_PENETRATION_SHORT = "splpen", ITEM_MOD_EXPERTISE_RATING_SHORT = "exprtng",
}
-- Hit and crit are flat percentages on Forever; the game may report them as rating.
local PCT = { ITEM_MOD_HIT_RATING_SHORT = { "hitPct", 10 }, ITEM_MOD_CRIT_RATING_SHORT = { "critPct", 14 },
              ITEM_MOD_DODGE_RATING_SHORT = { "dodgePct", 12 }, ITEM_MOD_PARRY_RATING_SHORT = { "parryPct", 15 },
              ITEM_MOD_BLOCK_RATING_SHORT = { "blockPct", 5 } }
local SLOTS = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 } -- not shirt (4) or tabard (19)

local GetStats = (C_Item and C_Item.GetItemStats) or GetItemStats
local GetInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo

local function ReadItem(slot, old)
    local id = GetInventoryItemID("player", slot)
    if not id then return nil end
    local link = GetInventoryItemLink("player", slot)
    if old and old.id == id and old.link == link and old.stats then return old end
    local e = { id = id, link = link, name = link and link:match("|h%[(.-)%]|h") }
    local name, _, quality, _, reqLevel, _, _, _, equipLoc = GetInfo(link or id)
    e.name, e.q, e.rl, e.loc = e.name or name, quality, reqLevel, equipLoc
    local raw = GetStats and link and GetStats(link)
    if raw and next(raw) then
        local st = {}
        for k, v in pairs(raw) do
            if STATS[k] then st[STATS[k]] = v
            elseif PCT[k] then st[PCT[k][1]] = v / PCT[k][2] end
        end
        e.stats, e.dps = st, raw.ITEM_MOD_DAMAGE_PER_SECOND_SHORT
    end
    return e
end

local function Skills()
    local out = {}
    if not GetNumSkillLines then return out end
    for i = 1, GetNumSkillLines() do
        local name, header, _, rank = GetSkillLineInfo(i)
        if name and not header and rank then out[name] = rank end
    end
    return out
end

-- Auction prices per random suffix ("Thistlefur Cap of Shadow Wrath"): the cheapest buyout and the count for
-- each suffixed name the game shows you: a full scan (below), and the auctions listed when you click an item.
local AH
local function LinkName(link) return link and link:match("|h%[(.-)%]|h") end
local function Suffixed(name) return name and name:find(" of ", 1, true) end
local function Note(store, name, unit, count)
    if not (Suffixed(name) and unit and unit > 0) then return end
    local e = store[name]
    if not e then e = { p = unit, n = 0 }; store[name] = e end
    if unit < e.p then e.p = unit end
    e.n = e.n + (count or 1); e.t = time()
end
local function AHStore()
    GearSnapshotDB = GearSnapshotDB or {}
    GearSnapshotDB.ah = GearSnapshotDB.ah or { items = {} }
    return GearSnapshotDB.ah
end
-- (1.8) Prices from the auction house's browse list: one row per item, and per random suffix, with the
-- cheapest buyout and how many are listed. Any scan that pages through the whole list fills it: Auctionator's
-- "Full Scan" (summary) or Gear Snapshot's own Scan button. A smaller search only updates the items it shows.
-- Saved account-wide per auction house (your faction's, or the neutral one at Booty Bay, Gadgetzan, Everlook).
local SUFFIX = { -- the game's suffix names by id (ItemNameDescription), "of ..."
    [14296]="Intellect", [14297]="Spirit", [14298]="Stamina", [14299]="the Owl", [14300]="the Eagle", [14301]="the Whale", [14302]="the Bear", [14303]="the Gorilla", [14304]="the Falcon", [14305]="the Boar", [14306]="the Wolf", [14307]="the Tiger", [14308]="Agility", [14309]="Intellect", [14310]="Spirit", [14311]="Stamina", [14312]="Strength", [14313]="Power", [14314]="Magic", [14315]="Healing", [14316]="Defense", [14317]="Regeneration", [14318]="Concentration", [14319]="Eluding", [14320]="Arcane Protection", [14321]="Fire Protection", [14322]="Frost Protection", [14323]="Nature Protection", [14324]="Shadow Protection", [14325]="the Sorcerer", [14326]="the Elder", [14327]="the Channeler", [14328]="the Physician", [14329]="the Hierophant", [14330]="the Bandit", [14331]="the Beast", [14332]="the Champion", [14333]="the Defender", [14334]="the Knight", [14335]="Arcane Wrath", [14336]="Fiery Wrath", [14337]="Frozen Wrath", [14338]="Holy Wrath", [14339]="Nature's Wrath", [14340]="Shadow Wrath", [14344]="Arcane Resistance", [14345]="Fire Resistance", [14346]="Frost Resistance", [14347]="Nature Resistance", [14348]="Shadow Resistance", [14455]="the Monkey", [14473]="the Prophet" }
local NEUTRAL_MAPS = { [1434] = true, [1446] = true, [1452] = true } -- Stranglethorn Vale, Tanaris, Winterspring
local statusFrame
local function Status(text, hideAfter)
    if not CreateFrame then return end
    if not statusFrame then
        statusFrame = CreateFrame("Frame", nil, UIParent)
        statusFrame:SetSize(900, 24); statusFrame:SetFrameStrata("DIALOG")
        statusFrame.text = statusFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        statusFrame.text:SetAllPoints()
    end
    statusFrame:ClearAllPoints()
    if AuctionHouseFrame and AuctionHouseFrame:IsShown() then statusFrame:SetPoint("BOTTOM", AuctionHouseFrame, "TOP", 0, 28) -- (above the Scan button)
    else statusFrame:SetPoint("TOP", UIParent, "TOP", 0, -120) end
    statusFrame.text:SetText("|cff66ccffGear Snapshot:|r " .. text)
    statusFrame:Show()
    if statusFrame.timer then statusFrame.timer:Cancel(); statusFrame.timer = nil end
    if hideAfter then statusFrame.timer = C_Timer.NewTimer(hideAfter, function() statusFrame:Hide() end) end
end
local house -- which auction house is open (set when it opens)
local function HouseStore()
    GearSnapshotBags = GearSnapshotBags or {}
    GearSnapshotBags.ah = GearSnapshotBags.ah or {}
    GearSnapshotBags.ahDebug = nil -- (left by the 1.8 test builds)
    local key = house or UnitFactionGroup("player") or "?"
    local h = GearSnapshotBags.ah[key] or { p = {}, s = {}, hist = {} }
    GearSnapshotBags.ah[key] = h
    return h
end
local scan -- the scan being read: { full = paging through everything, mine = Gear Snapshot asked for it, p, s, rows }
local function NewScan(full, mine) scan = { full = full, mine = mine, p = {}, s = {}, rows = 0, pages = 0, start = time() } end
local function AddRows(rows)
    if not scan then NewScan(false, false) end
    scan.pages = scan.pages + 1
    for _, r in ipairs(rows or {}) do
        local k, price, n = r.itemKey, r.minPrice, r.totalQuantity
        if k and k.itemID and price and price > 0 and n and n > 0 then
            scan.rows = scan.rows + 1
            local id = k.itemID
            local e = scan.p[id]
            if not e then scan.p[id] = { price, n } else
                if price < e[1] then e[1] = price end
                e[2] = e[2] + n
            end
            local suf = k.itemSuffix and k.itemSuffix ~= 0 and SUFFIX[k.itemSuffix]
            if suf then
                scan.s[id] = scan.s[id] or {}
                local x = scan.s[id][suf]
                if not x then scan.s[id][suf] = { price, n } else
                    if price < x[1] then x[1] = price end
                    x[2] = x[2] + n
                end
            end
        end
    end
end
-- suffix prices also go to this character's file by full name ("Cloak of the Owl"), as before 1.8
local fullScans = 0
local function SaveNames(s, t, gen, tries)
    local store = AHStore()
    if gen ~= fullScans then return end -- a newer full scan replaced these
    local items = store.items
    local missing = false
    local nameOf = (C_Item and C_Item.GetItemNameByID) or function(id) return (GetItemInfo(id)) end
    for id, bySuf in pairs(s) do
        local base = nameOf(id)
        if base then
            for suf, x in pairs(bySuf) do items[base .. " of " .. suf] = { p = x[1], n = x[2], t = t } end
        else
            missing = true
            if C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
        end
    end
    -- names the game hadn't loaded yet: try again a little later
    if missing and (tries or 0) < 3 then C_Timer.After(2, function() SaveNames(s, t, gen, (tries or 0) + 1) end) end
end
local function FinishScan()
    local sc = scan; scan = nil
    if not sc or sc.rows == 0 then return end
    local h, t = HouseStore(), time()
    if sc.full then
        h.p, h.s, h.t, h.rows = sc.p, sc.s, t, sc.rows -- a full scan: anything not in it is not on sale now
        local day = math.floor(t / 86400)
        for id, e in pairs(sc.p) do
            local d = h.hist[id] or {}; h.hist[id] = d
            if not d[day] or e[1] < d[day] then d[day] = e[1] end
        end
        for id, d in pairs(h.hist) do -- keep 14 days
            local any = false
            for k in pairs(d) do if k <= day - 14 then d[k] = nil else any = true end end
            if not any then h.hist[id] = nil end
        end
    else
        for id, e in pairs(sc.p) do h.p[id] = e end -- a smaller search: update what it showed
        for id, x in pairs(sc.s) do h.s[id] = x end
        h.seen = t
    end
    h.map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player") or h.map
    h.zone = GetZoneText and GetZoneText() or h.zone
    -- copy every suffix name into this character's file too, for your own faction's auction house
    -- (a full scan replaces the old list)
    if house ~= "Neutral" then
        local store = AHStore()
        if sc.full then store.items, store.full = {}, t; fullScans = fullScans + 1 end
        pcall(SaveNames, sc.s, t, fullScans)
    end
    if sc.full then
        local n = 0; for _ in pairs(sc.p) do n = n + 1 end
        Status(("100%% done: prices for %d items saved. Type /reload to write the file."):format(n), 20)
        print(("|cff66ccffGear Snapshot:|r full scan done, prices for %d items (%s auction house). /reload to write the file."):format(n, house or "?"))
    end
end
local function ScanProgress()
    if not (scan and scan.full) then return end
    if not scan.mine and scan.pages < 2 then return end -- (an empty search nobody pages through is not a scan)
    local last = HouseStore().rows
    if last and last > 0 then
        Status(("scanning %d%%  (%d items)"):format(math.min(99, math.floor(scan.rows * 100 / last)), scan.rows))
    else
        Status(("scanning: %d items so far"):format(scan.rows))
    end
end
local function OnBrowse(ev, added)
    local CA = C_AuctionHouse
    if ev == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" then
        -- the first page of a new list. (It also fires when prices on the list shown change: during a full
        -- scan that is the list being read, so skip it.)
        if scan and scan.full and scan.rows > 0 then return end
        if not scan then NewScan(false, false) end
        AddRows(CA.GetBrowseResults() or {})
    else
        AddRows(added)
    end
    if not scan.full then FinishScan() return end -- a normal search: save what it showed
    ScanProgress()
    if CA.HasFullBrowseResults and CA.HasFullBrowseResults() then FinishScan()
    elseif scan.mine then CA.RequestMoreBrowseResults() end -- our own scan: ask for the next page
end
local function EmptyQuery(q)
    return q and (q.searchString or "") == "" and not (q.filters and #q.filters > 0) and not (q.itemClassFilters and #q.itemClassFilters > 0)
end
local hooked = false
local function HookBrowse()
    if hooked or not (C_AuctionHouse and C_AuctionHouse.SendBrowseQuery and hooksecurefunc) then return end
    hooked = true
    -- see every browse search, whoever sends it: an empty search pages through the whole auction house
    hooksecurefunc(C_AuctionHouse, "SendBrowseQuery", function(q)
        if scan and scan.mine and not scan.sent then scan.sent = true return end -- our own scan's query
        if scan and scan.full and (scan.mine or scan.pages >= 2) then Status("scan stopped: another search started.", 15) end
        NewScan(EmptyQuery(q), false)
    end)
end
local function StartScan()
    local CA = C_AuctionHouse
    if not (CA and CA.SendBrowseQuery) then print("|cff66ccffGear Snapshot:|r this game has no browse scan.") return end
    if not (AuctionHouseFrame and AuctionHouseFrame:IsShown()) then print("|cff66ccffGear Snapshot:|r open the auction house first.") return end
    if scan and scan.full then print("|cff66ccffGear Snapshot:|r a scan is already running.") return end
    HookBrowse()
    NewScan(true, true)
    Status("scanning...")
    CA.SendBrowseQuery({ searchString = "", sorts = {}, filters = {}, itemClassFilters = {} })
end
local scanButton
local function AddScanButton()
    if scanButton or not (AuctionHouseFrame and CreateFrame) then return end
    scanButton = CreateFrame("Button", nil, AuctionHouseFrame, "UIPanelButtonTemplate")
    scanButton:SetSize(150, 22)
    scanButton:SetPoint("BOTTOMRIGHT", AuctionHouseFrame, "TOPRIGHT", 0, 2) -- just above the window, out of other addons' way
    scanButton:SetFrameStrata("HIGH")
    scanButton:SetText("Gear Snapshot scan")
    scanButton:SetScript("OnClick", StartScan)
end
-- one item's auctions (when you click it in the browse list): each listing has its own suffix
local function ReadItemSearch(itemKey)
    local CA = C_AuctionHouse
    if not (CA and CA.GetNumItemSearchResults and itemKey) then return end
    local n = CA.GetNumItemSearchResults(itemKey) or 0
    if n == 0 then return end
    local fresh = {}
    for k = 1, n do
        local r = CA.GetItemSearchResultInfo(itemKey, k)
        if r and r.itemLink and r.buyoutAmount then Note(fresh, LinkName(r.itemLink), r.buyoutAmount, r.quantity or 1) end
    end
    local items = AHStore().items
    for name, e in pairs(fresh) do items[name] = e end
end
-- old-style auction house list (and its "get all" scan)
local function ReadLegacy()
    if not (GetNumAuctionItems and GetAuctionItemInfo) then return end
    local n, total = GetNumAuctionItems("list")
    if not n or n == 0 then return end
    local fresh = {}
    for k = 1, n do
        local _, _, count, _, _, _, _, _, _, buyout = GetAuctionItemInfo("list", k)
        local link = GetAuctionItemLink and GetAuctionItemLink("list", k)
        if link and buyout and buyout > 0 then Note(fresh, LinkName(link), math.floor(buyout / math.max(count or 1, 1)), count) end
    end
    local store = AHStore()
    if total and n == total and n > 1000 then store.items, store.full, store.auctions = fresh, time(), n -- a full "get all" scan
    else for name, e in pairs(fresh) do store.items[name] = e end end
end


-- Known recipes: read when you open a profession window (Enchanting, Tailoring, ...), saved per profession as
-- recipes[<profession>] = { rank, max, t, known = { [spellID or name] = name } }. Read-only.
local function RecStore()
    GearSnapshotDB = GearSnapshotDB or {}
    GearSnapshotDB.recipes = GearSnapshotDB.recipes or {}
    return GearSnapshotDB.recipes
end
local function SpellFromLink(link)
    if not link then return nil end
    return tonumber(link:match("|H%a+:(%d+)"))
end
-- Recipes are never unlearned, so a list is merged into what was saved before: a half-loaded window or a
-- search/filter in it can't shrink the saved list.
local announce = {}
local function SaveList(prof, rank, max, list)
    if not prof or prof == "" or prof == "UNKNOWN" or not next(list) then return end
    local store = RecStore()
    local old = store[prof]
    if old and old.known then for k, v in pairs(old.known) do if list[k] == nil then list[k] = v end end end
    local n = 0; for _ in pairs(list) do n = n + 1 end
    store[prof] = { rank = rank, max = max, t = time(), known = list, n = n }
    local key = prof .. ":" .. tostring(rank) .. ":" .. n
    if announce[prof] ~= key then
        announce[prof] = key
        print("|cff66ccffGear Snapshot:|r " .. prof .. " " .. tostring(rank or "?") .. (max and ("/" .. max) or "") .. ", " .. n .. " recipes saved. /reload to write the file.")
    end
end
-- classic trade skill window (Tailoring, ...; on some clients Enchanting too)
local function ReadTradeSkills()
    if not (GetNumTradeSkills and GetTradeSkillInfo) then return end
    local prof, rank, max = GetTradeSkillLine()
    local list = {}
    for i = 1, GetNumTradeSkills() do
        local name, kind = GetTradeSkillInfo(i)
        if name and kind ~= "header" and kind ~= "subheader" then
            local id = GetTradeSkillRecipeLink and SpellFromLink(GetTradeSkillRecipeLink(i))
            list[id or name] = name
        end
    end
    SaveList(prof, rank, max, list)
end
-- classic craft window (Enchanting)
local function ReadCrafts()
    if not (GetNumCrafts and GetCraftInfo) then return end
    local prof, rank, max
    if GetCraftDisplaySkillLine then prof, rank, max = GetCraftDisplaySkillLine() end
    if (not prof) and GetCraftName then prof = GetCraftName() end
    local list = {}
    for i = 1, GetNumCrafts() do
        local name, _, kind = GetCraftInfo(i)
        if name and kind ~= "header" then
            local link = (GetCraftRecipeLink and GetCraftRecipeLink(i)) or (GetCraftItemLink and GetCraftItemLink(i))
            local id = link and link:find("|Henchant:") and SpellFromLink(link) or nil
            list[id or name] = name
        end
    end
    SaveList(prof, rank, max, list)
end
-- modern profession window
local function ReadModern()
    local T = C_TradeSkillUI
    if not (T and T.GetAllRecipeIDs and T.GetRecipeInfo) then return end
    local prof, rank, max
    if T.GetBaseProfessionInfo then local i = T.GetBaseProfessionInfo(); if i then prof, rank, max = i.professionName, i.skillLevel, i.maxSkillLevel end end
    if (not prof) and T.GetTradeSkillLine then local _, n, r, m = T.GetTradeSkillLine(); prof, rank, max = n, r, m end
    local list = {}
    for _, id in ipairs(T.GetAllRecipeIDs() or {}) do
        local r = T.GetRecipeInfo(id)
        if r and r.learned then list[id] = r.name end
    end
    SaveList(prof, rank, max, list)
end
local function ReadRecipes(ev)
    if ev == "CRAFT_SHOW" or ev == "CRAFT_UPDATE" then pcall(ReadCrafts) return end
    pcall(ReadTradeSkills)
    pcall(ReadModern)
end

-- Spec: the one picked in Forever Leveling BiS (Forever has no API for the talent spec), else talent points per tree.
local function BisSpec()
    local db = ForeverLevelingBiSDB
    if type(db) ~= "table" or type(db.chars) ~= "table" then return nil end
    local realm = GetRealmName()
    local full = (GetUnitName and GetUnitName("player", true)) or UnitName("player")
    local c = db.chars[full .. "-" .. realm] or db.chars[UnitName("player") .. "-" .. realm]
    return c and type(c.spec) == "string" and c.spec or nil
end
local function Talents()
    if not (GetNumTalentTabs and GetNumTalents and GetTalentInfo) then return nil end
    local out, any = {}, false
    for tab = 1, GetNumTalentTabs() or 0 do
        local pts = 0
        for i = 1, GetNumTalents(tab) or 0 do
            local rank = select(5, GetTalentInfo(tab, i))
            pts = pts + (tonumber(rank) or 0)
        end
        local name = GetTalentTabInfo and select(1, GetTalentTabInfo(tab))
        out[tab] = { points = pts, name = type(name) == "string" and name or nil }
        if pts > 0 then any = true end
    end
    return any and out or nil
end
-- Weapon types the character has learned (item subclass -> the spell that teaches it), as Forever Leveling BiS reads them.
local WEAPON_SKILL_SPELLS = { [0] = 196, [1] = 197, [2] = 264, [3] = 266, [4] = 198, [5] = 199, [6] = 200, [7] = 201, [8] = 202,
    [10] = 227, [13] = 15590, [15] = 1180, [16] = 2567, [18] = 5011, [19] = 5009 }
local function WeaponSkills()
    local Known = IsPlayerSpell or (C_SpellBook and C_SpellBook.IsSpellKnown) or IsSpellKnown
    if not Known then return nil end
    local out
    for sub, spell in pairs(WEAPON_SKILL_SPELLS) do
        local ok, known = pcall(Known, spell)
        if ok and known then out = out or {}; out[sub] = true end
    end
    return out
end


-- (1.6) Quests, for the Level route page: every quest the game counts as finished, and your quest log
-- (which quests you hold, which are ready to turn in, and progress such as 6/10). Read while you play,
-- not at logout: during loading screens and logout the game answers an empty quest log.
-- (1.8) Flight points this character knows: read when you open a flight master's map. A point counts when the map
-- shows it as where you are or as somewhere you can fly (on this client a point you haven't found is "DISTANT").
-- Saved by the game's node id with its name, and never forgotten (you can't unlearn a flight point).
local function ReadFlights()
    if not (C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and GetTaxiMapID and TaxiNodeGetType) then return end
    local map = GetTaxiMapID()
    if not map then return end
    GearSnapshotDB = GearSnapshotDB or {}
    local fl = GearSnapshotDB.flights or {}
    local n = 0
    for _, node in ipairs(C_TaxiMap.GetAllTaxiNodes(map) or {}) do
        local kind = node.slotIndex and TaxiNodeGetType(node.slotIndex)
        if node.nodeID and (kind == "CURRENT" or kind == "REACHABLE") then
            fl[node.nodeID] = (TaxiNodeName and TaxiNodeName(node.slotIndex)) or node.name or true
            n = n + 1
        end
    end
    if n > 0 then GearSnapshotDB.flights, GearSnapshotDB.flightsT = fl, time() end
end
local function QuestStore()
    GearSnapshotDB = GearSnapshotDB or {}
    GearSnapshotDB.quests = GearSnapshotDB.quests or {}
    return GearSnapshotDB.quests
end
local function ReadDone()
    local ids = {}
    if C_QuestLog and C_QuestLog.GetAllCompletedQuestIDs then
        for _, id in ipairs(C_QuestLog.GetAllCompletedQuestIDs()) do ids[#ids + 1] = id end
    elseif GetQuestsCompleted then
        for id in pairs(GetQuestsCompleted()) do ids[#ids + 1] = id end
    end
    if #ids == 0 then return end -- not answered yet: keep the last list
    table.sort(ids)
    local q = QuestStore()
    q.done, q.doneTime = ids, time()
end
local function LogTitle(i)
    if C_QuestLog and C_QuestLog.GetInfo then
        local info = C_QuestLog.GetInfo(i)
        if not info then return end
        local c
        if not info.isHeader then
            if C_QuestLog.IsFailed and C_QuestLog.IsFailed(info.questID) then c = -1
            elseif C_QuestLog.IsComplete and C_QuestLog.IsComplete(info.questID) then c = 1 end
        end
        return info.title, info.level, info.isHeader, info.isCollapsed, c, info.questID
    end
    local title, level, _, isHeader, isCollapsed, c, _, id = GetQuestLogTitle(i)
    return title, level, isHeader, isCollapsed, c, id
end
local function ReadLog()
    local getNum = (C_QuestLog and C_QuestLog.GetNumQuestLogEntries) or GetNumQuestLogEntries
    if not getNum then return end
    local entries, numQuests = getNum()
    local log, folded = {}, 0
    for i = 1, entries or 0 do
        local title, level, isHeader, isCollapsed, c, id = LogTitle(i)
        if isHeader then
            if isCollapsed then folded = folded + 1 end
        elseif id and id > 0 then
            local row = { id = id, title = title, level = level, ready = (c == 1) or nil, failed = (c == -1) or nil, obj = {} }
            local objs = C_QuestLog and C_QuestLog.GetQuestObjectives and C_QuestLog.GetQuestObjectives(id)
            if not objs and GetNumQuestLeaderBoards then
                objs = {}
                for j = 1, GetNumQuestLeaderBoards(i) or 0 do
                    local text, kind, finished = GetQuestLogLeaderBoard(j, i)
                    objs[j] = { text = text, type = kind, finished = finished }
                end
            end
            for j, o in ipairs(objs or {}) do
                row.obj[j] = { text = o.text, type = o.type, done = o.finished and true or nil, have = o.numFulfilled, need = o.numRequired }
            end
            log[#log + 1] = row
        end
    end
    -- no rows while the log still has quests = a loading screen: keep the last good log
    if #log == 0 and (numQuests or 0) > 0 then return end
    local q = QuestStore()
    q.log, q.logTime, q.inLog = log, time(), numQuests
    -- a folded zone in the quest log hides its quests from this list: the page says to unfold them
    q.folded = (folded > 0 and #log < (numQuests or 0)) and folded or nil
end
-- Where you stand and where your hearthstone is set, so the route can plan your first trip from there.
-- World coordinates come from the map position (C_Map.GetWorldPosFromMapPos); inside a dungeon there is none: keep the last.
local function ReadWhere()
    local q = QuestStore()
    local bind = GetBindLocation and GetBindLocation()
    if bind and bind ~= "" then q.hearth = bind end
    local um = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local pos = um and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(um, "player")
    if not pos then return end
    local x, y = pos:GetXY()
    if not x or (x == 0 and y == 0) then return end
    local here = { map = um, x = math.floor(x * 10000 + 0.5) / 100, y = math.floor(y * 10000 + 0.5) / 100, time = time() }
    local info = C_Map.GetMapInfo and C_Map.GetMapInfo(um)
    if info then here.zone = info.name end
    if C_Map.GetWorldPosFromMapPos then
        local cont, w = C_Map.GetWorldPosFromMapPos(um, pos)
        if cont and w then here.cont = cont; here.wx, here.wy = w:GetXY() end
    end
    q.where = here
end
local function ReadQuests() pcall(ReadDone); pcall(ReadLog); pcall(ReadWhere) end

-- (1.7) Bags, bank and mailbox, for "I have" on Profession leveling and the Craft finder (so TradeSkillMaster isn't
-- needed). Item counts per character, each part with the time it was read: bags while you play, the bank only while
-- it is open, the mailbox when you open it. Kept account-wide (GearSnapshotBags) so your alts' bags are in the file
-- too; every character's GearSnapshot.lua carries a copy. Read-only.
local CNT = C_Container or {}
local NumSlots = CNT.GetContainerNumSlots or GetContainerNumSlots
local function SlotItem(bag, slot)
    if CNT.GetContainerItemInfo then
        local i = CNT.GetContainerItemInfo(bag, slot)
        if i then return i.itemID, i.stackCount end
        return nil
    end
    if GetContainerItemInfo then
        local _, count, _, _, _, _, link, _, _, id = GetContainerItemInfo(bag, slot)
        id = id or (link and tonumber(link:match("item:(%d+)")))
        return id, count
    end
end
local function ReadContainers(list, by)
    local out, any = {}, false
    for _, bag in ipairs(list) do
        local n = NumSlots and NumSlots(bag) or 0
        local one = {}
        for slot = 1, n or 0 do
            local id, count = SlotItem(bag, slot)
            if id then out[id] = (out[id] or 0) + (count or 1); one[id] = (one[id] or 0) + (count or 1); any = true end
        end
        if (n or 0) > 0 then any = true end
        if by then by[bag] = (n or 0) > 0 and { slots = n, items = one } or nil end -- which container held what (to check the counts)
    end
    return any and out or nil
end
local function BagList()
    local B, list = Enum and Enum.BagIndex, { 0, 1, 2, 3, 4 }
    if B and B.ReagentBag then list[#list + 1] = B.ReagentBag end
    return list
end
local function BankList()
    local B, list = Enum and Enum.BagIndex, {}
    list[1] = (B and B.Bank) or BANK_CONTAINER or -1
    if B and B.BankBag_1 then
        for i = 1, 7 do if B["BankBag_" .. i] then list[#list + 1] = B["BankBag_" .. i] end end
    else
        -- bank bags come right after your own bags (incl. a 5th/reagent bag slot); never count one of your bags twice
        local mine, first = {}, 0
        for _, i in ipairs(BagList()) do mine[i] = true; if i >= first then first = i + 1 end end
        for i = first, first + math.max(NUM_BANKBAGSLOTS or 0, 7) - 1 do if not mine[i] then list[#list + 1] = i end end
    end
    if B and B.Reagentbank and (not IsReagentBankUnlocked or IsReagentBankUnlocked()) then list[#list + 1] = B.Reagentbank end
    return list
end
local function BagStore()
    GearSnapshotBags = GearSnapshotBags or {}
    GearSnapshotBags.chars = GearSnapshotBags.chars or {}
    local key = UnitName("player") .. "-" .. GetRealmName()
    local c = GearSnapshotBags.chars[key] or {}
    GearSnapshotBags.chars[key] = c
    c.name, c.realm, c.faction, c.money = UnitName("player"), GetRealmName(), UnitFactionGroup("player"), GetMoney()
    return c
end
local bankOpen = false
local function ReadBags()
    local by = {}
    local items = ReadContainers(BagList(), by)
    if not items then return end -- not answered yet (loading screen)
    local c = BagStore(); c.bags, c.bagsT, c.bagsBy = items, time(), by
end
local function ReadBank()
    if not bankOpen then return end
    local by = {}
    local items = ReadContainers(BankList(), by)
    if not items then return end
    local c = BagStore(); c.bank, c.bankT, c.bankBy = items, time(), by
end
local function ReadMail()
    if not (GetInboxNumItems and GetInboxItem) then return end
    local n = GetInboxNumItems()
    local out = {}
    for i = 1, n or 0 do
        for j = 1, ATTACHMENTS_MAX_RECEIVE or 16 do
            local _, id, _, count = GetInboxItem(i, j)
            if id and type(id) ~= "number" then id = nil end
            if not id and GetInboxItemLink then local l = GetInboxItemLink(i, j); id = l and tonumber(l:match("item:(%d+)")) end
            if id then out[id] = (out[id] or 0) + (count or 1) end
        end
    end
    local c = BagStore(); c.mail, c.mailT = out, time()
end

local function Snapshot()
    local old = GearSnapshotDB and GearSnapshotDB.gear or {}
    local db = {
        version = 3, name = UnitName("player"), realm = GetRealmName(),
        class = select(2, UnitClass("player")), level = UnitLevel("player"),
        race = select(2, UnitRace("player")), raceId = select(3, UnitRace("player")), faction = UnitFactionGroup("player"),
        money = GetMoney(), skills = Skills(), time = time(), date = date("%Y-%m-%d %H:%M"), gear = {},
        ah = GearSnapshotDB and GearSnapshotDB.ah or nil,
        recipes = GearSnapshotDB and GearSnapshotDB.recipes or nil,
        quests = GearSnapshotDB and GearSnapshotDB.quests or nil,
        flights = GearSnapshotDB and GearSnapshotDB.flights or nil, flightsT = GearSnapshotDB and GearSnapshotDB.flightsT or nil,
        bags = GearSnapshotBags and { chars = GearSnapshotBags.chars } or nil, -- (1.7) every character's bags, bank and mail (not the 1.8 prices)
    }
    for _, s in ipairs(SLOTS) do db.gear[s] = ReadItem(s, old[s]) end
    local ok, v = pcall(BisSpec); if ok then db.spec = v end
    -- Forever Leveling BiS version, so the Gear Upgrades page can warn when its item data is older than the addon
    ok, v = pcall(function()
        local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
        return get and get("ForeverLevelingBiS", "Version")
    end)
    if ok and v then db.bis = v end
    ok, v = pcall(Talents); if ok then db.talents = v end
    -- (1.8, temporary) what this client's talent functions return, to read the spec from talents later
    ok, v = pcall(function()
        local p = { tabs = GetNumTalentTabs and GetNumTalentTabs() or "none", n1 = GetNumTalents and GetNumTalents(1) or "none",
                    spec = GetSpecialization and GetSpecialization() or "none", primary = GetPrimaryTalentTree and GetPrimaryTalentTree() or "none" }
        if GetTalentInfo then local r = { pcall(GetTalentInfo, 1, 1) }; for i = 1, #r do r[i] = type(r[i]) == "table" and "table" or tostring(r[i]) end; p.info11 = r end
        if GetTalentTabInfo then local r = { pcall(GetTalentTabInfo, 2) }; for i = 1, #r do r[i] = tostring(r[i]) end; p.tab2 = r end
        if C_SpecializationInfo then local t = {}; for k in pairs(C_SpecializationInfo) do t[#t + 1] = k end; table.sort(t); p.csi = table.concat(t, ",") end
        return p
    end)
    if ok then db.talentProbe = v end
    ok, v = pcall(WeaponSkills); if ok then db.wskills = v end
    GearSnapshotDB = db
end

local f = CreateFrame("Frame")
for _, ev in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_EQUIPMENT_CHANGED", "PLAYER_LEVEL_UP", "SKILL_LINES_CHANGED", "PLAYER_LOGOUT",
                      "ITEM_SEARCH_RESULTS_UPDATED", "AUCTION_ITEM_LIST_UPDATE", "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED",
                      "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "AUCTION_HOUSE_BROWSE_RESULTS_ADDED",
                      "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_UPDATE", "CRAFT_SHOW", "CRAFT_UPDATE",
                      "QUEST_LOG_UPDATE", "QUEST_TURNED_IN", "QUEST_ACCEPTED", "QUEST_REMOVED", "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED",
                      "TAXIMAP_OPENED", "BAG_UPDATE_DELAYED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED", "PLAYERBANKSLOTS_CHANGED", "PLAYERREAGENTBANKSLOTS_CHANGED", "MAIL_INBOX_UPDATE" }) do
    pcall(f.RegisterEvent, f, ev) -- (an event this client doesn't have is skipped)
end
f:SetScript("OnEvent", function(_, ev, arg1)
    if ev == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or ev == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
        local ok, err = pcall(OnBrowse, ev, arg1)
        if not ok then scan = nil; Status("couldn't read the scan: " .. tostring(err), 20) end
    elseif ev == "AUCTION_HOUSE_SHOW" then
        HookBrowse()
        local ok, err = pcall(AddScanButton)
        if not ok then print("|cff66ccffGear Snapshot:|r couldn't add the Scan button (" .. tostring(err) .. "). Type /gearsnap scan instead.") end
        local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
        house = (map and NEUTRAL_MAPS[map]) and "Neutral" or UnitFactionGroup("player")
    elseif ev == "AUCTION_HOUSE_CLOSED" then
        if scan and scan.full and (scan.mine or scan.pages >= 2) then Status("scan stopped: the auction house closed before it finished.", 15)
        elseif statusFrame then statusFrame:Hide() end
        scan = nil
    elseif ev == "ITEM_SEARCH_RESULTS_UPDATED" then pcall(ReadItemSearch, arg1)
    elseif ev == "AUCTION_ITEM_LIST_UPDATE" then pcall(ReadLegacy)
    elseif ev:find("^TRADE_SKILL") or ev:find("^CRAFT") then
        if ev == "TRADE_SKILL_SHOW" or ev == "CRAFT_SHOW" then wipe(announce) end -- say it again each time a window opens
        if f.recTimer then f.recTimer:Cancel() end -- wait until the list stops changing, then read it once
        local kind = ev:find("^CRAFT") and "CRAFT_SHOW" or "TRADE_SKILL_SHOW"
        f.recTimer = C_Timer.NewTimer(1, function() f.recTimer = nil; ReadRecipes(kind) end)
    elseif ev == "TAXIMAP_OPENED" then C_Timer.After(0.5, function() pcall(ReadFlights) end)
    elseif ev:find("^ZONE_CHANGED") then pcall(ReadWhere)
    elseif ev == "BANKFRAME_OPENED" then bankOpen = true; pcall(ReadBank)
    elseif ev == "BANKFRAME_CLOSED" then bankOpen = false -- (the bank may already be gone: keep what was read while open)
    elseif ev == "MAIL_INBOX_UPDATE" then
        if f.mailTimer then f.mailTimer:Cancel() end
        f.mailTimer = C_Timer.NewTimer(1, function() f.mailTimer = nil; pcall(ReadMail) end)
    elseif ev == "BAG_UPDATE_DELAYED" or ev:find("BANKSLOTS_CHANGED$") then
        if f.bagTimer then f.bagTimer:Cancel() end -- many updates in a row while looting or sorting: read once they stop
        f.bagTimer = C_Timer.NewTimer(1, function() f.bagTimer = nil; pcall(ReadBags); pcall(ReadBank) end)
    elseif ev:find("^QUEST_") then
        if f.qTimer then f.qTimer:Cancel() end -- the log fires many updates in a row: read it once they stop
        f.qTimer = C_Timer.NewTimer(1, function() f.qTimer = nil; ReadQuests() end)
    elseif ev == "PLAYER_ENTERING_WORLD" then C_Timer.After(3, function() pcall(ReadBags); Snapshot(); ReadQuests() end)
    else
        if ev == "PLAYER_LOGOUT" then pcall(ReadWhere); pcall(ReadBags) end -- where you logged out (kept if the game no longer answers)
        Snapshot()
    end
end)

SLASH_GEARSNAPSHOT1 = "/gearsnap"
SlashCmdList.GEARSNAPSHOT = function(msg)
    if msg and msg:lower():find("scan") then StartScan() return end
    Snapshot()
    local n, p = 0, 0
    for _ in pairs(GearSnapshotDB.gear) do n = n + 1 end
    for _ in pairs(GearSnapshotDB.ah and GearSnapshotDB.ah.items or {}) do p = p + 1 end
    print("|cff66ccffGear Snapshot:|r saved " .. n .. " items, level " .. GearSnapshotDB.level .. " " .. tostring(GearSnapshotDB.class) .. (GearSnapshotDB.spec and (" (" .. GearSnapshotDB.spec .. ")") or "") .. ", suffix prices for " .. p .. " items. Recipes: " .. (function() local t = {}; for k, v in pairs(GearSnapshotDB.recipes or {}) do t[#t + 1] = k .. " " .. (v.n or 0) end; return #t > 0 and table.concat(t, ", ") or "open a profession window first" end)() .. ". Type /reload to write the file.")
end
