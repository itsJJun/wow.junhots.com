-- The arrow (points at your next stop) and the step list under it.
local _, ns = ...
local P = ns.Planner
local S = ns.state
local canaccess = canaccessvalue or function() return true end
local atan2, pi = math.atan2, math.pi

local arrow, panel, lines = nil, nil, {}

local function SavePos(frame)
	local point, _, rel, x, y = frame:GetPoint(1)
	JunhotsTravelDB.arrow = { point, rel, x, y }
end

local function MakeArrow()
	arrow = CreateFrame("Button", "JunhotsTravelArrow", UIParent)
	arrow:SetSize(64, 64)
	arrow:SetMovable(true)
	arrow:EnableMouse(true)
	arrow:RegisterForDrag("LeftButton")
	arrow:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	arrow:SetClampedToScreen(true)
	arrow:SetScript("OnDragStart", arrow.StartMoving)
	arrow:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); SavePos(self) end)
	arrow:SetScript("OnClick", function(_, btn)
		if btn == "RightButton" then
			if C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
			ns.SetGoal(nil)
		else
			ns.TogglePanel()
		end
	end)
	arrow:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
		GameTooltip:AddLine("Junhots Travel")
		GameTooltip:AddLine("Click: show or hide the steps", 1, 1, 1)
		GameTooltip:AddLine("Drag: move", 1, 1, 1)
		GameTooltip:AddLine("Right-click: stop", 1, 1, 1)
		GameTooltip:Show()
	end)
	arrow:SetScript("OnLeave", function() GameTooltip:Hide() end)
	local t = arrow:CreateTexture(nil, "ARTWORK")
	t:SetPoint("CENTER")
	if C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo("Navigation-Tracked-Arrow") then
		t:SetAtlas("Navigation-Tracked-Arrow")
		t:SetSize(40, 40)
	else
		t:SetTexture("Interface\\Minimap\\MinimapArrow")
		t:SetSize(48, 48)
	end
	t:SetVertexColor(1, 0.82, 0.2)
	arrow.tex = t
	local done = arrow:CreateTexture(nil, "ARTWORK")
	done:SetPoint("CENTER")
	done:SetSize(36, 36)
	done:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
	done:Hide()
	arrow.done = done
	local txt = arrow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	txt:SetPoint("TOP", arrow, "BOTTOM", 0, 2)
	txt:SetWidth(260)
	arrow.text = txt
	local sub = arrow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	sub:SetPoint("TOP", txt, "BOTTOM", 0, -2)
	arrow.sub = sub
	ns.UIReset()
	arrow:SetScript("OnUpdate", function(self, el)
		self.t = (self.t or 0) + el
		if self.t < 0.05 then return end
		self.t = 0
		ns.Point()
	end)
end

function ns.UIReset()
	if not arrow then return end
	arrow:ClearAllPoints()
	local p = JunhotsTravelDB.arrow
	if p then arrow:SetPoint(p[1], UIParent, p[2] or p[1], p[3], p[4])
	else arrow:SetPoint("TOP", UIParent, "TOP", 0, -140) end
end

local function MakePanel()
	panel = CreateFrame("Frame", "JunhotsTravelPanel", UIParent, "BackdropTemplate")
	panel:SetSize(300, 40)
	panel:SetPoint("TOP", arrow.sub, "BOTTOM", 0, -6)
	if panel.SetBackdrop then
		panel:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
		panel:SetBackdropColor(0, 0, 0, 0.75)
		panel:SetBackdropBorderColor(0.4, 0.4, 0.4)
	end
	panel:Hide()
	panel:SetShown(JunhotsTravelDB.panel ~= false)
end

local function Line(i)
	local l = lines[i]
	if not l then
		l = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		l:SetJustifyH("LEFT")
		l:SetWidth(280)
		l:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, -8 - (i - 1) * 16)
		lines[i] = l
	end
	return l
end

function ns.TogglePanel()
	if not panel then return end
	JunhotsTravelDB.panel = not panel:IsShown()
	ns.Refresh()
end

local KIND = { fly = "|cff66dd66", boat = "|cff66aaff", zeppelin = "|cff66aaff", tram = "|cff66aaff", lift = "|cff66aaff", portal = "|cffcc88ff", passage = "|cffcc88ff" }

-- step list + arrow words
function ns.Refresh()
	if not arrow then return end
	local g = S.goal
	ns.Draw()
	arrow:SetShown(g ~= nil)
	if not g then panel:Hide(); return end
	arrow.done:SetShown(S.arrived == true)
	arrow.tex:SetShown(not S.arrived)
	local n = 0
	if S.arrived then
		arrow.text:SetText("You're there")
		arrow.sub:SetText(g.name or "")
	elseif UnitOnTaxi("player") then
		arrow.text:SetText("Flying to " .. (S.flying or "your flight point"))
		arrow.sub:SetText("")
		arrow.tex:Hide()
	elseif not S.plan then
		arrow.text:SetText("No way found")
		arrow.sub:SetText(g.name or "")
	else
		local l = S.plan.legs[1]
		arrow.text:SetText(l and P.Say(l, S.plan.legs[2]) or "")
		arrow.sub:SetText("All the way: " .. P.Time(S.plan.secs))
		for i, leg in ipairs(S.plan.legs) do
			n = n + 1
			local c = KIND[leg.k] or "|cffffd100"
			Line(n):SetText(c .. i .. ".|r " .. P.Say(leg, S.plan.legs[i + 1]) .. "  |cff999999" .. P.Time(leg.secs) .. "|r")
		end
	end
	if ns.KnownCount() == 0 then
		n = n + 1
		Line(n):SetText("|cffff8866Open any flight master's map once so I know your flight points.|r")
	end
	for i = 1, #lines do lines[i]:SetShown(i <= n) end
	panel:SetHeight(16 + n * 16)
	panel:SetShown(JunhotsTravelDB.panel ~= false and n > 0)
end

-- turn the arrow toward the next stop
function ns.Point()
	if not S.plan or S.arrived or UnitOnTaxi("player") then return end
	local spot = ns.NextSpot()
	local here = ns.Here()
	local facing = GetPlayerFacing()
	if not (spot and here and facing and canaccess(facing)) or spot.map ~= here.map then
		arrow.tex:SetAlpha(0.3)
		return
	end
	local l = S.plan.legs[1]
	-- at the start of a flight, boat or portal: nothing to point at
	arrow.tex:SetAlpha((l and l.k ~= "walk") and 0.3 or 1)
	local bearing = atan2(spot.y - here.y, spot.x - here.x) -- counter-clockwise from north, like facing
	arrow.tex:SetRotation(bearing - facing)
	local d = P.dist(here, spot)
	local txt = (l and P.Say(l, S.plan.legs[2]) or "")
	if l and l.k == "walk" then txt = txt .. "  |cffffffff" .. math.floor(d + 0.5) .. " yd|r" end
	arrow.text:SetText(txt)
end

function ns.UIInit()
	MakeArrow()
	MakePanel()
	ns.Refresh()
end
