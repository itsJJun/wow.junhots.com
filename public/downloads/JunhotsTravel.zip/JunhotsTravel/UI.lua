-- The arrow (points at your next stop) and the step list under it.
local _, ns = ...
local P = ns.Planner
local S = ns.state
local canaccess = canaccessvalue or function() return true end
local atan2, pi, exp = math.atan2, math.pi, math.exp
local TWO = 2 * pi
local EASE = 18   -- how fast the arrow swings round (same smoothness at any frame rate)
local ORBIT = 29  -- ring style: how far from the centre the arrow rides (just outside the ring)

-- "ring" (default) or "plain" (the arrow alone)
function ns.ArrowStyle() return (JunhotsTravelDB and JunhotsTravelDB.arrowStyle) or "ring" end

local arrow, panel, lines = nil, nil, {}

local function SavePos(frame)
	local point, _, rel, x, y = frame:GetPoint(1)
	JunhotsTravelDB.arrow = { point, rel, x, y }
end

local function MakeArrow()
	arrow = CreateFrame("Button", "JunhotsTravelArrow", UIParent)
	arrow:SetSize(52, 52)
	arrow:SetMovable(true)
	arrow:EnableMouse(true)
	arrow:RegisterForDrag("LeftButton")
	arrow:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	arrow:SetClampedToScreen(true)
	arrow:SetScript("OnDragStart", arrow.StartMoving)
	arrow:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); SavePos(self) end)
	arrow:SetScript("OnClick", function(_, btn)
		if btn == "RightButton" then
			if C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
			ns.SetGoal(nil)
		else
			ns.TogglePanel()
		end
	end)
	arrow:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
		GameTooltip:AddLine("Junhots Travel")
		if ns.ArrowStyle() == "ring" then
			GameTooltip:AddLine("The number is the distance in yards", 1, 1, 1)
			GameTooltip:AddLine("Turn until the arrow is over the dot: it turns green", 1, 1, 1)
		end
		GameTooltip:AddLine("Click: show or hide the steps", 1, 1, 1)
		GameTooltip:AddLine("Drag: move", 1, 1, 1)
		GameTooltip:AddLine("Right-click: stop", 1, 1, 1)
		GameTooltip:Show()
	end)
	arrow:SetScript("OnLeave", function() GameTooltip:Hide() end)
	-- ring style (default): the game's gold ring with the distance inside, and the arrow riding round it.
	-- When you face the right way the ring glows green.
	local back = ns.NoSnap(arrow:CreateTexture(nil, "BACKGROUND"))
	back:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\soft")   -- soft.tga: dark round backing
	back:SetSize(36, 36)
	back:SetPoint("CENTER")
	local glow = ns.NoSnap(arrow:CreateTexture(nil, "BORDER"))
	glow:SetPoint("CENTER")
	if not ns.Atlas(glow, "ArtifactsFX-YellowRing", 54, 54) then glow:SetSize(1, 1); glow:SetColorTexture(0, 0, 0, 0) end
	glow:SetVertexColor(0.45, 1, 0.45)
	glow:SetAlpha(0)
	local ring = ns.NoSnap(arrow:CreateTexture(nil, "BORDER", nil, 1))
	-- the gold ring sits 2.5 px above the middle of its art (its shadow is below): line the ring itself up
	ring:SetPoint("CENTER", 0.5, -2.6)
	if not ns.Atlas(ring, "worldquest-tracker-ring-selected", 46, 46) then ring:SetSize(1, 1); ring:SetColorTexture(0, 0, 0, 0) end
	arrow.ring, arrow.back, arrow.glow = ring, back, glow
	-- a small gem set in the top of the ring: line the arrow up with it. Gold, turning green when you face the way
	-- (the game's own level-up dots).
	local gem = ns.NoSnap(arrow:CreateTexture(nil, "BORDER", nil, 3))
	local gemOn = ns.NoSnap(arrow:CreateTexture(nil, "BORDER", nil, 4))
	if not (ns.Atlas(gem, "levelup-dot-gold", 8.5, 9) and ns.Atlas(gemOn, "levelup-dot-green", 8.5, 9)) then
		gem:SetSize(1, 1); gem:SetColorTexture(0, 0, 0, 0); gemOn:SetSize(1, 1); gemOn:SetColorTexture(0, 0, 0, 0)
	end
	gem:SetPoint("CENTER", 0.5, 17.15)   -- on the ring's gold band, straight up
	gemOn:SetPoint("CENTER", gem, "CENTER")
	gemOn:SetAlpha(0)
	arrow.gem, arrow.gemOn = gem, gemOn
	local mid = arrow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	mid:SetPoint("CENTER", 0.5, 0)
	arrow.mid = mid
	local t = arrow:CreateTexture(nil, "ARTWORK")
	ns.NoSnap(t)
	t:SetPoint("CENTER")
	-- the game's own navigation arrow (as its waypoint marker uses), else ours (media/arrow.tga)
	ns.arrowArt = "game"
	if not ns.Atlas(t, "Navigation-Tracked-Arrow", 40, 40) then
		ns.arrowArt = "own"
		t:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\arrow")
		t:SetSize(40, 40)
	end
	arrow.tex = t
	local bw, bh = t:GetSize()
	arrow.big = { bw or 40, bh or bw or 40 }
	local done = arrow:CreateTexture(nil, "ARTWORK")
	done:SetPoint("CENTER")
	-- you're there: the game's map pin, else ours
	if not ns.Atlas(done, "Waypoint-MapPin-Tracked", 30, 30) then
		done:SetSize(30, 30)
		done:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\pin")
	end
	done:Hide()
	arrow.done = done
	local txt = arrow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	txt:SetPoint("TOP", arrow, "BOTTOM", 0, 2)
	arrow.text = txt
	local sub = arrow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	sub:SetPoint("TOP", txt, "BOTTOM", 0, -2)
	sub:SetWidth(320)
	arrow.sub = sub
	ns.UIReset()
	ns.ArrowLayout()
	-- every frame: turn smoothly; 10 times a second: where to point and how far
	arrow:SetScript("OnUpdate", function(self, el)
		self.t = (self.t or 0) + el
		if self.t >= 0.05 then
			self.t = 0
			if not ns.Safe("arrow", ns.Point) then self:SetScript("OnUpdate", nil); return end
		end
		ns.Turn(el)
	end)
end

-- ring style: small arrow on the ring's edge, distance inside; plain: the big arrow alone
function ns.ArrowLayout()
	if not arrow then return end
	local ring = ns.ArrowStyle() == "ring"
	local w, h = arrow.big[1], arrow.big[2]
	if ring then w, h = 22, h * 22 / w end   -- the game arrow's own size: crisp
	arrow.tex:SetSize(w, h)
	arrow.tex:ClearAllPoints()
	arrow.tex:SetPoint("CENTER")
	arrow.tex:SetVertexColor(1, 1, 1)
	arrow.angle = nil
	arrow.ring:SetShown(ring); arrow.gem:SetShown(ring); arrow.gemOn:SetShown(ring)
	arrow.back:SetShown(ring)
	arrow.glow:SetShown(ring)
	arrow.mid:SetText("")
	arrow:SetSize(ring and 76 or 52, ring and 76 or 52)
	-- ring: "Run to" in white, the place in gold (the distance is inside); plain: the distance in gold
	if arrow.text.SetFontObject then arrow.text:SetFontObject(ring and "GameFontHighlight" or "GameFontNormal") end
end

-- time left, short: 45s / 3m / 1h05
local function Left(s)
	s = math.max(0, math.floor(s + 0.5))
	if s < 60 then return s .. "s" end
	if s < 3600 then return math.floor(s / 60 + 0.5) .. "m" end
	return string.format("%dh%02d", math.floor(s / 3600), math.floor(s % 3600 / 60))
end
-- what the ring shows (Settings): "distance" (default), "time" left, or "both" (distance in the ring, time under it)
function ns.ArrowLabel() return (JunhotsTravelDB and JunhotsTravelDB.label) or "distance" end

-- 127 / 1.2k
local function Yards(d)
	d = math.floor(d + 0.5)
	if d < 1000 then return tostring(d) end
	return string.format("%.1fk", d / 1000)
end

function ns.UIReset()
	if not arrow then return end
	arrow:SetScale(JunhotsTravelDB.scale or 1)
	arrow:ClearAllPoints()
	local p = JunhotsTravelDB.arrow
	if p then arrow:SetPoint(p[1], UIParent, p[2] or p[1], p[3], p[4])
	else arrow:SetPoint("TOP", UIParent, "TOP", 0, -140) end
end

local function MakePanel()
	panel = CreateFrame("Frame", "JunhotsTravelPanel", UIParent, "BackdropTemplate")
	panel:SetSize(300, 40)
	panel:SetPoint("TOP", arrow.sub, "BOTTOM", 0, -6)
	if panel.SetBackdrop then
		panel:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
		panel:SetBackdropColor(0.06, 0.05, 0.04, 0.85)
		panel:SetBackdropBorderColor(0.55, 0.43, 0.2)
	end
	panel:Hide()
	panel:SetShown(JunhotsTravelDB.panel ~= false)
end

local function Line(i)
	local l = lines[i]
	if not l then
		l = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		l:SetJustifyH("LEFT")
		l:SetWidth(280)
		-- each line under the one before, so a long line that wraps pushes the rest down
		if i == 1 then l:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, -8)
		else l:SetPoint("TOPLEFT", Line(i - 1), "BOTTOMLEFT", 0, -3) end
		lines[i] = l
	end
	return l
end

function ns.TogglePanel()
	if not panel then return end
	JunhotsTravelDB.panel = not panel:IsShown()
	ns.Refresh()
end

local KIND = { hearth = "|cff66ccff", fly = "|cff66dd66", boat = "|cff66aaff", zeppelin = "|cff66aaff", tram = "|cff66aaff", lift = "|cff66aaff", portal = "|cffcc88ff", passage = "|cffcc88ff" }

-- for the compass bar: where the way is (from north, like facing) while you walk, and how far
function ns.ArrowBearing() return arrow and arrow.walking and arrow.bearing or nil end
function ns.ArrowDistanceText() return arrow and arrow.distText or "" end

-- step list + arrow words
function ns.Refresh()
	if not arrow then return end
	if ns.CompassRefresh then ns.Safe("compass", ns.CompassRefresh) end
	if ns.MarkerUpdate then ns.Safe("marker", ns.MarkerUpdate) end
	local g = S.goal
	ns.Safe("map", ns.Draw)
	arrow:SetShown(g ~= nil)
	if not g then panel:Hide(); return end
	local ring = ns.ArrowStyle() == "ring"
	arrow.done:SetShown(S.arrived == true)
	arrow.tex:SetShown(not S.arrived)
	arrow.ring:SetShown(ring and not S.arrived); arrow.gem:SetShown(ring and not S.arrived); arrow.gemOn:SetShown(ring and not S.arrived)
	arrow.back:SetShown(ring and not S.arrived)
	arrow.glow:SetShown(ring and not S.arrived)
	if S.arrived or not S.plan or (UnitOnTaxi("player") and not S.flyEnd) then arrow.mid:SetText("") end
	local n = 0
	if S.arrived then
		arrow.text:SetText("You're there")
		arrow.sub:SetText((g.quest and ns.QuestLine and ns.QuestLine(g.quest)) or g.name or "")
	elseif UnitOnTaxi("player") then
		arrow.text:SetText("Flying to |cffffd100" .. (S.flying or "your flight point") .. "|r")
		arrow.tex:Hide()
		ns.FlyLeft()
	elseif not S.plan then
		arrow.text:SetText("No way found")
		arrow.sub:SetText(g.name or "")
	else
		ns.Point()
		for i, leg in ipairs(S.plan.legs) do
			n = n + 1
			local c = KIND[leg.k] or "|cffffd100"
			Line(n):SetText(c .. i .. ".|r " .. P.Say(leg, S.plan.legs[i + 1]) .. "  |cff999999" .. P.Time(leg.secs) .. "|r")
			-- what the walk does about danger, in grey under it
			for _, note in ipairs(leg.notes or {}) do
				n = n + 1
				Line(n):SetText("    |cff999999" .. note .. "|r")
			end
		end
	end
	if ns.KnownCount() == 0 then
		n = n + 1
		Line(n):SetText("|cffff8866Open any flight master's map once so I know your flight points.|r")
	end
	if S.plan and #S.plan.legs > 1 then
		n = n + 1
		Line(n):SetText("|cff999999All the way: " .. P.Time(S.plan.secs) .. "|r")
	end
	-- as wide as the longest line (wrapping only past 380 px), as tall as the lines
	local wide = 200
	for i = 1, n do
		local l = lines[i]
		local sw = tonumber(l.GetUnboundedStringWidth and l:GetUnboundedStringWidth() or l:GetStringWidth()) or 0
		if sw > wide then wide = sw end
	end
	wide = math.min(380, wide + 4)
	local h = 0
	for i = 1, #lines do
		lines[i]:SetShown(i <= n)
		lines[i]:SetWidth(wide)
		if i <= n then h = h + (tonumber(lines[i]:GetStringHeight()) or 12) + 3 end
	end
	panel:SetSize(wide + 20, h + 13)
	-- a one-step walk only repeats the line under the arrow: no list then
	local worth = (S.plan and (#S.plan.legs > 1 or S.plan.legs[1] and S.plan.legs[1].notes)) or ns.KnownCount() == 0
	panel:SetShown(JunhotsTravelDB.panel ~= false and n > 0 and worth)
end

-- the step in a few words, without the compass direction (the arrow shows that)
local function Short(l, nxt)
	return (P.Say(l, nxt):gsub("^(%a+) %a+ to ", "%1 to "))
end

-- where the arrow points (bearing from north) and the words under it
-- in the air: time until you land in the ring (written the same way every time, so it never blinks)
function ns.FlyLeft()
	if not S.flyEnd then arrow.sub:SetText(""); return end
	local ring = ns.ArrowStyle() == "ring"
	local left = math.max(0, math.floor(S.flyEnd - GetTime() + 0.5))
	local t = string.format("%d:%02d", math.floor(left / 60), left % 60)
	arrow.mid:SetText(ring and t or "")
	arrow.sub:SetText(ring and "" or ("Lands in " .. t))
end
function ns.Point()
	local ring = ns.ArrowStyle() == "ring"
	if UnitOnTaxi("player") then ns.FlyLeft() end
	if not S.plan or S.arrived or UnitOnTaxi("player") then arrow.bearing, arrow.walking = nil, false; return end
	local l = S.plan.legs[1]
	local spot = ns.NextSpot()
	local here = ns.Here()
	if not (l and spot and here) or spot.map ~= here.map then
		arrow.bearing = nil
		arrow.walking = false
		arrow.tex:SetAlpha(ring and 0 or 0.3)
		arrow.ring:SetAlpha(0.4); arrow.gem:SetAlpha(0.4)
		arrow.back:SetAlpha(1)
		arrow.mid:SetText("")
		arrow.glow:SetAlpha(0); arrow.gemOn:SetAlpha(0)
		arrow.text:SetText(l and P.Say(l, S.plan.legs[2]) or "")
		arrow.sub:SetText("")
		return
	end
	arrow.bearing = atan2(spot.y - here.y, spot.x - here.x) -- counter-clockwise from north, like facing
	if l.k == "walk" then
		-- big: how far; small: where to
		arrow.walking = true
		arrow.distText = Yards(P.dist(here, spot))
		local al = arrow.behind and ring and 0.5 or 1
		arrow.tex:SetAlpha(al)
		arrow.ring:SetAlpha(al); arrow.gem:SetAlpha(al)
		arrow.back:SetAlpha(al)
		if ring then
			-- distance inside the ring, the step under it
			local lab = ns.ArrowLabel()
			arrow.mid:SetText(lab == "time" and Left(S.plan.secs or 0) or arrow.distText)
			-- "Run to" white, the place gold
			local words = (Short(l, S.plan.legs[2]):gsub("^(.- to )(.+)$", "%1|cffffd100%2|r"))
			if lab == "both" then words = words .. "  |cff999999" .. P.Time(S.plan.secs or 0) .. " left|r" end
			arrow.text:SetText(words)
			arrow.sub:SetText("")
		else
			arrow.text:SetText(math.floor(P.dist(here, spot) + 0.5) .. " yd")
			arrow.sub:SetText(Short(l, S.plan.legs[2]))
		end
	else
		-- at the start of a flight, boat or portal: nothing to point at
		arrow.walking = false
		arrow.tex:SetAlpha(ring and 0 or 0.3)
		arrow.ring:SetAlpha(0.4); arrow.gem:SetAlpha(0.4)
		arrow.back:SetAlpha(1)
		arrow.mid:SetText("")
		arrow.glow:SetAlpha(0); arrow.gemOn:SetAlpha(0)
		arrow.text:SetText(P.Say(l, S.plan.legs[2]))
		arrow.sub:SetText("")
	end
end

-- a goal from a quest icon: what to do there, under the step
do
	local inner = ns.Point
	function ns.Point()
		inner()
		local g = S.goal
		-- a goal named after a quest in your log (from a tooltip or another add-on's pin): that quest
		if g and not g.quest and g.name and g.qname ~= g.name then
			g.qname = g.name
			local id = ns.QuestIdByTitle(g.name)
			if id then
				local _, title, done = ns.QuestInLog(id)
				g.quest = { id = id, title = title, kind = done and "turnin" or "objective" }
			end
		end
		local q = g and g.quest and ns.QuestLine and ns.QuestLine(g.quest)
		if q and arrow and not UnitOnTaxi("player") then
			local cur = arrow.sub:GetText()
			if ns.ArrowStyle() == "ring" and S.plan and S.plan.legs[1] and not S.plan.legs[2] and arrow.walking then
				-- the last walk: say what to do there ("Turn in Venom Sac", "Kill Raptor 3/8") instead of "Run to"
				arrow.text:SetText(q); arrow.sub:SetText("")
			elseif ns.ArrowStyle() == "ring" or not cur or cur == "" then arrow.sub:SetText(q) else arrow.sub:SetText(cur .. "\n" .. q) end
		end
	end
end

-- ease the arrow toward its bearing (the shortest way round)
function ns.Turn(el)
	if not arrow.bearing then arrow.angle = nil; arrow.gemOn:SetAlpha(0); return end
	local facing = GetPlayerFacing()
	if not (facing and canaccess(facing)) then return end
	local want = (arrow.bearing - facing) % TWO
	local a = arrow.angle
	if not a then a = want
	else
		local d = (want - a + pi) % TWO - pi
		if math.abs(d) < 0.001 then a = want else a = (a + d * (1 - exp(-EASE * (el or 0)))) % TWO end
	end
	arrow.angle = a
	arrow.tex:SetRotation(a)
	if ns.ArrowStyle() ~= "ring" then return end
	-- ride round the ring, pointing out; the ring glows green as the arrow nears the top (= facing the right way)
	arrow.tex:ClearAllPoints()
	arrow.tex:SetPoint("CENTER", -math.sin(a) * ORBIT, math.cos(a) * ORBIT)
	local off = math.min(a, TWO - a)
	local on = 1 - math.min(1, math.max(0, (off - 0.1) / 0.3))
	arrow.glow:SetAlpha(on)
	arrow.gemOn:SetAlpha(on)
	-- the way is behind you: dim (past 120 degrees; back to full inside 100, so turning on the spot doesn't flicker)
	if off > 2.09 then arrow.behind = true elseif off < 1.75 then arrow.behind = false end
	if arrow.walking then
		local al = arrow.behind and 0.5 or 1
		arrow.ring:SetAlpha(al); arrow.gem:SetAlpha(al); arrow.tex:SetAlpha(al); arrow.back:SetAlpha(al)
	end
end

function ns.UIInit()
	MakeArrow()
	MakePanel()
	ns.Refresh()
end
