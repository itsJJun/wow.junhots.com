-- The arrow (points at your next stop) and the step list under it.
local _, ns = ...
local P = ns.Planner
local S = ns.state
local canaccess = canaccessvalue or function() return true end
local atan2, pi, exp = math.atan2, math.pi, math.exp
local TWO = 2 * pi
local EASE = 18   -- how fast the arrow swings round (same smoothness at any frame rate)
local ORBIT = 21  -- ring style: how far from the centre the arrow rides
local GOLD, GREEN = { 1, 0.82, 0.35 }, { 0.45, 1, 0.45 }

-- "ring" (default) or "plain" (the arrow alone)
function ns.ArrowStyle() return (JunhotsTravelDB and JunhotsTravelDB.arrowStyle) or "ring" end

local arrow, panel, lines = nil, nil, {}

local function SavePos(frame)
	local point, _, rel, x, y = frame:GetPoint(1)
	JunhotsTravelDB.arrow = { point, rel, x, y }
end

local function MakeArrow()
	arrow = CreateFrame("Button", "JunhotsTravelArrow", UIParent)
	arrow:SetSize(52, 52)
	arrow:SetMovable(true)
	arrow:EnableMouse(true)
	arrow:RegisterForDrag("LeftButton")
	arrow:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	arrow:SetClampedToScreen(true)
	arrow:SetScript("OnDragStart", arrow.StartMoving)
	arrow:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); SavePos(self) end)
	arrow:SetScript("OnClick", function(_, btn)
		if btn == "RightButton" then
			if C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
			ns.SetGoal(nil)
		else
			ns.TogglePanel()
		end
	end)
	arrow:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
		GameTooltip:AddLine("Junhots Travel")
		GameTooltip:AddLine("Click: show or hide the steps", 1, 1, 1)
		GameTooltip:AddLine("Drag: move", 1, 1, 1)
		GameTooltip:AddLine("Right-click: stop", 1, 1, 1)
		GameTooltip:Show()
	end)
	arrow:SetScript("OnLeave", function() GameTooltip:Hide() end)
	-- ring style (default): a thin ring, the arrow rides its edge, and the distance sits inside.
	-- Turn until the arrow reaches the small mark at the top: then it glows green.
	local ring = ns.NoSnap(arrow:CreateTexture(nil, "BACKGROUND"))
	ring:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\soft")   -- soft.tga holds the ring art
	ring:SetSize(48, 48)
	ring:SetPoint("CENTER")
	arrow.ring = ring
	local mark = ns.NoSnap(arrow:CreateTexture(nil, "BORDER"))
	mark:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\dot")
	mark:SetSize(5, 5)
	mark:SetPoint("CENTER", 0, 13)
	arrow.mark = mark
	local mid = arrow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	mid:SetPoint("CENTER", 0, 1)
	arrow.mid = mid
	local unit = arrow:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	unit:SetPoint("TOP", mid, "BOTTOM", 0, 1)
	unit:SetText("yd")
	arrow.unit = unit
	local t = arrow:CreateTexture(nil, "ARTWORK")
	ns.NoSnap(t)
	t:SetPoint("CENTER")
	-- the game's own navigation arrow (as its waypoint marker uses), else ours (media/arrow.tga)
	ns.arrowArt = "game"
	if not ns.Atlas(t, "Navigation-Tracked-Arrow", 40, 40) then
		ns.arrowArt = "own"
		t:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\arrow")
		t:SetSize(40, 40)
	end
	arrow.tex = t
	local bw, bh = t:GetSize()
	arrow.big = { bw or 40, bh or bw or 40 }
	local done = arrow:CreateTexture(nil, "ARTWORK")
	done:SetPoint("CENTER")
	-- you're there: the game's map pin, else ours
	if not ns.Atlas(done, "Waypoint-MapPin-Tracked", 30, 30) then
		done:SetSize(30, 30)
		done:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\pin")
	end
	done:Hide()
	arrow.done = done
	local txt = arrow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	txt:SetPoint("TOP", arrow, "BOTTOM", 0, 2)
	arrow.text = txt
	local sub = arrow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	sub:SetPoint("TOP", txt, "BOTTOM", 0, -2)
	sub:SetWidth(320)
	arrow.sub = sub
	ns.UIReset()
	ns.ArrowLayout()
	-- every frame: turn smoothly; 10 times a second: where to point and how far
	arrow:SetScript("OnUpdate", function(self, el)
		self.t = (self.t or 0) + el
		if self.t >= 0.05 then
			self.t = 0
			if not ns.Safe("arrow", ns.Point) then self:SetScript("OnUpdate", nil); return end
		end
		ns.Turn(el)
	end)
end

-- ring style: small arrow on the ring's edge, distance inside; plain: the big arrow alone
function ns.ArrowLayout()
	if not arrow then return end
	local ring = ns.ArrowStyle() == "ring"
	local w, h = arrow.big[1], arrow.big[2]
	if ring then w, h = w * 0.5, h * 0.5 end
	arrow.tex:SetSize(w, h)
	arrow.tex:ClearAllPoints()
	arrow.tex:SetPoint("CENTER")
	arrow.tex:SetVertexColor(1, 1, 1)
	arrow.angle = nil
	arrow.ring:SetShown(ring)
	arrow.mark:SetShown(ring)
	arrow.mid:SetText("")
	arrow.unit:Hide()
	arrow:SetSize(ring and 56 or 52, ring and 56 or 52)
	-- ring: the step in white under it (the distance is inside); plain: the distance in gold
	if arrow.text.SetFontObject then arrow.text:SetFontObject(ring and "GameFontHighlight" or "GameFontNormal") end
end

-- 127 / 1.2k
local function Yards(d)
	d = math.floor(d + 0.5)
	if d < 1000 then return tostring(d) end
	return string.format("%.1fk", d / 1000)
end

function ns.UIReset()
	if not arrow then return end
	arrow:ClearAllPoints()
	local p = JunhotsTravelDB.arrow
	if p then arrow:SetPoint(p[1], UIParent, p[2] or p[1], p[3], p[4])
	else arrow:SetPoint("TOP", UIParent, "TOP", 0, -140) end
end

local function MakePanel()
	panel = CreateFrame("Frame", "JunhotsTravelPanel", UIParent, "BackdropTemplate")
	panel:SetSize(300, 40)
	panel:SetPoint("TOP", arrow.sub, "BOTTOM", 0, -6)
	if panel.SetBackdrop then
		panel:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
		panel:SetBackdropColor(0.06, 0.05, 0.04, 0.85)
		panel:SetBackdropBorderColor(0.55, 0.43, 0.2)
	end
	panel:Hide()
	panel:SetShown(JunhotsTravelDB.panel ~= false)
end

local function Line(i)
	local l = lines[i]
	if not l then
		l = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		l:SetJustifyH("LEFT")
		l:SetWidth(280)
		l:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, -8 - (i - 1) * 16)
		lines[i] = l
	end
	return l
end

function ns.TogglePanel()
	if not panel then return end
	JunhotsTravelDB.panel = not panel:IsShown()
	ns.Refresh()
end

local KIND = { hearth = "|cff66ccff", fly = "|cff66dd66", boat = "|cff66aaff", zeppelin = "|cff66aaff", tram = "|cff66aaff", lift = "|cff66aaff", portal = "|cffcc88ff", passage = "|cffcc88ff" }

-- step list + arrow words
function ns.Refresh()
	if not arrow then return end
	local g = S.goal
	ns.Safe("map", ns.Draw)
	arrow:SetShown(g ~= nil)
	if not g then panel:Hide(); return end
	local ring = ns.ArrowStyle() == "ring"
	arrow.done:SetShown(S.arrived == true)
	arrow.tex:SetShown(not S.arrived)
	arrow.ring:SetShown(ring and not S.arrived)
	arrow.mark:SetShown(ring and not S.arrived)
	if S.arrived or not S.plan or UnitOnTaxi("player") then arrow.mid:SetText(""); arrow.unit:Hide() end
	local n = 0
	if S.arrived then
		arrow.text:SetText("You're there")
		arrow.sub:SetText(g.name or "")
	elseif UnitOnTaxi("player") then
		arrow.text:SetText("Flying to " .. (S.flying or "your flight point"))
		arrow.sub:SetText("")
		arrow.tex:Hide()
	elseif not S.plan then
		arrow.text:SetText("No way found")
		arrow.sub:SetText(g.name or "")
	else
		ns.Point()
		for i, leg in ipairs(S.plan.legs) do
			n = n + 1
			local c = KIND[leg.k] or "|cffffd100"
			Line(n):SetText(c .. i .. ".|r " .. P.Say(leg, S.plan.legs[i + 1]) .. "  |cff999999" .. P.Time(leg.secs) .. "|r")
		end
	end
	if ns.KnownCount() == 0 then
		n = n + 1
		Line(n):SetText("|cffff8866Open any flight master's map once so I know your flight points.|r")
	end
	if S.plan and #S.plan.legs > 1 then
		n = n + 1
		Line(n):SetText("|cff999999All the way: " .. P.Time(S.plan.secs) .. "|r")
	end
	for i = 1, #lines do lines[i]:SetShown(i <= n) end
	panel:SetHeight(16 + n * 16)
	panel:SetShown(JunhotsTravelDB.panel ~= false and n > 0)
end

-- the step in a few words, without the compass direction (the arrow shows that)
local function Short(l, nxt)
	return (P.Say(l, nxt):gsub("^(%a+) %a+ to ", "%1 to "))
end

-- where the arrow points (bearing from north) and the words under it
function ns.Point()
	local ring = ns.ArrowStyle() == "ring"
	if not S.plan or S.arrived or UnitOnTaxi("player") then arrow.bearing = nil; return end
	local l = S.plan.legs[1]
	local spot = ns.NextSpot()
	local here = ns.Here()
	if not (l and spot and here) or spot.map ~= here.map then
		arrow.bearing = nil
		arrow.tex:SetAlpha(ring and 0 or 0.3)
		arrow.ring:SetAlpha(0.4)
		arrow.mid:SetText("")
		arrow.unit:Hide()
		arrow.text:SetText(l and P.Say(l, S.plan.legs[2]) or "")
		arrow.sub:SetText("")
		return
	end
	arrow.bearing = atan2(spot.y - here.y, spot.x - here.x) -- counter-clockwise from north, like facing
	if l.k == "walk" then
		-- big: how far; small: where to
		arrow.tex:SetAlpha(1)
		arrow.ring:SetAlpha(1)
		if ring then
			-- distance inside the ring, the step under it
			arrow.mid:SetText(Yards(P.dist(here, spot)))
			arrow.unit:Show()
			arrow.text:SetText(Short(l, S.plan.legs[2]))
			arrow.sub:SetText("")
		else
			arrow.text:SetText(math.floor(P.dist(here, spot) + 0.5) .. " yd")
			arrow.sub:SetText(Short(l, S.plan.legs[2]))
		end
	else
		-- at the start of a flight, boat or portal: nothing to point at
		arrow.tex:SetAlpha(ring and 0 or 0.3)
		arrow.ring:SetAlpha(0.4)
		arrow.mid:SetText("")
		arrow.unit:Hide()
		arrow.text:SetText(P.Say(l, S.plan.legs[2]))
		arrow.sub:SetText("")
	end
end

-- ease the arrow toward its bearing (the shortest way round)
function ns.Turn(el)
	if not arrow.bearing then arrow.angle = nil; return end
	local facing = GetPlayerFacing()
	if not (facing and canaccess(facing)) then return end
	local want = (arrow.bearing - facing) % TWO
	local a = arrow.angle
	if not a then a = want
	else
		local d = (want - a + pi) % TWO - pi
		if math.abs(d) < 0.001 then a = want else a = (a + d * (1 - exp(-EASE * (el or 0)))) % TWO end
	end
	arrow.angle = a
	arrow.tex:SetRotation(a)
	if ns.ArrowStyle() ~= "ring" then return end
	-- ride the ring's edge, pointing out; glow green as it nears the mark at the top (= facing the right way)
	arrow.tex:ClearAllPoints()
	arrow.tex:SetPoint("CENTER", -math.sin(a) * ORBIT, math.cos(a) * ORBIT)
	local off = math.min(a, TWO - a)
	local k = 1 - math.min(1, math.max(0, (off - 0.1) / 0.3))
	local r, g, b = GOLD[1] + (GREEN[1] - GOLD[1]) * k, GOLD[2] + (GREEN[2] - GOLD[2]) * k, GOLD[3] + (GREEN[3] - GOLD[3]) * k
	arrow.ring:SetVertexColor(r, g, b)
	arrow.mark:SetVertexColor(r, g, b)
end

function ns.UIInit()
	MakeArrow()
	MakePanel()
	ns.Refresh()
end
