-- Fastest way from one spot to another: walking, flights you know, boats, zeppelins, the tram, lifts and portals.
-- Dijkstra over the fixed places in Data.lua plus your start and your goal.
local _, ns = ...
local D = ns.D
local P = {}
ns.Planner = P

local RUN, DETOUR, MAXDIRECT, FLY_START = 7, 1.4, 2500, 10
P.RUN = RUN

local sqrt, floor, atan2, pi = math.sqrt, math.floor, math.atan2, math.pi
local function dist(a, b) local dx, dy = a.x - b.x, a.y - b.y return sqrt(dx * dx + dy * dy) end
P.dist = dist

local function facOk(f, fac) return not f or f == "N" or f == fac end

-- Fixed places, built once: every flight point, dock and portal end.
local places, placeList, flightsFrom, walk, walkMaps, curves
local function Build()
	if places then return end
	places, placeList, flightsFrom, walk, walkMaps, curves = {}, {}, {}, {}, {}, {}
	local function add(p) places[p.key] = p; placeList[#placeList + 1] = p end
	for id, t in pairs(D.taxi) do
		add({ key = "taxi" .. id, map = t[1], x = t[2], y = t[3], taxi = id, name = t[4], fac = t[5], cls = t[6] })
	end
	for id, d in pairs(D.docks) do
		add({ key = "dock" .. id, map = d[1], x = d[2], y = d[3], dock = id, name = d[4] })
	end
	for i, p in ipairs(D.portals) do
		add({ key = "pa" .. i, map = p[4][1], x = p[4][2], y = p[4][3], portal = i, name = p[1] })
		add({ key = "pb" .. i, map = p[5][1], x = p[5][2], y = p[5][3], name = p[1] })
	end
	table.sort(placeList, function(a, b) return a.key < b.key end)
	for _, f in ipairs(D.flights) do
		local list = flightsFrom[f[1]] or {}
		flightsFrom[f[1]] = list
		list[#list + 1] = { to = f[2], secs = f[3] }
		curves[f[1] .. "-" .. f[2]] = f[4]
	end
	-- walking place names in Data -> our place keys (same for taxi/dock; portal ends by position)
	local walkKey = {}
	for k, p in pairs(D.places) do
		walkMaps[p[1]] = true
		if places[k] then
			walkKey[k] = k
		else
			local best, bestD
			for _, q in ipairs(placeList) do
				if q.map == p[1] and q.key:sub(1, 1) == "p" then
					local d = dist(q, { x = p[2], y = p[3] })
					if d < 30 and (not bestD or d < bestD) then best, bestD = q.key, d end
				end
			end
			walkKey[k] = best
		end
	end
	for k, v in pairs(D.walks) do
		local a, b = k:match("^(%S+) (%S+)$")
		local ka, kb = walkKey[a], walkKey[b]
		if ka and kb then
			walk[ka .. " " .. kb] = v[1]
			walk[kb .. " " .. ka] = v[2] or v[1]
		end
	end
end
P.Build = Build
function P.Places() Build() return places end
function P.Curve(a, b) Build() return curves[a .. "-" .. b] end

-- does the straight line p-q cross a wall (a ridge you can't walk over)?
local function cross(ax, ay, bx, by, cx, cy, dx, dy)
	local d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
	local d2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax)
	local d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx)
	local d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx)
	return d1 * d2 < 0 and d3 * d4 < 0
end
function P.Walled(p, q)
	for _, w in ipairs(D.walls or {}) do
		if w[1] == p.map then
			local pts = w[2]
			for i = 1, #pts - 3, 2 do
				if cross(p.x, p.y, q.x, q.y, pts[i], pts[i + 1], pts[i + 2], pts[i + 3]) then return true end
			end
		end
	end
	return false
end

-- If the straight line from p to q crosses a wall, the wall end to go round first (else nil).
function P.Round(p, q)
	local best, bestD
	for _, w in ipairs(D.walls or {}) do
		if w[1] == p.map then
			local pts, hit = w[2], false
			for i = 1, #pts - 3, 2 do
				if cross(p.x, p.y, q.x, q.y, pts[i], pts[i + 1], pts[i + 2], pts[i + 3]) then hit = true break end
			end
			if hit then
				for _, e in ipairs({ { pts[1], pts[2] }, { pts[#pts - 1], pts[#pts] } }) do
					local c = { map = p.map, x = e[1], y = e[2], name = "the way round the ridge" }
					local d = dist(p, c) + dist(c, q)
					if dist(p, c) > 20 and (not bestD or d < bestD) then best, bestD = c, d end
				end
			end
		end
	end
	return best
end

function P.Land(map, x, y)
	for _, l in ipairs(D.lands) do
		if l[1] == map and x >= l[2] and x <= l[3] and y >= l[4] and y <= l[5] then return l[6] end
	end
	return "main" .. map
end

function P.ZoneAt(map, x, y)
	local best, bestA
	for _, z in ipairs(D.zones) do
		if z[2] == map and x >= z[3] and x <= z[4] and y >= z[5] and y <= z[6] then
			local a = (z[4] - z[3]) * (z[6] - z[5])
			if not bestA or a < bestA then best, bestA = z[7], a end
		end
	end
	return best
end

local function taxiOk(id, o)
	local t = D.taxi[id]
	return t and o.known[id] and facOk(t[5], o.fac) and (not t[6] or t[6] == o.cls)
end

-- ---------- walking network (Walk.lua, built from the game's terrain, rocks and buildings) ----------
local W                 -- [map] = { x = {}, y = {}, first = {}, to = {}, cost = {}, grid = {}, n = count }
local GRID = 256
local function key(x, y) return floor(x / GRID) * 100000 + floor(y / GRID) end
local NearNodes
local function BuildWalk()
	if W then return end
	Build()
	W = {}
	for map, g in pairs(ns.W or {}) do
		local w = { x = {}, y = {}, z = {}, first = {}, to = {}, cost = {}, grid = {}, n = #g.n / 3 }
		for i = 1, w.n do
			local x, y = g.n[3 * i - 2], g.n[3 * i - 1]
			w.x[i], w.y[i], w.z[i] = x, y, g.n[3 * i]
			local k = key(x, y)
			local b = w.grid[k] or {}
			w.grid[k] = b
			b[#b + 1] = i
		end
		-- adjacency in flat arrays: edges of node i are first[i] .. first[i + 1] - 1
		local deg = {}
		for i = 1, w.n + 1 do deg[i] = 0 end
		local e = g.e
		for j = 1, #e, 3 do deg[e[j]] = deg[e[j]] + 1; deg[e[j + 1]] = deg[e[j + 1]] + 1 end
		local pos = 1
		for i = 1, w.n + 1 do w.first[i] = pos; pos = pos + deg[i]; deg[i] = w.first[i] end
		for j = 1, #e, 3 do
			local p, q, c = e[j], e[j + 1], e[j + 2]
			w.to[deg[p]], w.cost[deg[p]] = q, c; deg[p] = deg[p] + 1
			w.to[deg[q]], w.cost[deg[q]] = p, c; deg[q] = deg[q] + 1
		end
		-- connected parts: the big ones are the land you can walk; small ones are islands, ledges, rooftops
		local comp, size, c = {}, {}, 0
		for i = 1, w.n do
			if not comp[i] then
				c = c + 1
				local st, cnt = { i }, 0
				comp[i] = c
				while #st > 0 do
					local u = table.remove(st)
					cnt = cnt + 1
					for j = w.first[u], w.first[u + 1] - 1 do
						local v = w.to[j]
						if not comp[v] then comp[v] = c; st[#st + 1] = v end
					end
				end
				size[c] = cnt
			end
		end
		w.main, w.comp, w.size, w.door = {}, comp, size, {}
		W[map] = w
		-- the main land: big parts with a flight master, dock or portal on them (not the sea floor or the void under
		-- the map, which are big too)
		local real = {}
		for _, p in ipairs(placeList) do
			if p.map == map then
				for _, q in ipairs(NearNodes(map, p.x, p.y, 150, 20)) do real[comp[q[1]]] = true end
			end
		end
		for i = 1, w.n do w.main[i] = size[comp[i]] >= 300 and real[comp[i]] or false end
		w.big = 1
		for k = 1, c do if size[k] > size[w.big] then w.big = k end end
	end
end
P.HasWalk = function(map) BuildWalk() return W[map] ~= nil end
P.WalkData = function() BuildWalk() return W end

-- walking-network nodes within r yards of a spot, nearest first (at most k)
function NearNodes(map, x, y, r, k, mainOnly)
	local w = W[map]
	if not w then return {} end
	local out = {}
	local gx0, gx1 = floor((x - r) / GRID), floor((x + r) / GRID)
	local gy0, gy1 = floor((y - r) / GRID), floor((y + r) / GRID)
	for gx = gx0, gx1 do
		for gy = gy0, gy1 do
			local b = w.grid[gx * 100000 + gy]
			if b then
				for _, i in ipairs(b) do
					local dx, dy = w.x[i] - x, w.y[i] - y
					local d = sqrt(dx * dx + dy * dy)
					if d <= r and (not mainOnly or w.main[i]) then out[#out + 1] = { i, d } end
				end
			end
		end
	end
	table.sort(out, function(p, q) return p[2] < q[2] end)
	for i = #out, k + 1, -1 do out[i] = nil end
	return out
end
P.NearNodes = function(map, x, y, r, k) BuildWalk() return NearNodes(map, x, y, r, k) end

-- binary heap of { cost, node }
local function push(h, c, v)
	local n = #h + 1
	h[n] = { c, v }
	while n > 1 do
		local p = floor(n / 2)
		if h[p][1] <= h[n][1] then break end
		h[p], h[n] = h[n], h[p]
		n = p
	end
end
local function pop(h)
	local top = h[1]
	local n = #h
	h[1] = h[n]; h[n] = nil; n = n - 1
	local i = 1
	while true do
		local l, r, m = 2 * i, 2 * i + 1, i
		if l <= n and h[l][1] < h[m][1] then m = l end
		if r <= n and h[r][1] < h[m][1] then m = r end
		if m == i then break end
		h[i], h[m] = h[m], h[i]
		i = m
	end
	return top
end

local LINK = 300   -- yards: how far a spot looks for the walking network (straight, around ridges you can't cross)
local LINKF = 1.15 -- a straight bit is a little longer on the ground

-- The nodes a spot steps onto: the 4 nearest within LINK, and the 2 nearest on the main land (so a spot on a ledge or
-- an island still reaches everything). Returns { { node, yards } }.
local PLAT = 40   -- yards: a spot this close to a raised or sunken part with a lift (Thunder Bluff, Undercity) stays on it
local CLIFF = 6   -- cost factor for stepping off such a part straight onto the main land
local function Links(map, x, y, swim)
	local out, seen = {}, {}
	-- on a part with a lift and nothing on the main land nearer: that part, and the main land only as a last resort
	-- (no straight jump up or down a cliff when the lift goes there)
	local w, plat = W[map], nil
	if w then
		for _, q in ipairs(NearNodes(map, x, y, PLAT, 12)) do
			if w.main[q[1]] then break end
			local c = w.comp[q[1]]
			if w.door[c] and w.size[c] >= 5 then plat = c; break end
		end
	end
	if plat then
		for _, r in ipairs(NearNodes(map, x, y, LINK, 40)) do
			if w.comp[r[1]] == plat and #out < 4 then out[#out + 1] = { r[1], r[2] * LINKF }; seen[r[1]] = true end
		end
	else
		for _, q in ipairs(NearNodes(map, x, y, LINK, 4)) do out[#out + 1] = { q[1], q[2] * LINKF }; seen[q[1]] = true end
	end
	local main = NearNodes(map, x, y, LINK, 2, true)
	if #main == 0 then main = NearNodes(map, x, y, 2000, 2, true) end
	for _, q in ipairs(main) do
		if not seen[q[1]] then out[#out + 1] = { q[1], q[2] * (plat and CLIFF or q[2] > LINK and DETOUR or LINKF) } end
	end
	-- last resort for a spot cut off from everything: swim to the nearest main land
	if swim then
		for _, q in ipairs(NearNodes(map, x, y, 6000, 2, true)) do out[#out + 1] = { q[1], q[2], true } end
		-- and the continent's biggest part (a spot on a cut-off part still gets somewhere)
		local n = 0
		for _, q in ipairs(NearNodes(map, x, y, 6000, 1000000, true)) do
			if w.comp[q[1]] == w.big and n < 2 then n = n + 1; out[#out + 1] = { q[1], q[2], true } end
		end
	end
	return out
end

-- Fixed places <-> walking network, worked out once: place.wlinks = { { map, node, yards } }, W[map].pl[node] = { { place, yards } }
local linked
local function LinkPlaces()
	if linked then return end
	linked = true
	-- lifts first: the top links to the highest part next to it, the bottom to the lowest (both have the same x, y)
	local function liftLinks(p, w)
		local top = p.name and p.name:find("%(top%)")
		local best
		for _, q in ipairs(NearNodes(p.map, p.x, p.y, 60, 30)) do
			local i = q[1]
			if (w.main[i] or w.size[w.comp[i]] >= 5) and (not best or (top and w.z[i] > w.z[best[1]]) or (not top and w.z[i] < w.z[best[1]])) then best = q end
		end
		if best then w.door[w.comp[best[1]]] = true; return { { best[1], best[2] * LINKF } } end
		return {}
	end
	local function isLift(p) return p.name and (p.name:find("%(top%)") or p.name:find("%(bottom%)")) end
	for _, p in ipairs(placeList) do p.lift = W[p.map] and isLift(p) and true or nil end
	for pass = 1, 2 do
	for _, p in ipairs(placeList) do
		local w = W[p.map]
		if w and (pass == 1) == (isLift(p) and true or false) then
			w.pl = w.pl or {}
			p.wlinks = {}
			for _, q in ipairs(pass == 1 and liftLinks(p, w) or Links(p.map, p.x, p.y)) do
				local n = { map = p.map, x = w.x[q[1]], y = w.y[q[1]] }
				if not P.Walled(p, n) then
					local yd = q[2]
					p.wlinks[#p.wlinks + 1] = { q[1], yd }
					local l = w.pl[q[1]] or {}
					w.pl[q[1]] = l
					l[#l + 1] = { p, yd }
				end
			end
		end
	end
	end
end

P.Links = function(map, x, y, swim) BuildWalk() LinkPlaces() return Links(map, x, y, swim) end

-- a, b = { map, x, y }. o = { known = { [taxiId] = true }, fac = "A"|"H", cls = "DRUID"..., speed = yd/s }
-- Returns { secs, legs = { { k = "walk"|"fly"|"boat"|..., from = place, to = place, secs, a, b, via, path } } }
-- Node ids: "S", "T", place keys ("taxi23"), walk nodes "w<map>:<i>".
function P.Route(a, b, o)
	Build(); BuildWalk(); LinkPlaces()
	local speed = o.speed or RUN
	local S = { key = "S", map = a.map, x = a.x, y = a.y }
	local T = { key = "T", map = b.map, x = b.x, y = b.y, name = b.name }
	local nodeOf = { S = S, T = T }
	local function wnode(map, i)
		local k = "w" .. map .. ":" .. i
		local n = nodeOf[k]
		if not n then
			local w = W[map]
			n = { key = k, map = map, x = w.x[i], y = w.y[i], wmap = map, wi = i }
			nodeOf[k] = n
		end
		return n
	end
	local land = {}
	local function landOf(n) local l = land[n.key] if not l then l = P.Land(n.map, n.x, n.y); land[n.key] = l end return l end
	-- the goal's links, looked up when a node is expanded
	local toT = {}
	if W[T.map] then
		for _, p in ipairs(Links(T.map, T.x, T.y, o.swim)) do
			local n = wnode(T.map, p[1])
			if not P.Walled(n, T) then toT[n.key] = p[3] and p[2] * 2.5 or p[2] end
		end
		-- fixed places right next to the goal
		for _, p in ipairs(placeList) do
			if p.map == T.map and not p.lift and dist(p, T) <= LINK and not P.Walled(p, T) then toT[p.key] = dist(p, T) * LINKF end
		end
	end
	local best, prev, done, heap = { S = 0 }, {}, {}, {}
	push(heap, 0, "S")
	local function relax(u, v, c, leg)
		local d = best[u] + c
		local old = best[v.key]
		if not old or d < old then
			nodeOf[v.key] = v
			best[v.key] = d
			prev[v.key] = { u, leg }
			push(heap, d, v.key)
		end
	end
	local WALK = { k = "walk" }
	local function walkTo(u, v, yd, swim) relax(u, v, (swim and yd * 2.5 or yd) / speed, swim and { k = "walk", swim = true } or WALK) end
	local nearT = {}
	do
		local list = {}
		for _, p in ipairs(placeList) do if p.map == T.map and landOf(p) == landOf(T) then list[#list + 1] = { dist(p, T), p } end end
		table.sort(list, function(x, y) return x[1] < y[1] end)
		for m = 1, math.min(4, #list) do nearT[list[m][2].key] = true end
	end
	while #heap > 0 do
		local top = pop(heap)
		local uk = top[2]
		if not done[uk] and top[1] <= best[uk] then
			done[uk] = true
			if uk == "T" then break end
			local u = nodeOf[uk]
			local hasW = W[u.map] ~= nil
			-- straight to the goal when close, or the goal has no walking network
			if u.map == T.map and (toT[uk] or (not W[T.map] and (dist(u, T) <= MAXDIRECT or nearT[uk] or uk == "S"))) then
				local c = toT[uk] or dist(u, T) * DETOUR
				if toT[uk] or not P.Walled(u, T) then walkTo(uk, T, c) end
			end
			if uk == "S" and u.map == T.map and dist(u, T) <= LINK and not P.Walled(u, T) then walkTo(uk, T, dist(u, T) * LINKF) end
			if u.wi then
				-- along the walking network
				local w = W[u.wmap]
				for j = w.first[u.wi], w.first[u.wi + 1] - 1 do
					walkTo(uk, wnode(u.wmap, w.to[j]), w.cost[j])
				end
				-- onto fixed places next to this node
				for _, p in ipairs((w.pl and w.pl[u.wi]) or {}) do walkTo(uk, p[1], p[2]) end
			elseif hasW then
				-- start or fixed place: step onto the walking network
				if u == S then
					for _, p in ipairs(Links(u.map, u.x, u.y, o.swim)) do
						local n = wnode(u.map, p[1])
						if not P.Walled(u, n) then walkTo(uk, n, p[2], p[3]) end
					end
					-- standing next to a flight master, dock or portal
					for _, p in ipairs(placeList) do
						if p.map == S.map and not p.lift and dist(p, S) <= LINK and not P.Walled(p, S) then walkTo(uk, p, dist(p, S) * LINKF) end
					end
				else
					for _, q in ipairs(u.wlinks or {}) do walkTo(uk, wnode(u.map, q[1]), q[2]) end
				end
			end
			-- fixed places on maps without a walking network: the old way (walking costs between places, straight bits)
			if not hasW then
				for _, m in ipairs(placeList) do
					if m.map == u.map and not done[m.key] and m ~= u then
						local swim = landOf(m) ~= landOf(u)
						local c
						if u ~= S and walkMaps[u.map] then
							c = walk[uk .. " " .. m.key]
							if not c and dist(u, m) < 60 then c = 0 end
						elseif dist(u, m) <= MAXDIRECT then
							c = dist(u, m) * DETOUR
						end
						if c and (not swim or o.swim) then walkTo(uk, m, c, swim) end
					end
				end
			end
			-- flights between flight points you know
			if u.taxi and taxiOk(u.taxi, o) then
				local pl = prev[uk]
				for _, f in ipairs(flightsFrom[u.taxi] or {}) do
					if taxiOk(f.to, o) then
						local start = (pl and pl[2].k == "fly") and 0 or FLY_START
						relax(uk, places["taxi" .. f.to], f.secs + start, { k = "fly", a = u.taxi, b = f.to })
					end
				end
			end
			-- boats, zeppelins, lifts, tram: ride time + half the time between departures
			if u.dock then
				for _, r in ipairs(D.routes) do
					if facOk(r[2], o.fac) then
						local st, i0 = r[4], nil
						for i = 1, #st do if st[i][1] == u.dock then i0 = i break end end
						if i0 then
							for j = 1, #st - 1 do
								local s = st[(i0 - 1 + j) % #st + 1]
								local ride = ((s[2] - st[i0][3]) % r[3]) / 1000
								local v = places["dock" .. s[1]]
								if v then relax(uk, v, ride + r[3] / 2000, { k = r[1], a = u.dock, b = s[1] }) end
							end
						end
					end
				end
			end
			if u.portal then
				local p = D.portals[u.portal]
				if facOk(p[3], o.fac) then relax(uk, places["pb" .. u.portal], p[6], { k = p[2], n = p[1] }) end
			end
		end
	end
	if not best.T then
		if o.swim then
			-- nothing joins the two: point straight at the goal (same continent only)
			if S.map ~= T.map then return nil end
			local secs = dist(S, T) * DETOUR / speed
			return { secs = secs, legs = { { k = "walk", from = S, to = T, secs = secs, path = { S, T }, cum = { 0, secs } } } }
		end
		local o2 = {}
		for k, v in pairs(o) do o2[k] = v end
		o2.swim = true
		return P.Route(a, b, o2)
	end
	local legs = {}
	local v = "T"
	while prev[v] do
		local u, leg = prev[v][1], prev[v][2]
		local l = {}
		for k2, v2 in pairs(leg) do l[k2] = v2 end
		l.from, l.to, l.secs = nodeOf[u], nodeOf[v], best[v] - best[u]
		table.insert(legs, 1, l)
		v = u
	end
	-- join walks in a row (path = the spots you walk through), and flights in a row (one flight with stops)
	local out = {}
	for _, l in ipairs(legs) do
		local last = out[#out]
		if last and last.k == "walk" and l.k == "walk" then
			last.secs, last.to, last.swim = last.secs + l.secs, l.to, last.swim or l.swim
			last.path[#last.path + 1] = l.to
			last.cum[#last.cum + 1] = last.secs
		elseif last and last.k == "fly" and l.k == "fly" then
			last.via[#last.via + 1] = last.b
			last.hops[#last.hops + 1] = { l.a, l.b }
			last.b, last.to, last.secs = l.b, l.to, last.secs + l.secs
		else
			if l.k == "fly" then l.via, l.hops = {}, { { l.a, l.b } } end
			if l.k == "walk" then l.path, l.cum = { l.from, l.to }, { 0, l.secs } end
			out[#out + 1] = l
		end
	end
	local shown = {}
	for _, l in ipairs(out) do
		if not (l.k == "walk" and l.secs < 1) then shown[#shown + 1] = l end
	end
	return { secs = best.T, legs = shown }
end

local DIRS = { "north", "northwest", "west", "southwest", "south", "southeast", "east", "northeast" }
-- world x grows north, world y grows west
function P.Dir(a, b)
	local ang = atan2(b.y - a.y, b.x - a.x)
	return DIRS[(floor(ang / (pi / 4) + 0.5) % 8) + 1]
end

local function town(id) return (D.taxi[id][4]:match("^([^,]+)")) end
P.Town = town

function P.Time(s)
	s = floor(s + 0.5)
	if s < 60 then return s .. " sec" end
	local m = floor(s / 60 + 0.5)
	if m < 60 then return m .. " min" end
	return floor(m / 60) .. " h " .. (m % 60) .. " min"
end

-- Plain words for one leg, e.g. "Fly to Crossroads". nxt = the leg after it (names what you walk to).
local RIDE = { boat = "boat", zeppelin = "zeppelin", tram = "Deeprun Tram", lift = "lift" }
function P.Say(l, nxt)
	if l.k == "fly" then
		local s = "Fly to " .. town(l.b)
		if #l.via > 0 then s = s .. " (" .. #l.via .. (#l.via == 1 and " stop" or " stops") .. " on the way)" end
		return s
	elseif l.k == "boat" or l.k == "zeppelin" then
		return "Take the " .. l.k .. " to " .. (D.docks[l.b][4] or "the next dock")
	elseif l.k == "tram" then
		return "Take the Deeprun Tram"
	elseif l.k == "lift" then
		return "Take the lift"
	elseif l.k == "portal" or l.k == "passage" then
		return "Take the " .. (l.n or "portal")
	end
	local verb = l.swim and "Swim" or "Run"
	local to = l.to
	local what
	if nxt and nxt.k == "fly" then what = "the flight master in " .. town(nxt.a)
	elseif nxt and RIDE[nxt.k] then what = "the " .. RIDE[nxt.k] .. (D.docks[nxt.a] and D.docks[nxt.a][4] and nxt.k ~= "tram" and nxt.k ~= "lift" and (" in " .. D.docks[nxt.a][4]) or "")
	elseif nxt and (nxt.k == "portal" or nxt.k == "passage") then what = "the " .. (nxt.n or "portal")
	else what = to.name or P.ZoneAt(to.map, to.x, to.y) or "your goal" end
	return verb .. " " .. P.Dir(l.from, to) .. " to " .. what
end
