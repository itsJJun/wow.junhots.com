-- Fastest way from one spot to another: walking, flights you know, boats, zeppelins, the tram, lifts and portals.
-- Dijkstra over the fixed places in Data.lua plus your start and your goal.
local _, ns = ...
local D = ns.D
local P = {}
ns.Planner = P

local RUN, DETOUR, MAXDIRECT, FLY_START = 7, 1.4, 2500, 10
P.RUN = RUN

local sqrt, floor, atan2, pi = math.sqrt, math.floor, math.atan2, math.pi
-- hand back to the game when this frame's time is used (Core: ns.Pause; nothing when run on its own)
local function Pause() if ns.Pause then ns.Pause() end end
local function dist(a, b) local dx, dy = a.x - b.x, a.y - b.y return sqrt(dx * dx + dy * dy) end
P.dist = dist

local function facOk(f, fac) return not f or f == "N" or f == fac end

-- Fixed places, built once: every flight point, dock and portal end.
local places, placeList, flightsFrom, walk, walkMaps, curves
local function Build()
	if places then return end
	places, placeList, flightsFrom, walk, walkMaps, curves = {}, {}, {}, {}, {}, {}
	local function add(p) places[p.key] = p; placeList[#placeList + 1] = p end
	for id, t in pairs(D.taxi) do
		add({ key = "taxi" .. id, map = t[1], x = t[2], y = t[3], z = t.z, taxi = id, name = t[4], fac = t[5], cls = t[6] })
	end
	for id, d in pairs(D.docks) do
		add({ key = "dock" .. id, map = d[1], x = d[2], y = d[3], z = d.z, dock = id, name = d[4] })
	end
	for i, p in ipairs(D.portals) do
		add({ key = "pa" .. i, map = p[4][1], x = p[4][2], y = p[4][3], portal = i, name = p[1] })
		add({ key = "pb" .. i, map = p[5][1], x = p[5][2], y = p[5][3], name = p[1] })
	end
	table.sort(placeList, function(a, b) return a.key < b.key end)
	for _, f in ipairs(D.flights) do
		local list = flightsFrom[f[1]] or {}
		flightsFrom[f[1]] = list
		list[#list + 1] = { to = f[2], secs = f[3] }
		curves[f[1] .. "-" .. f[2]] = f[4]
	end
	-- walking place names in Data -> our place keys (same for taxi/dock; portal ends by position)
	local walkKey = {}
	for k, p in pairs(D.places) do
		walkMaps[p[1]] = true
		if places[k] then
			walkKey[k] = k
		else
			local best, bestD
			for _, q in ipairs(placeList) do
				if q.map == p[1] and q.key:sub(1, 1) == "p" then
					local d = dist(q, { x = p[2], y = p[3] })
					if d < 30 and (not bestD or d < bestD) then best, bestD = q.key, d end
				end
			end
			walkKey[k] = best
		end
	end
	for k, v in pairs(D.walks) do
		local a, b = k:match("^(%S+) (%S+)$")
		local ka, kb = walkKey[a], walkKey[b]
		if ka and kb then
			walk[ka .. " " .. kb] = v[1]
			walk[kb .. " " .. ka] = v[2] or v[1]
		end
	end
end
P.Build = Build
-- ---------- the game's own flight routes ----------
-- Pick a far flight point on the flight map and the game picks the stops on the way itself (it flies through them).
-- Routes you saw on your flight map win (saved by Map.lua: [from][to] = { stop, stop, ..., to }). Any other trip
-- follows the rule that fits every route seen so far: fewest seconds, each stop costing ROUTE_PEN seconds more
-- (Map.lua fits it; Jun's 28 Nov flight proves at least 15: the game flew Orgrimmar -> Gadgetzan direct, 417 s,
-- over Orgrimmar -> Crossroads -> Freewind -> Gadgetzan, 388 s).
local savedRoutes, ROUTE_PEN = nil, 15
local RELAND = 60   -- getting off midway and taking a new flight: only when that saves a minute
local routeCache = setmetatable({}, { __mode = "k" })
function P.SetFlightRoutes(routes, pen)
	savedRoutes = routes
	if pen then ROUTE_PEN = pen end
	routeCache = setmetatable({}, { __mode = "k" })
end
function P.RoutePen() return ROUTE_PEN end
local function edgeSecs(a, b)
	for _, f in ipairs(flightsFrom[a] or {}) do if f.to == b then return f.secs end end
end
-- the rule: every flight from a over the stops ok(id) allows, as { [to] = { secs, hops = { stop, ..., to } } }
local function RuleRoutes(a, ok, pen)
	local cost, secs, stops, prev, done = { [a] = 0 }, { [a] = 0 }, { [a] = 0 }, {}, {}
	while true do
		local u, cu
		for k, c in pairs(cost) do
			if not done[k] and (not cu or c < cu - 1e-6 or (c < cu + 1e-6 and (stops[k] < stops[u] or (stops[k] == stops[u] and k < u)))) then u, cu = k, c end
		end
		if not u then break end
		done[u] = true
		if u == a or ok(u) then
			for _, f in ipairs(flightsFrom[u] or {}) do
				local v = f.to
				if v ~= a and ok(v) and not done[v] then
					local c = cu + f.secs + pen
					local cv = cost[v]
					if not cv or c < cv - 1e-6 or (c < cv + 1e-6 and stops[u] + 1 < stops[v]) then
						cost[v], secs[v], stops[v], prev[v] = c, secs[u] + f.secs, stops[u] + 1, u
					end
				end
			end
		end
	end
	local out = {}
	for v in pairs(prev) do
		local hops, w = {}, v
		while w ~= a do table.insert(hops, 1, w); w = prev[w] end
		out[v] = { secs = secs[v], hops = hops }
	end
	return out
end
P.RuleRoutes = function(a, ok, pen) Build() return RuleRoutes(a, ok, pen or ROUTE_PEN) end
-- a saved route as { secs, hops } (nil when a stop of it is not a flight we know of)
local function SavedRoute(a, b)
	local r = savedRoutes and savedRoutes[a] and savedRoutes[a][b]
	if type(r) ~= "table" or #r == 0 or r[#r] ~= b then return nil end
	local t, u = 0, a
	for _, v in ipairs(r) do
		local s = edgeSecs(u, v)
		if not s then return nil end
		t, u = t + s, v
	end
	return { secs = t, hops = r, seen = true }
end
-- every flight the game would fly you from taxi node a (known = the flight points you know), sorted by where to
local function GameRoutes(a, known, okFn)
	-- cached per list of known flight points (the list grows in place: its size tells when it changed)
	local byKnown = known and routeCache[known]
	if known then
		local n = 0
		for _ in pairs(known) do n = n + 1 end
		if not byKnown or byKnown.n ~= n then byKnown = { n = n }; routeCache[known] = byKnown end
	end
	local list = byKnown and byKnown[a]
	if list then return list end
	local ok = okFn or function(id) return not known or known[id] end
	local rr = RuleRoutes(a, ok, ROUTE_PEN)
	list = {}
	for v, r in pairs(rr) do list[#list + 1] = SavedRoute(a, v) and { to = v, secs = SavedRoute(a, v).secs, hops = SavedRoute(a, v).hops, seen = true } or { to = v, secs = r.secs, hops = r.hops } end
	-- a saved route to a place the rule can't reach with what you know now (a stop's faction or class): still yours
	if savedRoutes and savedRoutes[a] then
		for v in pairs(savedRoutes[a]) do
			if not rr[v] and ok(v) then
				local r = SavedRoute(a, v)
				if r then list[#list + 1] = { to = v, secs = r.secs, hops = r.hops, seen = true } end
			end
		end
	end
	table.sort(list, function(x, y) return x.to < y.to end)
	if byKnown then byKnown[a] = list end
	return list
end
P.GameRoutes = GameRoutes
-- The game's route from taxi node a to b: { secs, hops = { stop, ..., b }, seen = saved from your flight map }
function P.GameRoute(a, b, known)
	Build()
	local r = SavedRoute(a, b)
	if r then return r end
	local rr = RuleRoutes(a, function(id) return id == b or not known or known[id] end, ROUTE_PEN)
	return rr[b]
end
-- How long the flight the game gives you from a to b takes (seconds)
function P.FlyTime(a, b, known, rate)
	local r = P.GameRoute(a, b, known)
	return r and r.secs / (rate or 1) or nil
end
function P.Places() Build() return places end
function P.Curve(a, b) Build() return curves[a .. "-" .. b] end

-- does the straight line p-q cross a wall (a ridge you can't walk over)?
local function cross(ax, ay, bx, by, cx, cy, dx, dy)
	local d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
	local d2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax)
	local d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx)
	local d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx)
	return d1 * d2 < 0 and d3 * d4 < 0
end
function P.Walled(p, q)
	for _, w in ipairs(D.walls or {}) do
		if w[1] == p.map then
			local pts = w[2]
			for i = 1, #pts - 3, 2 do
				if cross(p.x, p.y, q.x, q.y, pts[i], pts[i + 1], pts[i + 2], pts[i + 3]) then return true end
			end
		end
	end
	return false
end

-- If the straight line from p to q crosses a wall, the wall end to go round first (else nil).
function P.Round(p, q)
	local best, bestD
	for _, w in ipairs(D.walls or {}) do
		if w[1] == p.map then
			local pts, hit = w[2], false
			for i = 1, #pts - 3, 2 do
				if cross(p.x, p.y, q.x, q.y, pts[i], pts[i + 1], pts[i + 2], pts[i + 3]) then hit = true break end
			end
			if hit then
				for _, e in ipairs({ { pts[1], pts[2] }, { pts[#pts - 1], pts[#pts] } }) do
					local c = { map = p.map, x = e[1], y = e[2], name = "the way round the ridge" }
					local d = dist(p, c) + dist(c, q)
					if dist(p, c) > 20 and (not bestD or d < bestD) then best, bestD = c, d end
				end
			end
		end
	end
	return best
end

function P.Land(map, x, y)
	for _, l in ipairs(D.lands) do
		if l[1] == map and x >= l[2] and x <= l[3] and y >= l[4] and y <= l[5] then return l[6] end
	end
	return "main" .. map
end

function P.ZoneAt(map, x, y)
	local best, bestA
	for _, z in ipairs(D.zones) do
		if z[2] == map and x >= z[3] and x <= z[4] and y >= z[5] and y <= z[6] then
			local a = (z[4] - z[3]) * (z[6] - z[5])
			if not bestA or a < bestA then best, bestA = z[7], a end
		end
	end
	return best
end

local function taxiUsable(id, o)
	local t = D.taxi[id]
	return t and facOk(t[5], o.fac) and (not t[6] or t[6] == o.cls)
end
local function taxiOk(id, o) return o.known[id] and taxiUsable(id, o) end

-- ---------- danger: zones far above your level, the other side's towns ----------
local HEARTH_CAST, LOADING, HEARTH_MIN = 10, 5, 600   -- a Hearthstone (an hour's cooldown) must save 10 minutes: never spent to win a few minutes
local TOWN = 6                                       -- walking through the other side's town costs 6x
-- cost factor for walking in a zone whose lowest level is `over` levels above yours: from 5 levels up, 6x at 10
local function overFactor(over) if over < 5 then return 1 end return 1 + 5 * math.min(1, (over - 4) / 6) end
P.overFactor = overFactor

-- ---------- walking network (Walk.lua, built from the game's terrain, rocks and buildings) ----------
local W                 -- [map] = { x = {}, y = {}, first = {}, to = {}, cost = {}, grid = {}, n = count }
local GRID = 256
local function key(x, y) return floor(x / GRID) * 100000 + floor(y / GRID) end
local NearNodes
local function BuildWalk()
	if W then return end
	Build()
	W = {}
	for map, g in pairs(ns.W or {}) do
		local w = { x = {}, y = {}, z = {}, first = {}, to = {}, cost = {}, grid = {}, n = #g.n / 3 }
		for i = 1, w.n do
			local x, y = g.n[3 * i - 2], g.n[3 * i - 1]
			w.x[i], w.y[i], w.z[i] = x, y, g.n[3 * i]
			local k = key(x, y)
			local b = w.grid[k] or {}
			w.grid[k] = b
			b[#b + 1] = i
		end
		-- adjacency in flat arrays: edges of node i are first[i] .. first[i + 1] - 1
		local deg = {}
		for i = 1, w.n + 1 do deg[i] = 0 end
		local e = g.e
		for j = 1, #e, 3 do deg[e[j]] = deg[e[j]] + 1; deg[e[j + 1]] = deg[e[j + 1]] + 1 end
		local d = g.d or {}   -- one way only: down a ledge
		for j = 1, #d, 4 do deg[d[j]] = deg[d[j]] + 1 end
		local pos = 1
		for i = 1, w.n + 1 do w.first[i] = pos; pos = pos + deg[i]; deg[i] = w.first[i] end
		-- wcost: what the way is chosen by (off-road yards count a bit more, from the game's road textures)
		local k = g.k
		w.wcost = k and {} or w.cost
		w.via, w.ei, w.ap = g.v or {}, {}, g.ap or {}   -- via[edge] = corners of a winding way; ei[slot] = edge (negative: walked backwards)
		for j = 1, #e, 3 do
			local p, q, c = e[j], e[j + 1], e[j + 2]
			local wc = k and k[(j + 2) / 3] or c
			local ei = (j + 2) / 3
			w.to[deg[p]], w.cost[deg[p]], w.ei[deg[p]] = q, c, ei; if k then w.wcost[deg[p]] = wc end; deg[p] = deg[p] + 1
			w.to[deg[q]], w.cost[deg[q]], w.ei[deg[q]] = p, c, -ei; if k then w.wcost[deg[q]] = wc end; deg[q] = deg[q] + 1
		end
		-- drops: edge numbers after the two-way ones (their corners in via too); drop[slot] = true
		w.drop = {}
		local ne = #e / 3
		for j = 1, #d, 4 do
			local p, q, c, wc = d[j], d[j + 1], d[j + 2], d[j + 3]
			local ei = ne + (j + 3) / 4
			if g.dv and g.dv[(j + 3) / 4] then w.via[ei] = g.dv[(j + 3) / 4] end
			w.to[deg[p]], w.cost[deg[p]], w.ei[deg[p]] = q, c, ei; if k then w.wcost[deg[p]] = wc end
			w.drop[deg[p]] = true; deg[p] = deg[p] + 1
		end
		-- connected parts: the big ones are the land you can walk; small ones are islands, ledges, rooftops
		local comp, size, c = {}, {}, 0
		for i = 1, w.n do
			if not comp[i] then
				c = c + 1
				local st, cnt = { i }, 0
				comp[i] = c
				while #st > 0 do
					local u = table.remove(st)
					cnt = cnt + 1
					for j = w.first[u], w.first[u + 1] - 1 do
						local v = w.to[j]
						if not comp[v] and not w.drop[j] then comp[v] = c; st[#st + 1] = v end
					end
				end
				size[c] = cnt
			end
		end
		w.main, w.comp, w.size, w.door = {}, comp, size, {}
		w.zone, w.town = g.z or {}, g.t or {}   -- per node: D.zones index, 1 Alliance town / 2 Horde town
		-- per node: true = something you can walk on is high above it (in a cave, tunnel, building, the Undercity)
		-- per node: on a road
		if g.r then
			w.road = {}
			for i = 1, w.n do w.road[i] = g.r[i] == 1 end
		end
		if g.c then
			w.cover = {}
			for i = 1, w.n do w.cover[i] = g.c[i] == 1 end
		end
		W[map] = w
		-- the main land: big parts with a flight master, dock or portal on them (not the sea floor or the void under
		-- the map, which are big too)
		local real = {}
		for _, p in ipairs(placeList) do
			if p.map == map then
				for _, q in ipairs(NearNodes(map, p.x, p.y, 150, 20)) do real[comp[q[1]]] = true end
			end
		end
		for i = 1, w.n do w.main[i] = size[comp[i]] >= 300 and real[comp[i]] or false end
		w.big = 1
		for k = 1, c do if size[k] > size[w.big] then w.big = k end end
	end
end
P.HasWalk = function(map) BuildWalk() return W[map] ~= nil end
P.WalkData = function() BuildWalk() return W end

-- walking-network nodes within r yards of a spot, nearest first (at most k)
function NearNodes(map, x, y, r, k, mainOnly)
	local w = W[map]
	if not w then return {} end
	local out = {}
	local gx0, gx1 = floor((x - r) / GRID), floor((x + r) / GRID)
	local gy0, gy1 = floor((y - r) / GRID), floor((y + r) / GRID)
	if k > 64 then
		for gx = gx0, gx1 do
			Pause()
			for gy = gy0, gy1 do
				local b = w.grid[gx * 100000 + gy]
				if b then
					for _, i in ipairs(b) do
						local dx, dy = w.x[i] - x, w.y[i] - y
						local d = sqrt(dx * dx + dy * dy)
						if d <= r and (not mainOnly or w.main[i]) then out[#out + 1] = { i, d } end
					end
				end
			end
		end
		table.sort(out, function(p, q) return p[2] < q[2] end)
		for i = #out, k + 1, -1 do out[i] = nil end
		return out
	end
	-- only the k nearest are kept as it goes (sorting every node in a wide circle is slow)
	local n = 0
	for gx = gx0, gx1 do
		Pause()
		for gy = gy0, gy1 do
			local b = w.grid[gx * 100000 + gy]
			if b then
				for _, i in ipairs(b) do
					local dx, dy = w.x[i] - x, w.y[i] - y
					local d2 = dx * dx + dy * dy
					if d2 <= r * r and (n < k or d2 < out[n][3]) and (not mainOnly or w.main[i]) then
						local at = n < k and n + 1 or n
						while at > 1 and out[at - 1][3] > d2 do out[at] = out[at - 1]; at = at - 1 end
						out[at] = { i, sqrt(d2), d2 }
						if n < k then n = n + 1 end
					end
				end
			end
		end
	end
	return out
end
P.NearNodes = function(map, x, y, r, k) BuildWalk() return NearNodes(map, x, y, r, k) end

-- the nearest walking node within r of (x, y) (walkable ground there), or nil
local function Ground(map, x, y, r)
	local w = W[map]
	local best, bestD = nil, r * r
	local gx0, gx1 = floor((x - r) / GRID), floor((x + r) / GRID)
	local gy0, gy1 = floor((y - r) / GRID), floor((y + r) / GRID)
	for gx = gx0, gx1 do
		for gy = gy0, gy1 do
			local b = w.grid[gx * 100000 + gy]
			if b then
				for _, i in ipairs(b) do
					local dx, dy = w.x[i] - x, w.y[i] - y
					local d = dx * dx + dy * dy
					if d <= bestD then best, bestD = i, d end
				end
			end
		end
	end
	return best
end

-- how far spot q is from the straight line a-b (yards)
local ROADKEEP = 20
P.ROADKEEP = ROADKEEP
function P.SegDist(q, a, b)
	local dx, dy = b.x - a.x, b.y - a.y
	local L = dx * dx + dy * dy
	local t = L > 0 and math.max(0, math.min(1, ((q.x - a.x) * dx + (q.y - a.y) * dy) / L)) or 0
	local ex, ey = a.x + dx * t - q.x, a.y + dy * t - q.y
	return sqrt(ex * ex + ey * ey)
end
function P.OnRoad(q) local w = q.wi and W[q.wmap or q.map] return w and w.road and w.road[q.wi] or false end
-- Can you run straight from a to b (same map)? No ridge in the way, ground under it, and clear of walls,
-- buildings and rocks (the fine walking detail). For the arrow looking ahead along your way.
function P.CanRun(a, b)
	if a.map ~= b.map then return false end
	BuildWalk()
	local map = a.map
	if not W[map] or P.Walled(a, b) then return false end
	local d = dist(a, b)
	local n = floor(d / 48)
	for k = 1, n do
		local t = k / (n + 1)
		if not Ground(map, a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, 100) then return false end
	end
	if ns.Ras and ns.Ras.Has(map) and not ns.Ras.Clear(map, a.x, a.y, b.x, b.y, 2) then return false end
	return true
end
-- is this spot of a walk under something (a cave, tunnel, the Undercity)?
function P.Covered(q)
	if q.via then return true end   -- on a winding way (stairs, a ramp): follow it, never cut across
	local w = q.wi and W[q.wmap or q.map] return w and w.cover and w.cover[q.wi] or false
end
-- Inside, below a flight master up a tower (Orgrimmar's stairs): the real way up from where you stand, as spots
-- (the last is the flight master's own spot), and its yards. nil when no way up starts within 12 yd of you.
local function ApproachFrom(p, u)
	local w = W[p.map]
	local ways = w and w.ap and p.taxi and w.ap[p.taxi]
	if not ways then return nil end
	local best, bd
	for _, v in ipairs(ways) do
		local d = dist(u, { x = v[1], y = v[2] })
		if d <= 12 and (not bd or d < bd) then best, bd = v, d end
	end
	if not best then return nil end
	local spots, yd, prevp = {}, bd, { x = best[1], y = best[2] }
	for i = 1, #best / 3 do
		local q = { map = p.map, x = best[3 * i - 2], y = best[3 * i - 1], z = best[3 * i], via = true }
		yd = yd + dist(prevp, q); prevp = q
		spots[#spots + 1] = q
	end
	return spots, yd
end
P.ApproachFrom = ApproachFrom
-- the corners of the walking network's way from node a to node b when it winds (stairs, a ramp, round a ridge)
local function ViaSpots(map, a, b)
	local w = W[map]
	if not (w and w.via) then return nil end
	for j = w.first[a], w.first[a + 1] - 1 do
		if w.to[j] == b then
			local ei = w.ei[j]
			local v = w.via[ei < 0 and -ei or ei]
			if not v then return nil end
			local out, n = {}, #v / 3
			for m = 1, n do
				local i = ei > 0 and m or (n - m + 1)
				out[m] = { map = map, x = v[3 * i - 2], y = v[3 * i - 1], z = v[3 * i], via = true }
			end
			return out
		end
	end
end

-- Straighten a walk: the walking network is a grid of spots about 128 yd apart, so in open ground its way zig-zags.
-- Go straight from a spot to a later one when the network's own way between them is hardly longer than the straight
-- line (no mountain or lake to go round) and there is ground under the whole straight line.
local STRAIGHT = 1.2   -- the network's way may be at most this much longer than straight
-- The steps onto and off the walking network (from where you stand, to the goal) are straight lines: where one
-- crosses a wall (a palisade round a camp), go round it on the fine wall map, so the map shows the real way in
-- (from where you stand the arrow finds its own way round, worked out as you move: only the other ends here, kept
-- between replans so a replan every few seconds costs nothing)
local roundCache, roundN = {}, 0
local function RoundEnds(path, cum)
	local R = ns.Ras
	if not (R and #path >= 2) then return path, cum, 0 end
	local np, nc, extra = { path[1] }, { cum[1] }, 0
	for k = 2, #path do
		Pause()
		local a, b = path[k - 1], path[k]
		local free = k > 2 and (not (a.wi or a.via) or not (b.wi or b.via))
		local d = dist(a, b)
		if free and a.map == b.map and R.Has(a.map) and d <= 400 then
			local key = a.map .. ":" .. floor(a.x / 4) .. ":" .. floor(a.y / 4) .. ":" .. floor(b.x / 4) .. ":" .. floor(b.y / 4)
			local hit = roundCache[key]
			if not hit then
				hit = { false }
				if not R.Clear(a.map, a.x, a.y, b.x, b.y, 2) then
					local w, y2 = R.Way(a.map, a.x, a.y, b.x, b.y)
					if w then hit = { w, y2 } end
				end
				if roundN > 200 then roundCache, roundN = {}, 0 end
				roundCache[key], roundN = hit, roundN + 1
			end
			local way, yd = hit[1] or nil, hit[2]
			if way and #way > 1 then
				-- the same pace as the straight step, over the longer way
				local secs = (cum[k] - cum[k - 1]) * math.max(1, (yd or d) / math.max(d, 1))
				local tot, pp = 0, a
				for _, q in ipairs(way) do tot = tot + dist(pp, q); pp = q end
				local acc; acc, pp = 0, a
				for i = 1, #way - 1 do
					local q = way[i]
					acc = acc + dist(pp, q); pp = q
					np[#np + 1] = { map = a.map, x = q.x, y = q.y }
					nc[#nc + 1] = cum[k - 1] + extra + (tot > 0 and secs * acc / tot or 0)
				end
				extra = extra + secs - (cum[k] - cum[k - 1])
			end
		end
		np[#np + 1], nc[#nc + 1] = b, cum[k] + extra
	end
	return np, nc, extra
end
local function Straighten(path, cum, hz)
	if #path < 3 then return path, cum end
	local map = path[1].map
	if not W[map] then return path, cum end
	local along = { 0 }
	for k = 2, #path do along[k] = along[k - 1] + (path[k].map == path[k - 1].map and dist(path[k], path[k - 1]) or 1e9) end
	local function ok(i, j)
		Pause()
		local a, b = path[i], path[j]
		if a.map ~= map or b.map ~= map then return false end
		local d = dist(a, b)
		if along[j] - along[i] > d * STRAIGHT + 20 then return false end
		if P.Walled(a, b) then return false end
		-- along a road: keep to it (a road spot is only left out when the straight line passes close by it)
		local wm = W[map]
		if wm.road then
			for k = i + 1, j - 1 do
				local q = path[k]
				if q.wi and wm.road[q.wi] and P.SegDist(q, a, b) > ROADKEEP then return false end
			end
		end
		-- a winding way's corners (stairs, ramps): keep them all
		for k = i + 1, j - 1 do if path[k].via then return false end end
		-- under something (a cave, a tunnel, the Undercity): follow the walking map, which knows the floors
		if wm.cover then
			for k = i, j do
				local q = path[k]
				if q.wi and wm.cover[q.wi] then return false end
			end
		end
		-- no more danger on the straight line than on the way it replaces
		local worst = 1
		if hz then for k = i, j do if path[k].wi then worst = math.max(worst, hz(path[k].wi)) end end end
		local n = floor(d / 48)
		for k = 1, n do
			local t = k / (n + 1)
			local g = Ground(map, a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, 100)
			if not g or (hz and hz(g) > worst) then return false end
		end
		-- fine detail (walls, buildings, rocks): the straight line must be clear all the way
		if ns.Ras and ns.Ras.Has(map) and not ns.Ras.Clear(map, a.x, a.y, b.x, b.y, 2) then return false end
		return true
	end
	local np, nc, i = { path[1] }, { cum[1] }, 1
	while i < #path do
		local j = i + 1
		for k = math.min(#path, i + 40), i + 2, -1 do
			if ok(i, k) then j = k; break end
		end
		np[#np + 1], nc[#nc + 1] = path[j], cum[j]
		i = j
	end
	return np, nc
end

-- binary heap of { cost, node }
local function push(h, c, v)
	local n = #h + 1
	h[n] = { c, v }
	while n > 1 do
		local p = floor(n / 2)
		if h[p][1] <= h[n][1] then break end
		h[p], h[n] = h[n], h[p]
		n = p
	end
end
local function pop(h)
	local top = h[1]
	local n = #h
	h[1] = h[n]; h[n] = nil; n = n - 1
	local i = 1
	while true do
		local l, r, m = 2 * i, 2 * i + 1, i
		if l <= n and h[l][1] < h[m][1] then m = l end
		if r <= n and h[r][1] < h[m][1] then m = r end
		if m == i then break end
		h[i], h[m] = h[m], h[i]
		i = m
	end
	return top
end

local LINK = 300   -- yards: how far a spot looks for the walking network (straight, around ridges you can't cross)
local LINKF = 1.15 -- a straight bit is a little longer on the ground

-- The nodes a spot steps onto: the 4 nearest within LINK, and the 2 nearest on the main land (so a spot on a ledge or
-- an island still reaches everything). Returns { { node, yards } }.
-- walking spots with floors above them close by (inside the Undercity, a cave, a building)
local function CoveredNear(map, x, y)
	local w = W[map]
	if not (w and w.cover) then return false end
	for _, q in ipairs(NearNodes(map, x, y, 30, 8)) do if w.cover[q[1]] then return true end end
	return false
end
-- Which floor you are on, inside (the game gives no height): the walking spot near you on the floor you were on a
-- moment ago (prevZ), else on the floor of `hint` (your planned way, a flight master or lift you stand at), else the
-- only floor there is. nil = can't tell.
function P.Floor(map, x, y, prevZ, hint)
	BuildWalk()
	local w = W[map]
	if not (w and w.cover) then return nil end
	local near = NearNodes(map, x, y, 16, 24)
	if #near == 0 then return nil end
	local function closest(z)
		local best, bd
		for _, q in ipairs(near) do
			local d = math.abs(w.z[q[1]] - z)
			if not bd or d < bd then best, bd = w.z[q[1]], d end
		end
		return best, bd
	end
	if prevZ then local z, d = closest(prevZ); if d <= 8 then return z end end
	if hint then local z, d = closest(hint); if d <= 8 then return z end end
	local lo, hi = math.huge, -math.huge
	for _, q in ipairs(near) do local z = w.z[q[1]]; lo, hi = math.min(lo, z), math.max(hi, z) end
	if hi - lo <= 4 then return (lo + hi) / 2 end
	return nil
end
-- The height of a goal standing where floors lie above each other (someone in the Undercity, a cave): the spawn
-- (Heights.lua) within 4 yd of it. nil = not such a place, or not a known spawn.
local hgrid = {}
function P.SpawnZ(map, x, y)
	local H = ns.Heights and ns.Heights[map]
	if not H then return nil end
	local g = hgrid[map]
	if not g then
		g = {}
		for i = 1, #H, 3 do
			local k = floor(H[i] / 16) * 100000 + floor(H[i + 1] / 16)
			g[k] = g[k] or {}
			table.insert(g[k], i)
		end
		hgrid[map] = g
	end
	local best, bd = nil, 16
	local cx, cy = floor(x / 16), floor(y / 16)
	for a = cx - 1, cx + 1 do
		for b = cy - 1, cy + 1 do
			for _, i in ipairs(g[a * 100000 + b] or {}) do
				local dx, dy = H[i] - x, H[i + 1] - y
				local d = dx * dx + dy * dy
				if d <= bd then best, bd = H[i + 2], d end
			end
		end
	end
	return best
end
-- Outside: about the height of the land you stand on (the main walking network's spot nearest you, within 64 yd),
-- so where a town stands on floors over the land under it (Orgrimmar) the arrow follows the town's floor
local GZ = {}
function P.GroundZ(map, x, y)
	-- the same answer within 3 yd of the last ask
	if GZ.map == map and (GZ.x - x) ^ 2 + (GZ.y - y) ^ 2 < 9 then return GZ.z end
	GZ.map, GZ.x, GZ.y, GZ.z = map, x, y, P.GroundZ1(map, x, y)
	return GZ.z
end
function P.GroundZ1(map, x, y)
	BuildWalk()
	local w = W[map]
	if not w then return nil end
	local q = NearNodes(map, x, y, 64, 1, true)[1]
	return q and w.z[q[1]] or nil
end
-- the height of a spot of a plan (a walking spot, or a place that knows it)
function P.SpotZ(q)
	if not q then return nil end
	if q.wi then local w = W[q.wmap or q.map]; return w and w.z[q.wi] end
	return q.z
end
local INSIDE = 14  -- yards: inside, a spot steps onto walking spots this close only
local NEXTTO = 12  -- yards: this close to a flight master, dock or portal you are at it
local PLAT = 40   -- yards: a spot this close to a raised or sunken part with a lift (Thunder Bluff, Undercity) stays on it
local CLIFF = 6   -- cost factor for stepping off such a part straight onto the main land
-- On two levels (a cave or tunnel under the ground, the Undercity under its ruins): `under` true = you are below
-- something, false = in the open, nil = not known. "Covered" nodes have ground you can walk on high above them.
-- Below something: the lowest covered floor near you (the Undercity, not the ruins' halls above it). In the open: no
-- covered nodes. Either way only when the other kind is not all there is.
local function Near(map, x, y, r, k, under, mainOnly, z)
	local w = W[map]
	-- a place whose height we know (a flight master): nodes on its floor
	if z and w and w.cover then
		local out = {}
		for _, q in ipairs(NearNodes(map, x, y, r, k * 6, mainOnly)) do
			if math.abs(w.z[q[1]] - z) < 10 and #out < k then out[#out + 1] = q end
		end
		if #out > 0 or mainOnly then return out end
	end
	if under == nil or not (w and w.cover) then return NearNodes(map, x, y, r, k, mainOnly) end
	-- your floor: the lowest covered one close by (not a deeper tunnel further off)
	local low, near
	if under then
		for _, q in ipairs(NearNodes(map, x, y, math.min(r, 120), 24)) do
			if w.cover[q[1]] then
				near = near or q[2]
				if q[2] <= math.max(40, near + 20) and (not low or w.z[q[1]] < low) then low = w.z[q[1]] end
			end
		end
	end
	local all = NearNodes(map, x, y, r, k * 6, mainOnly)
	local out = {}
	for _, q in ipairs(all) do
		local c = w.cover[q[1]]
		local keep
		if under then keep = low == nil or (c and w.z[q[1]] < low + 12)
		else keep = c == false end
		if keep and #out < k then out[#out + 1] = q end
	end
	-- nothing on your level: anything near (but never the main land of another floor)
	if #out == 0 and not (mainOnly and under and low) then for i = 1, math.min(k, #all) do out[i] = all[i] end end
	return out
end
local function Links(map, x, y, swim, under, z)
	local out, seen = {}, {}
	-- on a part with a lift and nothing on the main land nearer: that part, and the main land only as a last resort
	-- (no straight jump up or down a cliff when the lift goes there)
	local w, plat = W[map], nil
	if w then
		for _, q in ipairs(Near(map, x, y, PLAT, 12, under, nil, z)) do
			if w.main[q[1]] then break end
			local c = w.comp[q[1]]
			if w.door[c] and w.size[c] >= 5 then plat = c; break end
		end
	end
	if plat then
		for _, r in ipairs(NearNodes(map, x, y, LINK, 40)) do
			if w.comp[r[1]] == plat and #out < 4 then out[#out + 1] = { r[1], r[2] * LINKF }; seen[r[1]] = true end
		end
	else
		for _, q in ipairs(Near(map, x, y, LINK, 4, under, nil, z)) do out[#out + 1] = { q[1], q[2] * LINKF }; seen[q[1]] = true end
	end
	local main = Near(map, x, y, LINK, 2, under, true, z)
	if #main == 0 and not ((under or z) and w and w.cover) then main = NearNodes(map, x, y, 2000, 2, true) end
	for _, q in ipairs(main) do
		if not seen[q[1]] then out[#out + 1] = { q[1], q[2] * (plat and CLIFF or q[2] > LINK and DETOUR or LINKF) } end
	end
	-- inside (the Undercity, a cave): its walking spots are close together, and a longer straight step there goes
	-- through a wall or over a canal. Only the near ones (the nearest if none is that near).
	if under == true and w and w.cover and #out > 1 and CoveredNear(map, x, y) then
		local near, best = {}, nil
		for _, q in ipairs(out) do
			if q[2] <= INSIDE * LINKF then near[#near + 1] = q end
			if not best or q[2] < best[2] then best = q end
		end
		out = #near > 0 and near or { best }
	end
	-- last resort for a spot cut off from everything: swim to the nearest main land
	if swim then
		for _, q in ipairs(NearNodes(map, x, y, 6000, 2, true)) do out[#out + 1] = { q[1], q[2], true } end
		-- and the continent's biggest part (a spot on a cut-off part still gets somewhere)
		local n = 0
		for _, q in ipairs(NearNodes(map, x, y, 6000, 1000000, true)) do
			if w.comp[q[1]] == w.big and n < 2 then n = n + 1; out[#out + 1] = { q[1], q[2], true } end
		end
	end
	return out
end

-- Fixed places <-> walking network, worked out once: place.wlinks = { { map, node, yards } }, W[map].pl[node] = { { place, yards } }
local linked
local function LinkPlaces()
	if linked then return end
	linked = true
	-- lifts first: the top links to the highest part next to it, the bottom to the lowest (both have the same x, y)
	local function liftLinks(p, w)
		local top = p.name and p.name:find("%(top%)")
		local best
		for _, q in ipairs(NearNodes(p.map, p.x, p.y, 60, 30)) do
			local i = q[1]
			-- a lift that knows its floor height joins only that floor (12 yd), never the floor at its other end
			local floorOk = not p.z or math.abs(w.z[i] - p.z) < 12
			if floorOk and (w.main[i] or w.size[w.comp[i]] >= 5) then
				if p.z then
					-- its own floor: the walking spot nearest its height (then nearest it)
					local sc = math.abs(w.z[i] - p.z) * 3 + q[2]
					if not best or sc < best.sc then best = { q[1], q[2], sc = sc } end
				elseif not best or (top and w.z[i] > w.z[best[1]]) or (not top and w.z[i] < w.z[best[1]]) then best = q end
			end
		end
		if best then w.door[w.comp[best[1]]] = true; return { { best[1], best[2] * LINKF } } end
		return {}
	end
	local function isLift(p) return p.name and (p.name:find("%(top%)") or p.name:find("%(bottom%)")) end
	for _, p in ipairs(placeList) do p.lift = W[p.map] and isLift(p) and true or nil end
	for pass = 1, 2 do
	for _, p in ipairs(placeList) do
		local w = W[p.map]
		if w and (pass == 1) == (isLift(p) and true or false) then
			w.pl = w.pl or {}
			p.wlinks = {}
			for _, q in ipairs(pass == 1 and liftLinks(p, w) or Links(p.map, p.x, p.y, nil, nil, p.z)) do
				local n = { map = p.map, x = w.x[q[1]], y = w.y[q[1]] }
				if not P.Walled(p, n) then
					local yd = q[2]
					p.wlinks[#p.wlinks + 1] = { q[1], yd }
					local l = w.pl[q[1]] or {}
					w.pl[q[1]] = l
					l[#l + 1] = { p, yd }
				end
			end
		end
	end
	end
end

P.Links = function(map, x, y, swim, under, z) BuildWalk() LinkPlaces() return Links(map, x, y, swim, under, z) end
-- the walking network and its links to flight masters, docks and portals, built once (at login, under the loading screen)
P.Warm = function() BuildWalk() LinkPlaces() end

-- a, b = { map, x, y }. o = { known = { [taxiId] = true }, fac = "A"|"H", cls = "DRUID"..., speed = yd/s,
--   flyRate = your flight speed / the normal one (learned from your flights),
--   level = your level (walks go round zones far above it), hearth = { map, x, y, name, wait } (bind point, cooldown left) }
-- Returns { secs, legs = { { k = "walk"|"fly"|"boat"|..., from = place, to = place, secs, a, b, via, path } } }
-- Node ids: "S", "T", place keys ("taxi23"), walk nodes "w<map>:<i>".
local WalkNotes   -- below
-- a lift's ends only join its own floor; but down below (the Undercity) its bottom is a way out
local function LiftOk(p, under) return not p.lift or (under == true and p.name and p.name:find("%(bottom%)") ~= nil) end

local RouteOnce
-- A plan with a Hearthstone, boat or zeppelin on one continent: if flights and walking alone do the trip, that wins
-- (Jun: "there is no way anyone would go into trouble instead of direct flight"), unless it is 15+ minutes slower.
local DIRECT_SLACK = 900
function P.Route(a, b, o)
	local r = RouteOnce(a, b, o)
	if not r or o.noRide or a.map ~= b.map then return r end
	local ride = false
	for _, l in ipairs(r.legs) do if l.k == "hearth" and not (l.spell and not l.cd) or l.k == "boat" or l.k == "zeppelin" then ride = true end end
	if not ride then return r end
	local o2 = {}
	for k, v in pairs(o) do o2[k] = v end
	o2.noRide = true
	local r2 = RouteOnce(a, b, o2)
	if not r2 then return r end
	local fly = false
	for _, l in ipairs(r2.legs) do if l.k == "fly" then fly = true end end
	if fly and r2.secs <= r.secs + DIRECT_SLACK then return r2 end
	return r
end
function RouteOnce(a, b, o)
	Build(); BuildWalk(); LinkPlaces()
	local speed = o.speed or RUN
	local S = { key = "S", map = a.map, x = a.x, y = a.y, free = true, under = a.under, z = a.z }
	local T = { key = "T", map = b.map, x = b.x, y = b.y, name = b.name }
	-- a goal on a floor (someone in the Undercity): its height, so the way ends on that floor
	local spawnZ = not b.z and not o.flat and not o.noSpawnZ and P.SpawnZ(b.map, b.x, b.y) or nil
	T.z = b.z or spawnZ
	local tUnder = b.under
	if T.z and tUnder == nil then tUnder = true end
	local nodeOf = { S = S, T = T }
	local H = o.hearth and { key = "H", map = o.hearth.map, x = o.hearth.x, y = o.hearth.y, name = o.hearth.name, free = true }
	-- danger on a walking node (cost factor): zones far above your level, the other side's towns.
	-- The zones (and towns) you start and end in never count.
	local hz = {}
	local enemy, zf
	do
		enemy = o.fac == "H" and 1 or o.fac == "A" and 2 or nil
		zf = {}
		for i, z in ipairs(D.zones) do zf[i] = o.level and overFactor((z[8] or 0) - o.level) or 1 end
		local function tagsAt(p)
			local w = W[p.map]
			if not w then return nil end
			local q = NearNodes(p.map, p.x, p.y, 300, 1)[1]
			if q then return w.zone[q[1]], w.town[q[1]] end
		end
		local sz, st = tagsAt(S)
		local tz, tt = tagsAt(T)
		if sz then zf[sz] = 1 end
		if tz then zf[tz] = 1 end
		if st == enemy or tt == enemy then enemy = nil end
		for map, w in pairs(W) do
			hz[map] = function(i)
				local f = zf[w.zone[i] or 0] or 1
				if enemy and w.town[i] == enemy and f < TOWN then f = TOWN end
				return f
			end
		end
	end
	-- (walking spots are keyed by a number, not a string: a long plan looks at thousands, every 4 seconds)
	local function wnode(map, i)
		local k = (map + 1) * 1000000 + i
		local n = nodeOf[k]
		if not n then
			local w = W[map]
			n = { key = k, map = map, x = w.x[i], y = w.y[i], wmap = map, wi = i }
			nodeOf[k] = n
		end
		return n
	end
	local land = {}
	local function landOf(n) local l = land[n.key] if not l then l = P.Land(n.map, n.x, n.y); land[n.key] = l end return l end
	-- the goal's links, looked up when a node is expanded
	local toT = {}
	if W[T.map] then
		for _, p in ipairs(Links(T.map, T.x, T.y, o.swim, tUnder, T.z)) do
			local n = wnode(T.map, p[1])
			if not P.Walled(n, T) then toT[n.key] = p[3] and p[2] * 2.5 or p[2] end
		end
		-- fixed places right next to the goal (inside, on floors: only when right next to it, else the walking
		-- network knows the way; a straight line there crosses a wall or a canal)
		local inside = tUnder == true and CoveredNear(T.map, T.x, T.y)
		for _, p in ipairs(placeList) do
			local floorOk = not (T.z and p.z and math.abs(p.z - T.z) > 12)
			if p.map == T.map and LiftOk(p, tUnder) and floorOk and dist(p, T) <= (inside and NEXTTO or LINK) and not P.Walled(p, T) then toT[p.key] = dist(p, T) * LINKF end
		end
	end
	-- best = cost (time, plus the extra for danger and the Hearthstone's bar), tim = the real time
	-- (prev: the node before (prevU) and the step from it (prevL); the heap in two arrays: no new table per step)
	local best, tim, prevU, prevL, done = { S = 0 }, { S = 0 }, {}, {}, {}
	local hc, hv, hn = {}, {}, 0
	local function hpush(c, v)
		hn = hn + 1
		local n = hn
		while n > 1 do
			local p = floor(n / 2)
			if hc[p] <= c then break end
			hc[n], hv[n] = hc[p], hv[p]
			n = p
		end
		hc[n], hv[n] = c, v
	end
	local function hpop()
		local tc, tv = hc[1], hv[1]
		local lc, lv = hc[hn], hv[hn]
		hc[hn], hv[hn] = nil, nil
		hn = hn - 1
		if hn > 0 then
			local i = 1
			while true do
				local l = 2 * i
				if l > hn then break end
				if l < hn and hc[l + 1] < hc[l] then l = l + 1 end
				if hc[l] >= lc then break end
				hc[i], hv[i] = hc[l], hv[l]
				i = l
			end
			hc[i], hv[i] = lc, lv
		end
		return tc, tv
	end
	hpush(0, "S")
	local function relax(u, v, c, leg, real)
		local d = best[u] + c
		local vk = v.key
		local old = best[vk]
		if not old or d < old then
			nodeOf[vk] = v
			best[vk] = d
			tim[vk] = tim[u] + (real or c)
			prevU[vk], prevL[vk] = u, leg
			hpush(d, vk)
		end
	end
	local WALK = { k = "walk" }
	-- yd = what the way is chosen by, real = the yards you really walk (off-road counts a bit more in yd)
	local function walkTo(u, v, yd, swim, real)
		local t = (swim and yd * 2.5 or yd) / speed
		local f = v.wi and hz[v.wmap] and hz[v.wmap](v.wi) or 1
		relax(u, v, t * f, swim and { k = "walk", swim = true } or WALK, real and real / speed or t)
	end
	local nearT = {}
	do
		local list = {}
		for _, p in ipairs(placeList) do if p.map == T.map and landOf(p) == landOf(T) then list[#list + 1] = { dist(p, T), p } end end
		table.sort(list, function(x, y) return x[1] < y[1] end)
		for m = 1, math.min(4, #list) do nearT[list[m][2].key] = true end
	end
	-- the Hearthstone: cast, loading screen, and any cooldown left; chosen only when it saves HEARTH_MIN
	if H and not o.noRide then
		local t = (o.hearth.wait or 0) + HEARTH_CAST + LOADING
		relax("S", H, t + HEARTH_MIN, { k = "hearth" }, t)
	end
	-- class teleports (o.ports: { map, x, y, name, spell, wait, cd }): cast, loading screen, any cooldown left;
	-- one with a long cooldown (Astral Recall) must save HEARTH_MIN, the others 10 seconds
	for i, p in ipairs(o.ports or {}) do
		local node = { key = "P" .. i, map = p.map, x = p.x, y = p.y, name = p.name, free = true }
		local t = (p.wait or 0) + HEARTH_CAST + LOADING
		if not (o.noRide and p.cd) then relax("S", node, t + (p.cd and HEARTH_MIN or 10), { k = "hearth", spell = p.spell, cd = p.cd }, t) end
	end
	-- o.slice: run as a coroutine, handing back to the game when this frame's few ms are used (no stall while you move)
	local slice, steps = o.slice, 0
	while hn > 0 do
		if slice then
			steps = steps + 1
			if steps % 16 == 0 then Pause() end
		end
		local tc, uk = hpop()
		if not done[uk] and tc <= best[uk] then
			done[uk] = true
			if uk == "T" then break end
			local u = nodeOf[uk]
			local hasW = W[u.map] ~= nil
			-- straight to the goal when close, or the goal has no walking network
			if u.map == T.map and (toT[uk] or (not W[T.map] and (dist(u, T) <= MAXDIRECT or nearT[uk] or u.free))) then
				local c = toT[uk] or dist(u, T) * DETOUR
				if toT[uk] or not P.Walled(u, T) then walkTo(uk, T, c) end
			end
			-- straight from where you stand to the goal when close; not on floors (the Undercity, a cave: a straight line
			-- there crosses a wall or a floor below), where the walking network knows the way, unless right next to it
			if u.free and u.map == T.map and dist(u, T) <= LINK and not P.Walled(u, T)
				and (dist(u, T) <= NEXTTO or not (u.under == true or tUnder == true) or not CoveredNear(u.map, u.x, u.y)) then
				walkTo(uk, T, dist(u, T) * LINKF)
			end
			if u.wi then
				-- along the walking network
				local w = W[u.wmap]
				for j = w.first[u.wi], w.first[u.wi + 1] - 1 do
					walkTo(uk, wnode(u.wmap, w.to[j]), w.wcost[j], nil, w.cost[j])
				end
				-- onto fixed places next to this node
				for _, p in ipairs((w.pl and w.pl[u.wi]) or {}) do walkTo(uk, p[1], p[2]) end
			elseif hasW then
				-- start or fixed place: step onto the walking network
				if u.free then
					local lk = Links(u.map, u.x, u.y, o.swim, u.under, u.z)
					for _, p in ipairs(lk) do
						local n = wnode(u.map, p[1])
						if not P.Walled(u, n) then walkTo(uk, n, p[2], p[3]) end
					end
					-- your floor: the height of the walking spot next to you (on the ground in the ruins, a flight
					-- master deep under you is not a straight step away)
					local W0 = W[u.map]
					local uz = lk[1] and W0.z[lk[1][1]]
					-- standing next to a flight master, dock or portal (inside, below a flight master up a tower: its
					-- stairs instead of a straight line)
					for _, p in ipairs(placeList) do
						-- right next to it (NEXTTO): you are on its floor whatever the walking spot next to you says (the
						-- Undercity's bat handler stands on a ring over the canals, and we can't see your height)
						if p.map == u.map and LiftOk(p, u.under) and dist(p, u) <= LINK and (dist(p, u) <= NEXTTO or not (uz and p.z and math.abs(p.z - uz) > 12)) then
							local ap, apyd = nil, nil
							if u.under == true and dist(p, u) <= 40 and dist(p, u) > NEXTTO then ap, apyd = ApproachFrom(p, u) end
							if ap then
								relax(uk, p, apyd / speed, { k = "walk", ap = ap }, apyd / speed)
							elseif not P.Walled(p, u) then
								walkTo(uk, p, dist(p, u) * LINKF)
							end
						end
					end
				else
					for _, q in ipairs(u.wlinks or {}) do walkTo(uk, wnode(u.map, q[1]), q[2]) end
				end
			end
			-- fixed places on maps without a walking network: the old way (walking costs between places, straight bits)
			if not hasW then
				for _, m in ipairs(placeList) do
					if m.map == u.map and not done[m.key] and m ~= u then
						local swim = landOf(m) ~= landOf(u)
						local c
						if not u.free and walkMaps[u.map] then
							c = walk[uk .. " " .. m.key]
							if not c and dist(u, m) < 60 then c = 0 end
						elseif dist(u, m) <= MAXDIRECT then
							c = dist(u, m) * DETOUR
						end
						if c and (not swim or o.swim) then walkTo(uk, m, c, swim) end
					end
				end
			end
			-- flights between flight points you know
			-- (one you haven't found yet counts too when you walk up to it: you learn it there and fly on)
			local pl = prevL[uk]
			if u.taxi and taxiUsable(u.taxi, o) and (o.known[u.taxi] or (pl and pl.k == "walk")) then
				local new = not o.known[u.taxi]
				-- the game's own route to each flight point (its stops on the way); a flight right after a flight =
				-- getting off and taking a new one
				local start = (pl and pl.k == "fly") and RELAND or FLY_START
				for _, r in ipairs(GameRoutes(u.taxi, o.known, function(id) return taxiOk(id, o) end)) do
					relax(uk, places["taxi" .. r.to], r.secs / (o.flyRate or 1) + start, { k = "fly", a = u.taxi, b = r.to, route = r, learn = new or nil })
				end
			end
			-- boats, zeppelins, lifts, tram: ride time + the wait for the next departure. When we have seen this route's
			-- boat leave (o.phases[route] = server ms of its loop start, o.now = server seconds), the real wait from when
			-- you get to the dock; else half the time between departures.
			if u.dock then
				for ri, r in ipairs(D.routes) do
					if facOk(r[2], o.fac) then
						local st, i0 = r[4], nil
						for i = 1, #st do if st[i][1] == u.dock then i0 = i break end end
						if i0 then
							local wait, live = r[3] / 2000, nil
							local ph = o.phases and o.phases[ri]
							if ph and o.now then
								local at = (o.now * 1000 + tim[uk] * 1000 - ph) % r[3]   -- where the loop is when you get there
								wait = ((st[i0][3] - at) % r[3]) / 1000
								if wait < 4 then wait = wait + r[3] / 1000 end           -- too close to make it on board
								live = tim[uk] + wait                                     -- leaves this many seconds from now
							end
							for j = 1, #st - 1 do
								local s = st[(i0 - 1 + j) % #st + 1]
								local ride = ((s[2] - st[i0][3]) % r[3]) / 1000
								local v = places["dock" .. s[1]]
								local skip = o.noRide and (r[1] == "boat" or r[1] == "zeppelin")
								if v and not skip then relax(uk, v, ride + wait, { k = r[1], a = u.dock, b = s[1], leaves = live }) end
							end
						end
					end
				end
			end
			if u.portal then
				local p = D.portals[u.portal]
				if facOk(p[3], o.fac) then relax(uk, places["pb" .. u.portal], p[6], { k = p[2], n = p[1] }) end
			end
		end
	end
	if not best.T then
		-- nothing to the floor of the person you go to (a spawn's height can be off): try again without it
		if spawnZ then
			local o2 = {}
			for k, v in pairs(o) do o2[k] = v end
			o2.noSpawnZ = true
			return RouteOnce(a, b, o2)
		end
		-- nothing from your floor (the walking map has gaps down there): try again without floors
		if (a.under ~= nil or tUnder ~= nil) and not o.flat then
			local o2, a2, b2 = {}, {}, {}
			for k, v in pairs(o) do o2[k] = v end
			for k, v in pairs(a) do a2[k] = v end
			for k, v in pairs(b) do b2[k] = v end
			o2.flat, a2.under, b2.under = true, nil, nil
			return P.Route(a2, b2, o2)
		end
		if o.swim then
			-- nothing joins the two: point straight at the goal (same continent only)
			if S.map ~= T.map then return nil end
			local secs = dist(S, T) * DETOUR / speed
			return { secs = secs, legs = { { k = "walk", from = S, to = T, secs = secs, path = { S, T }, cum = { 0, secs } } } }
		end
		local o2 = {}
		for k, v in pairs(o) do o2[k] = v end
		o2.swim = true
		return P.Route(a, b, o2)
	end
	local legs = {}
	local v = "T"
	while prevU[v] do
		local u, leg = prevU[v], prevL[v]
		local l = {}
		for k2, v2 in pairs(leg) do l[k2] = v2 end
		l.from, l.to, l.secs = nodeOf[u], nodeOf[v], tim[v] - tim[u]
		table.insert(legs, 1, l)
		v = u
	end
	-- join walks in a row (path = the spots you walk through), and flights in a row (one flight with stops)
	local out = {}
	for _, l in ipairs(legs) do
		local last = out[#out]
		if last and last.k == "walk" and l.k == "walk" then
			local vs = l.from.wi and l.to.wi and l.from.wmap == l.to.wmap and ViaSpots(l.from.wmap, l.from.wi, l.to.wi)
			if vs then
				-- spread the step's time over its corners by distance
				local tot, prevp = 0, l.from
				for _, q in ipairs(vs) do tot = tot + dist(prevp, q); prevp = q end
				tot = tot + dist(prevp, l.to)
				local acc, pp = 0, l.from
				for _, q in ipairs(vs) do
					acc = acc + dist(pp, q); pp = q
					last.path[#last.path + 1] = q
					last.cum[#last.cum + 1] = last.secs + (tot > 0 and l.secs * acc / tot or 0)
				end
			end
			last.secs, last.to, last.swim = last.secs + l.secs, l.to, last.swim or l.swim
			last.path[#last.path + 1] = l.to
			last.cum[#last.cum + 1] = last.secs
		else
			if l.k == "fly" then
				-- via = the stops the game flies you through; hops = each piece of it (for the map)
				local r = l.route or { hops = { l.b } }
				l.via, l.hops, l.seen = {}, {}, r.seen
				local u = l.a
				for i, v in ipairs(r.hops) do
					if i < #r.hops then l.via[#l.via + 1] = v end
					l.hops[#l.hops + 1] = { u, v }
					u = v
				end
				l.route = nil
				-- a flight right after a flight: you get off at the first one's end and take a new flight
				if last and last.k == "fly" then last.land, l.reland = true, true end
			end
			if l.k == "walk" then
				l.path, l.cum = { l.from }, { 0 }
				if l.ap then
					local tot, pp = 0, l.from
					for _, q in ipairs(l.ap) do tot = tot + dist(pp, q); pp = q end
					local acc; acc, pp = 0, l.from
					for i2 = 1, #l.ap - 1 do
						local q = l.ap[i2]
						acc = acc + dist(pp, q); pp = q
						l.path[#l.path + 1] = q
						l.cum[#l.cum + 1] = tot > 0 and l.secs * acc / tot or 0
					end
					l.ap = nil
				end
				l.path[#l.path + 1] = l.to
				l.cum[#l.cum + 1] = l.secs
			end
			out[#out + 1] = l
		end
	end
	for _, l in ipairs(out) do
		if l.k == "walk" and l.path then
			l.notes = WalkNotes(l.path, hz[l.path[1].map], zf, enemy)
			l.path, l.cum = Straighten(l.path, l.cum, l.path[1] and hz[l.path[1].map])
			local extra
			l.path, l.cum, extra = RoundEnds(l.path, l.cum)
			l.secs = l.secs + extra
			tim.T = tim.T + extra
		end
	end
	local shown = {}
	for _, l in ipairs(out) do
		if not (l.k == "walk" and l.secs < 1) then shown[#shown + 1] = l end
	end
	return { secs = tim.T, legs = shown }
end

-- the other side's town at a walking node: the name of its flight master's town ("Crossroads")
local function TownAt(map, x, y, fac)
	local best, bd
	for _, t in pairs(D.taxi) do
		if t[1] == map and t[5] ~= fac and t[5] ~= "N" then
			local dx, dy = t[2] - x, t[3] - y
			local d = dx * dx + dy * dy
			if not bd or d < bd then best, bd = t, d end
		end
	end
	return best and (best[4]:match("^([^,]+)")) or "a hostile town"
end
-- What a walk does about danger, in a few words: "Avoids Duskwood (level 18-30)", "Crosses Wetlands (level 20-30)"
-- (no way round), "Hostile town: Crossroads". Avoided = on the straight line from start to end, but not on the way.
WalkNotes = function(path, hz, zf, enemy)
	if not hz or #path < 2 then return nil end
	local map = path[1].map
	local w = W[map]
	if not w then return nil end
	local crossZ, crossT, seen = {}, {}, {}
	for _, p in ipairs(path) do
		if p.wi and p.map == map then
			local z = w.zone[p.wi]
			if z and (zf[z] or 1) > 1 then crossZ[z] = true end
			if enemy and w.town[p.wi] == enemy then crossT[TownAt(map, p.x, p.y, enemy == 1 and "H" or "A")] = true end
		end
	end
	local notes = {}
	local function zoneText(z) local e = D.zones[z]; return e[7] .. " (level " .. e[8] .. "-" .. e[9] .. ")" end
	local a, b = path[1], path[#path]
	if b.map == map then
		local d = dist(a, b)
		local n = floor(d / 150)
		for k = 1, n do
			Pause()
			local t = k / (n + 1)
			local g = Ground(map, a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, 150)
			if g then
				local z = w.zone[g]
				if z and (zf[z] or 1) > 1 and not crossZ[z] and not seen["z" .. z] then
					seen["z" .. z] = true
					notes[#notes + 1] = "Avoids " .. zoneText(z)
				end
				if enemy and w.town[g] == enemy then
					local name = TownAt(map, w.x[g], w.y[g], enemy == 1 and "H" or "A")
					if not crossT[name] and not seen["t" .. name] then
						seen["t" .. name] = true
						notes[#notes + 1] = "Avoids hostile town: " .. name
					end
				end
			end
		end
	end
	for z in pairs(crossZ) do notes[#notes + 1] = "Crosses " .. zoneText(z) end
	for name in pairs(crossT) do notes[#notes + 1] = "Hostile town: " .. name end
	return #notes > 0 and notes or nil
end

local DIRS = { "north", "northwest", "west", "southwest", "south", "southeast", "east", "northeast" }
-- world x grows north, world y grows west
function P.Dir(a, b)
	local ang = atan2(b.y - a.y, b.x - a.x)
	return DIRS[(floor(ang / (pi / 4) + 0.5) % 8) + 1]
end

local function town(id) return (D.taxi[id][4]:match("^([^,]+)")) end
P.Town = town

function P.Time(s)
	s = floor(s + 0.5)
	if s < 60 then return s .. " sec" end
	local m = floor(s / 60 + 0.5)
	if m < 60 then return m .. " min" end
	return floor(m / 60) .. " h " .. (m % 60) .. " min"
end

-- Plain words for one leg, e.g. "Fly to Crossroads". nxt = the leg after it (names what you walk to).
local RIDE = { boat = "boat", zeppelin = "zeppelin", tram = "Deeprun Tram", lift = "lift" }
function P.Say(l, nxt)
	if l.k == "hearth" then
		if l.spell then return "Cast " .. l.spell .. (l.to.name and not l.spell:find(l.to.name, 1, true) and (" to " .. l.to.name) or "") end
		return "Use your Hearthstone to " .. (l.to.name or "your inn")
	elseif l.k == "fly" then
		local s = (l.learn and "Talk to the flight master to learn it, then fly to " or (l.reland and "Take a new flight to " or "Fly to ")) .. town(l.b)
		if l.land then return s .. " and get off there" end
		if #l.via > 0 then s = s .. " (" .. #l.via .. (#l.via == 1 and " stop" or " stops") .. " on the way)" end
		return s
	elseif l.k == "boat" or l.k == "zeppelin" then
		local s = "Take the " .. l.k .. " to " .. (D.docks[l.b][4] or "the next dock")
		local left = l.leavesAt and GetTime and (l.leavesAt - GetTime()) or l.leaves
		if left and left > 0 then s = s .. " (leaves in " .. P.Time(left) .. ")" end
		return s
	elseif l.k == "tram" then
		return "Take the Deeprun Tram"
	elseif l.k == "lift" then
		return "Take the lift"
	elseif l.k == "portal" or l.k == "passage" then
		return "Take the " .. (l.n or "portal")
	end
	local verb = l.swim and "Swim" or "Run"
	local to = l.to
	local what
	if nxt and nxt.k == "fly" then what = (nxt.learn and "the new flight master in " or "the flight master in ") .. town(nxt.a)
	elseif nxt and RIDE[nxt.k] then what = "the " .. RIDE[nxt.k] .. (D.docks[nxt.a] and D.docks[nxt.a][4] and nxt.k ~= "tram" and nxt.k ~= "lift" and (" in " .. D.docks[nxt.a][4]) or "")
	elseif nxt and (nxt.k == "portal" or nxt.k == "passage") then what = "the " .. (nxt.n or "portal")
	else what = to.name or P.ZoneAt(to.map, to.x, to.y) or "your goal" end
	return verb .. " " .. P.Dir(l.from, to) .. " to " .. what
end
