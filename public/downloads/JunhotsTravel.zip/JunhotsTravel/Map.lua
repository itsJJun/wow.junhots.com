-- Draws your way on the world map: walking (gold), flights along their real curves (green), boats and zeppelins (blue).
local _, ns = ...
local P = ns.Planner
local D = ns.D
local S = ns.state

local COLOR = {
	walk = { 1, 0.85, 0.2, 1 },
	fly = { 0.3, 1, 0.42, 1 },
	boat = { 0.35, 0.7, 1, 0.95 }, zeppelin = { 0.35, 0.7, 1, 0.95 }, tram = { 0.35, 0.7, 1, 0.95 }, lift = { 0.35, 0.7, 1, 0.95 },
	portal = { 0.8, 0.55, 1, 0.95 }, passage = { 0.8, 0.55, 1, 0.95 },
}

-- ---------- smooth lines ----------
-- Douglas-Peucker: drop spots that sit almost on the line between their neighbours (tol in yards)
local function Simplify(pts, tol)
	if #pts < 3 then return pts end
	local keep = { [1] = true, [#pts] = true }
	local stack = { { 1, #pts } }
	while #stack > 0 do
		local r = table.remove(stack)
		local a, b = pts[r[1]], pts[r[2]]
		local dx, dy = b[1] - a[1], b[2] - a[2]
		local len = math.sqrt(dx * dx + dy * dy)
		local far, at = 0, nil
		for k = r[1] + 1, r[2] - 1 do
			local q = pts[k]
			local d = len > 0 and math.abs(dx * (a[2] - q[2]) - dy * (a[1] - q[1])) / len or math.sqrt((q[1] - a[1]) ^ 2 + (q[2] - a[2]) ^ 2)
			if d > far then far, at = d, k end
		end
		if at and far > tol then keep[at] = true; stack[#stack + 1] = { r[1], at }; stack[#stack + 1] = { at, r[2] } end
	end
	local out = {}
	for k = 1, #pts do if keep[k] then out[#out + 1] = pts[k] end end
	return out
end
-- Chaikin corner cutting: rounds the corners (ends stay where they are)
local function Round(pts, times)
	for _ = 1, times do
		if #pts < 3 then return pts end
		local out = { pts[1] }
		for k = 1, #pts - 1 do
			local a, b = pts[k], pts[k + 1]
			out[#out + 1] = { a[1] * 0.75 + b[1] * 0.25, a[2] * 0.75 + b[2] * 0.25 }
			out[#out + 1] = { a[1] * 0.25 + b[1] * 0.75, a[2] * 0.25 + b[2] * 0.75 }
		end
		out[#out + 1] = pts[#pts]
		pts = out
	end
	return pts
end
ns.SmoothLine = function(pts, tol) return Round(Simplify(pts, tol or 12), 3) end
-- spots every `step` along a line of { x, y } (first one `first` in), each given to put(x, y); at most `max`
function ns.Along(pts, step, first, put, max)
	local carry, n = first or step / 2, 0
	for i = 2, #pts do
		local a, b = pts[i - 1], pts[i]
		local dx, dy = b[1] - a[1], b[2] - a[2]
		local len = math.sqrt(dx * dx + dy * dy)
		local d = carry
		while d < len do
			n = n + 1
			if max and n > max then return end
			put(a[1] + dx * d / len, a[2] + dy * d / len)
			d = d + step
		end
		carry = d - len
	end
end
-- the walking way: small spaced dots ("dots", the default) or a thin line ("line")
function ns.TrailStyle() return (JunhotsTravelDB and JunhotsTravelDB.trail) or "dots" end

-- our own art (media/*.tga, made by art/make_art.py): white parts take the colour of the leg
local MEDIA = "Interface\\AddOns\\JunhotsTravel\\media\\"
-- stops wear the game's own map art where the client has it ("atlas:"), else ours
local STOP = { fly = MEDIA .. "stop_fly", boat = MEDIA .. "stop_boat", zeppelin = MEDIA .. "stop_boat" }
local STOP_ATLAS = { boat = "flightmasterferry", zeppelin = "flightmasterferry" }
local function FlyAtlas()
	local f = UnitFactionGroup("player")
	return (f == "Alliance" or f == "Horde") and ("taxinode_" .. f:lower()) or "taxinode_neutral"
end
local CASE = { 0.03, 0.02, 0.005, 0.85 }   -- dark soft edge under every line: stands out on any map colour

-- OpenMap (the seamless world map addon) says where a world spot sits on its stitched map (its read-only OpenMapAPI)
local function OpenMap()
	local api = rawget(_G, "OpenMapAPI")
	if type(api) ~= "table" or api.major ~= 1 or (api.version or 0) < 2 or not api.IsStitched then return nil end
	local ok, on = pcall(api.IsStitched)
	return ok and on == true and api or nil
end
ns.OpenMap = OpenMap

-- We draw on a frame of our own on the map (no data provider: that is a write into the map, which can taint it).
local view, lines, icons, nl, ni = nil, {}, {}, 0, 0
local W, H, mapID, thick, om, scale

local function clear()
	for k = 1, #lines do lines[k]:Hide() end
	for k = 1, #icons do icons[k]:Hide() end
	nl, ni = 0, 0
end

-- world spot -> spot on the canvas (pixels from top left) and its map fractions
local function pos(cont, x, y)
	if om and om.CanvasFromWorldPos then
		local ok, u, v = pcall(om.CanvasFromWorldPos, cont, x, y)
		if ok and type(u) == "number" and type(v) == "number" then return u * W, v * H, u, v end
		return nil
	end
	local _, p = C_Map.GetMapPosFromWorldPos(cont, CreateVector2D(x, y), mapID)
	if not p then return nil end
	local px, py = p:GetXY()
	return px * W, py * H, px, py
end
local function off(a, b)
	if om then return false end   -- the stitched map shows the zones around too; the map itself clips the rest
	return (a[3] < -0.2 and b[3] < -0.2) or (a[3] > 1.2 and b[3] > 1.2) or (a[4] < -0.2 and b[4] < -0.2) or (a[4] > 1.2 and b[4] > 1.2)
end
local function line(layer, sub, ax, ay, bx, by, col, th)
	nl = nl + 1
	local l = lines[nl]
	if not l then l = ns.NoSnap(view:CreateLine(nil, "ARTWORK")); l:SetTexture(MEDIA .. "aa"); lines[nl] = l end
	l:SetDrawLayer(layer, sub)
	l:SetVertexColor(col[1], col[2], col[3], col[4])
	l:SetThickness(th)
	l:SetStartPoint("TOPLEFT", view, ax, -ay)
	l:SetEndPoint("TOPLEFT", view, bx, -by)
	l:Show()
end
-- one smooth line through world spots { {x, y}, ... }: a dark edge, then the colour on top
local function path(cont, pts, col, smooth, fade)
	if smooth then pts = ns.SmoothLine(pts) end
	local uv = {}
	for k, q in ipairs(pts) do
		local ax, ay, u, v = pos(cont, q[1], q[2])
		uv[k] = ax and { ax, ay, u, v } or false
	end
	for k = 2, #uv do
		local a, b = uv[k - 1], uv[k]
		if a and b and not off(a, b) then
			local f = fade or 1
			-- (media/aa fades its outer thirds: drawn about 1.8x as wide as it looks, for smooth edges)
			line("ARTWORK", 1, a[1], a[2], b[1], b[2], { CASE[1], CASE[2], CASE[3], CASE[4] * f }, (thick + 2.8 / scale) * 1.8)
			line("OVERLAY", 1, a[1], a[2], b[1], b[2], { col[1], col[2], col[3], col[4] * f }, thick * 1.8)
		end
	end
end
-- a picture at a world spot: the game's atlas at its own shape, else our file tinted (col)
local function icon(cont, x, y, atlas, tex, size, col)
	local ax, ay, u, v = pos(cont, x, y)
	if not ax or (not om and (u < 0 or u > 1 or v < 0 or v > 1)) then return end
	ni = ni + 1
	local t = icons[ni]
	if not t then t = ns.NoSnap(view:CreateTexture(nil, "OVERLAY", nil, 7)); icons[ni] = t end
	if not (atlas and ns.Atlas(t, atlas, size, size)) then
		t:SetTexture(tex)
		t:SetTexCoord(0, 1, 0, 1)
		t:SetSize(size, size)
		if col then t:SetVertexColor(col[1], col[2], col[3], 1) else t:SetVertexColor(1, 1, 1, 1) end
	else
		t:SetVertexColor(1, 1, 1, 1)
	end
	t:ClearAllPoints()
	t:SetPoint("CENTER", view, "TOPLEFT", ax, -ay)
	t:Show()
end

-- walking: small dots with a thin dark rim (media/dot.tga, tinted), spaced along the way
local function trail(cont, pts, col, fade)
	local px = {}
	for _, q in ipairs(pts) do
		local ax, ay = pos(cont, q[1], q[2])
		if ax then px[#px + 1] = { ax, ay } end
	end
	local size, step = 6 / scale, 11 / scale
	ns.Along(px, step, step / 2, function(x, y)
		if not om and (x < -0.2 * W or x > 1.2 * W or y < -0.2 * H or y > 1.2 * H) then return end
		ni = ni + 1
		local t = icons[ni]
		if not t then t = ns.NoSnap(view:CreateTexture(nil, "OVERLAY", nil, 7)); icons[ni] = t end
		t:SetTexture(MEDIA .. "dot")
		t:SetTexCoord(0, 1, 0, 1)
		t:SetSize(size, size)
		t:SetVertexColor(col[1], col[2], col[3], (fade or 1))
		t:ClearAllPoints()
		t:SetPoint("CENTER", view, "TOPLEFT", x, -y)
		t:Show()
	end, 1500)
end

local function DrawAll()
	clear()
	local plan = S.plan
	if not (plan and S.goal and view) then return end
	local map = WorldMapFrame
	mapID = map:GetMapID()
	if not mapID then return end
	om = OpenMap()
	W, H = view:GetWidth(), view:GetHeight()
	if not (W and W > 0 and H and H > 0) then return end
	scale = (map.GetCanvasScale and map:GetCanvasScale()) or 1
	thick = 2.6 / scale
	local here = ns.Here()
	local stops = {}
	for i, l in ipairs(plan.legs) do
		local col = COLOR[l.k] or COLOR.walk
		local fade = i == 1 and 1 or 0.75   -- the step you are on stands out
		local a = (i == 1 and here and l.k == "walk") and here or l.from
		if l.k == "fly" then
			for _, h in ipairs(l.hops) do
				local c = P.Curve(h[1], h[2])
				local cont = D.taxi[h[1]][1]
				if c then
					local pts = {}
					for j = 1, #c - 1, 2 do pts[#pts + 1] = { c[j], c[j + 1] } end
					path(cont, pts, col, false, fade)   -- already the game's own smooth curve
				end
			end
			stops[#stops + 1] = { l.from, FlyAtlas(), STOP.fly, col }
			stops[#stops + 1] = { l.to, FlyAtlas(), STOP.fly, col }
		elseif l.k == "walk" then
			local prev = (i == 1 and here) or l.path[1]
			local pts, cont = { { prev.x, prev.y } }, prev.map
			for j = (i == 1 and l.at or 2), #l.path do
				local q = l.path[j]
				if q.map ~= cont then break end
				-- from you to your next spot: round walls and buildings first
				local way = i == 1 and j == l.at and here and ns.LocalWay and ns.LocalWay(here, q)
				if way then
					for k = 1, #way - 1 do pts[#pts + 1] = { way[k].x, way[k].y } end
				else
					local r = P.Round(prev, q)
					if r then pts[#pts + 1] = { r.x, r.y } end
				end
				pts[#pts + 1] = { q.x, q.y }
				prev = q
			end
			if ns.TrailStyle() == "line" then
				path(cont, pts, col, true, fade)
			else
				trail(cont, ns.SmoothLine(pts), col, fade)
			end
		elseif l.k ~= "hearth" and a.map == l.to.map then
			path(a.map, { { a.x, a.y }, { l.to.x, l.to.y } }, col, false, fade)
			stops[#stops + 1] = { l.from, STOP_ATLAS[l.k], STOP[l.k] or (MEDIA .. "stop"), col }
		end
	end
	for _, st in ipairs(stops) do
		local p = st[1]
		icon(p.map, p.x, p.y, st[2], st[3], 18 / scale, st[4])
	end
	-- the goal: the game (or OpenMap) already shows its own pin when the goal is your map pin
	local g = S.goal
	if g.source ~= "pin" then icon(g.map, g.x, g.y, "Waypoint-MapPin-Tracked", MEDIA .. "pin", 22 / scale) end
end

-- our frame on the map's canvas; while the map is open it redraws when the map, zoom or size changes, and 5 times a second
local function MakeView()
	if view then return true end
	if not (WorldMapFrame and WorldMapFrame.GetCanvas) then return false end
	local canvas = WorldMapFrame:GetCanvas()
	if not canvas then return false end
	view = CreateFrame("Frame")
	view:SetParent(canvas)
	view:SetAllPoints(canvas)
	local last, t = "", 0
	view:SetScript("OnUpdate", function(self, el)
		t = t + el
		local o = OpenMap()
		local lvl = canvas:GetFrameLevel() + 1500
		if o and o.ArtTopLevel then
			local ok, top = pcall(o.ArtTopLevel)
			if ok and type(top) == "number" and top + 10 > lvl then lvl = top + 10 end
		end
		if self:GetFrameLevel() ~= lvl then self:SetFrameLevel(lvl) end
		local key = tostring(WorldMapFrame:GetMapID()) .. ":" .. tostring(WorldMapFrame.GetCanvasScale and WorldMapFrame:GetCanvasScale()) .. ":" .. tostring(self:GetWidth()) .. ":" .. tostring(o ~= nil)
		if key ~= last or t > 0.05 then
			last, t = key, 0
			ns.Safe("map", DrawAll)
		end
	end)
	return true
end

function ns.Draw()
	if not MakeView() then return end
	if view:IsVisible() then DrawAll() end
end

-- the spot under the cursor on the map: (uiMap, 0-1 x, 0-1 y), read from OpenMap on its stitched map
local function CursorSpot(map)
	local o = OpenMap()
	if o and o.CursorPosition and o.MapAt and o.MapFromWorld then
		local ok, u, v = pcall(o.CursorPosition)
		if not (ok and u and v) then return nil end
		local ok2, ui = pcall(o.MapAt, u, v)
		if not (ok2 and ui) then return nil end
		local ok3, x, y = pcall(o.MapFromWorld, ui, u, v)
		if ok3 and x and y then return ui, x, y end
		return nil
	end
	local x, y = map:GetNormalizedCursorPosition()
	return map:GetMapID(), x, y
end

-- Shift+click a spot: the route goes there (our pin on the map; the game's own pin is left alone)
local function GoTo(ui, mx, my)
	if not (ui and mx and my) or mx < 0 or mx > 1 or my < 0 or my > 1 then return false end
	local g = ns.WorldFromMap(ui, mx, my)
	if not g then return false end
	local info = C_Map.GetMapInfo(ui)
	g.name = (info and info.name and (info.name .. " ") or "") .. string.format("%.0f, %.0f", mx * 100, my * 100)
	ns.SetGoal(g, "click")   -- our own pin only: nothing of the game's to clear later
	return true
end
ns.GoTo = GoTo

function ns.MapClickInit()
	if ns.clickInit or not WorldMapFrame then return end
	if WorldMapFrame.AddCanvasClickHandler then
		ns.clickInit = true
		-- higher runs first: ahead of OpenMap (1000) and Shortest Path (1001), so a Shift+click is ours
		WorldMapFrame:AddCanvasClickHandler(function(map, button)
			if button ~= "LeftButton" or not IsShiftKeyDown() or IsControlKeyDown() or (ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()) then return false end
			local ok, done = pcall(function() return GoTo(CursorSpot(map)) end)
			if not ok then ns.Error("click", done) end
			return ok and done or false
		end, 1002)
		return
	end
	-- older map without click handlers: watch the mouse on the map
	local sc = WorldMapFrame.ScrollContainer
	if not sc then return end
	ns.clickInit = true
	local down
	sc:HookScript("OnMouseDown", function(self, button)
		down = nil
		if button ~= "LeftButton" or not IsShiftKeyDown() or not self.GetNormalizedCursorPosition then return end
		local mx, my = self:GetNormalizedCursorPosition()
		down = { WorldMapFrame:GetMapID(), mx, my }
	end)
	sc:HookScript("OnMouseUp", function(_, button)
		local d = down
		down = nil
		if button == "LeftButton" and d then GoTo(d[1], d[2], d[3]) end
	end)
end

-- ---------- Shift+click on a map icon (quest giver, turn-in, objective, any other pin) ----------
-- Icons take the click themselves, so the map's own click handler never hears it: we listen to every mouse release
-- and act when it was a Shift+click over an icon on the world map. The route goes to the spot under the cursor.
-- A Questie icon also says what to do there (its quest and type); anything else is named from its tooltip.
local function Under()
	if GetMouseFoci then local f = GetMouseFoci(); return f and f[1] end
	return GetMouseFocus and GetMouseFocus()
end
local function OnMap(f)
	local sc = WorldMapFrame and WorldMapFrame.ScrollContainer
	if not sc or not f or f == sc or f == sc.Child then return false end   -- the bare map: its own click handler
	for _ = 1, 12 do
		f = f.GetParent and f:GetParent()
		if not f then return false end
		if f == sc then return true end
	end
	return false
end
-- a quest from the tooltip shown over the icon ("[48] A Sticky Situation" / "- 0/10 Hinterlands Honey Ripple")
local function TipQuest()
	if not (GameTooltip and GameTooltip:IsShown()) then return nil end
	local function line(i) local l = _G["GameTooltipTextLeft" .. i]; local t = l and l:GetText(); return type(t) == "string" and (t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) or nil end
	local t1 = line(1)
	local title = t1 and (t1:match("^%[%d+%+?%a?%]%s*(.+)$") or t1)
	if not title then return nil end
	local id = ns.QuestIdByTitle and ns.QuestIdByTitle(title)
	if not id then return nil end
	local q = { id = id, title = title }
	local t2 = line(2)
	if t2 and t2:find("%d+/%d+") then
		q.kind = "objective"
		local want = t2:gsub("^%s*%-%s*", ""):gsub("^%d+/%d+%s*", "")
		local li = ns.LogIndex(id)
		for i = 1, 8 do
			local txt = li and GetQuestLogLeaderBoard and GetQuestLogLeaderBoard(i, li)
			if not txt then break end
			if want ~= "" and txt:find(want, 1, true) then q.obj = i; break end
		end
	else
		local _, _, done = ns.QuestInLog(id)
		q.kind = (done == 1 or done == true) and "turnin" or "objective"
	end
	return q
end
local function TipName(f)
	if GameTooltip and GameTooltip:IsShown() and GameTooltip:GetOwner() == f then
		local l = _G.GameTooltipTextLeft1
		local t = l and l:GetText()
		if type(t) == "string" and t ~= "" then return (t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end
	end
end
-- a quest icon that is not Questie's: OpenMap's own quest pins (data.id, data.complete) and the game's QuestPin
-- (questID). What to do there comes from your quest log.
local function LogQuest(id, complete)
	local li, logTitle, done = ns.QuestInLog(id)
	local q = { id = id, title = logTitle }
	if not q.title and C_QuestLog and C_QuestLog.GetTitleForQuestID then q.title = C_QuestLog.GetTitleForQuestID(id) end
	if li then q.kind = (done == 1 or done == true or complete) and "turnin" or "objective"
	else q.kind = complete and "turnin" or "pickup" end
	return q
end
-- what a quest icon is for (read only)
local function QuestOf(f)
	-- the icon, or a part of it (its glow, its texture frame): up to 3 parents for the one with the quest
	local d
	for _ = 1, 4 do
		if not f then return nil end
		local fd = rawget(f, "data")
		if type(fd) == "table" and type(fd.Id) == "number" and type(fd.Type) == "string" then d = fd; break end
		if type(fd) == "table" and type(fd.id) == "number" and (fd.complete ~= nil or type(fd.map) == "number") then
			return LogQuest(fd.id, fd.complete == true)   -- OpenMap
		end
		local qid = rawget(f, "questID")
		if type(qid) == "number" and qid > 0 then return LogQuest(qid) end   -- the game's own quest icon
		f = f.GetParent and f:GetParent()
	end
	if not d then return nil end
	local qd = type(d.QuestData) == "table" and d.QuestData or {}
	local _, logTitle = ns.QuestInLog(d.Id)
	local q = { id = d.Id, title = logTitle or (type(qd.name) == "string" and qd.name) or nil }
	if d.Type == "complete" then q.kind = "turnin"
	elseif d.Type == "available" then q.kind = "pickup"
	else
		q.kind = "objective"
		q.obj = type(d.ObjectiveIndex) == "number" and d.ObjectiveIndex or nil
		q.otype = type(d.Type) == "string" and d.Type or nil
		local od = type(d.ObjectiveData) == "table" and d.ObjectiveData or {}
		if type(od.Description) == "string" then
			q.text = od.Description .. ((type(od.Needed) == "number" and od.Needed > 0) and (": " .. (tonumber(od.Collected) or 0) .. "/" .. od.Needed) or "")
		end
	end
	return q, type(d.Name) == "string" and d.Name or nil, d.Type
end
-- what was under the mouse when the button went down: the click itself can change the map (a city icon zooms into
-- the city, a quest icon opens the quest), so the spot is read before that
local pressed
local function Press()
	pressed = nil
	if not (WorldMapFrame and WorldMapFrame:IsShown()) then return end
	if not IsShiftKeyDown() or IsControlKeyDown() then return end
	local foci = GetMouseFoci and GetMouseFoci() or { Under() }
	local copy = {}
	for i, c in ipairs(foci) do copy[i] = c end
	local ui, mx, my = CursorSpot(WorldMapFrame)
	pressed = { t = GetTime(), foci = copy, ui = ui, mx = mx, my = my }
end
local function PinClick()
	local pr = pressed
	pressed = nil
	if pr and GetTime() - pr.t > 1.5 then pr = nil end
	if not (WorldMapFrame and WorldMapFrame:IsShown()) then return end
	if not IsShiftKeyDown() or IsControlKeyDown() or (ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()) then return end
	-- every frame under the mouse (an icon can sit under another map add-on's frame): the first with a quest
	if ns.mouseDown and not pr then return end   -- the press did not start on the map with Shift held
	local foci = pr and pr.foci or (GetMouseFoci and GetMouseFoci() or { Under() })
	local f, q, who, kind
	local qlog = WorldMapFrame.QuestLog or QuestMapFrame
	local function inLog(c)
		for _ = 1, 15 do
			if not c then return false end
			if c == qlog then return true end
			c = c.GetParent and c:GetParent()
		end
		return false
	end
	-- under the world map but not its scroll area: another map add-on's own layer (OpenMap moves its icons onto its
	-- stitched map in combat). Only a quest icon there counts.
	local function inMap(c)
		for _ = 1, 15 do
			if not c then return false end
			if c == WorldMapFrame then return true end
			c = c.GetParent and c:GetParent()
		end
		return false
	end
	for _, c in ipairs(foci) do
		-- the quest list beside (or, full screen, over) the map is on top: that click is for the quest list
		if not f and qlog and inLog(c) then return end
		if OnMap(c) then
			f = f or c
			q, who, kind = QuestOf(c)
			if q then f = c; break end
		elseif inMap(c) then
			local q2, who2, kind2 = QuestOf(c)
			if q2 then f, q, who, kind = c, q2, who2, kind2; break end
		end
	end
	if not f then return end
	local ui, mx, my
	if pr then ui, mx, my = pr.ui, pr.mx, pr.my else ui, mx, my = CursorSpot(WorldMapFrame) end
	if not GoTo(ui, mx, my) then return end
	if not q then q = TipQuest() end
	local g = S.goal
	if g then
		g.quest = q
		g.name = who or (q and q.title) or TipName(f) or g.name
		if JunhotsTravelCharDB.goal then JunhotsTravelCharDB.goal.quest, JunhotsTravelCharDB.goal.name = g.quest, g.name end
		-- the plan was made before the name was known: name its end too
		if S.plan then for _, l in ipairs(S.plan.legs) do if l.to and l.to.key == "T" then l.to.name = g.name end end end
	end
	-- Questie asks "hide this quest?" on a Shift+click of a quest giver: that click was for us
	if kind == "available" and StaticPopup_Hide then C_Timer.After(0, function() StaticPopup_Hide("QUESTIE_CONFIRMHIDE") end) end
	ns.Refresh()
end
function ns.PinClickInit()
	if ns.pinInit then return end
	ns.pinInit = true
	local f = CreateFrame("Frame")
	local ok = pcall(f.RegisterEvent, f, "GLOBAL_MOUSE_UP")
	if not ok then return end
	ns.mouseDown = pcall(f.RegisterEvent, f, "GLOBAL_MOUSE_DOWN") or nil
	f:SetScript("OnEvent", function(_, ev, button)
		if button ~= "LeftButton" then return end
		if ev == "GLOBAL_MOUSE_DOWN" then ns.Safe("pin click", Press) else ns.Safe("pin click", PinClick) end
	end)
	-- a Shift+click on the game's own map icons (a city, a quest) is ours: no zooming in, no quest window
	if WorldMapFrame and WorldMapFrame.AddGlobalPinMouseActionHandler then
		pcall(WorldMapFrame.AddGlobalPinMouseActionHandler, WorldMapFrame, function(_, _, button)
			return (button == nil or button == "LeftButton") and IsShiftKeyDown() and not IsControlKeyDown()
				and not (ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()) or false
		end, 1002)
	end
end

-- ---------- the game's flight map: mark the flight point to pick ----------
-- The game's gold ring round its button (its dark edge stands out on the yellow map), the game's arrow bobbing
-- above it, and "Fly here" under it (only when your next flight starts at this flight master).
local taxiMark
local function MakeTaxiMark(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetSize(40, 40)
	local ring = f:CreateTexture(nil, "OVERLAY")
	ring:SetPoint("CENTER", 0.3, -1.7)
	if not ns.Atlas(ring, "worldquest-tracker-ring-selected", 30, 30) then ring:SetSize(1, 1); ring:SetColorTexture(0, 0, 0, 0) end
	local glow = f:CreateTexture(nil, "ARTWORK")
	glow:SetPoint("CENTER")
	if not ns.Atlas(glow, "ArtifactsFX-YellowRing", 40, 40) then glow:SetSize(1, 1); glow:SetColorTexture(0, 0, 0, 0) end
	glow:SetVertexColor(0.3, 1, 0.3)
	local arrow = f:CreateTexture(nil, "OVERLAY")
	if ns.Atlas(arrow, "Navigation-Tracked-Arrow", 22, 18) then arrow:SetRotation(math.pi) else arrow:SetSize(1, 1); arrow:SetColorTexture(0, 0, 0, 0) end
	arrow:SetPoint("BOTTOM", f, "CENTER", 0, 15)
	local label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	label:SetPoint("TOP", f, "CENTER", 0, -15)
	local font, size = label:GetFont()
	if font then label:SetFont(font, (size or 10) + 1, "OUTLINE") end
	label:SetText("Fly here")
	-- the arrow bobs (its own animation, so the ring and words stay still)
	if arrow.CreateAnimationGroup then
		local ag = arrow:CreateAnimationGroup()
		ag:SetLooping("BOUNCE")
		local m = ag:CreateAnimation("Translation")
		m:SetOffset(0, -4)
		m:SetDuration(0.6)
		if m.SetSmoothing then m:SetSmoothing("IN_OUT") end
		local g2 = glow:CreateAnimationGroup()
		g2:SetLooping("BOUNCE")
		local a = g2:CreateAnimation("Alpha")
		if a.SetFromAlpha then a:SetFromAlpha(0.9); a:SetToAlpha(0.35) end
		a:SetDuration(0.6)
		f.pulse = { ag, g2 }
	end
	return f
end
function ns.TaxiMark()
	if taxiMark then taxiMark:Hide() end
	local plan = S.plan
	if not (plan and C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and GetTaxiMapID and TaxiNodeGetType) then return end
	local fly
	for _, l in ipairs(plan.legs) do if l.k == "fly" then fly = l; break end end
	if not fly then return end
	local map = GetTaxiMapID()
	if not map then return end
	local slot, here
	for _, node in ipairs(C_TaxiMap.GetAllTaxiNodes(map) or {}) do
		if node.nodeID == fly.b then slot = node.slotIndex end
		if node.nodeID == fly.a and node.slotIndex and TaxiNodeGetType(node.slotIndex) == "CURRENT" then here = true end
	end
	if not (slot and here) then return end
	local b = _G["TaxiButton" .. slot]
	if not (b and b:IsShown()) then return end
	if not taxiMark then taxiMark = MakeTaxiMark(b:GetParent()) end
	taxiMark:SetParent(b:GetParent())
	taxiMark:SetFrameLevel(b:GetFrameLevel() + 2)
	taxiMark:ClearAllPoints()
	taxiMark:SetPoint("CENTER", b, "CENTER")
	taxiMark:Show()
	ns.taxiMark = taxiMark
	for _, ag in ipairs(taxiMark.pulse or {}) do ag:Play() end
end
