-- Draws your way on the world map: walking (gold), flights along their real curves (green), boats and zeppelins (blue).
local _, ns = ...
local P = ns.Planner
local D = ns.D
local S = ns.state

local COLOR = {
	walk = { 1, 0.85, 0.2, 1 },
	fly = { 0.3, 1, 0.42, 1 },
	boat = { 0.35, 0.7, 1, 0.95 }, zeppelin = { 0.35, 0.7, 1, 0.95 }, tram = { 0.35, 0.7, 1, 0.95 }, lift = { 0.35, 0.7, 1, 0.95 },
	portal = { 0.8, 0.55, 1, 0.95 }, passage = { 0.8, 0.55, 1, 0.95 },
}

-- ---------- smooth lines ----------
-- Douglas-Peucker: drop spots that sit almost on the line between their neighbours (tol in yards)
local function Simplify(pts, tol)
	if #pts < 3 then return pts end
	local keep = { [1] = true, [#pts] = true }
	local stack = { { 1, #pts } }
	while #stack > 0 do
		local r = table.remove(stack)
		local a, b = pts[r[1]], pts[r[2]]
		local dx, dy = b[1] - a[1], b[2] - a[2]
		local len = math.sqrt(dx * dx + dy * dy)
		local far, at = 0, nil
		for k = r[1] + 1, r[2] - 1 do
			local q = pts[k]
			local d = len > 0 and math.abs(dx * (a[2] - q[2]) - dy * (a[1] - q[1])) / len or math.sqrt((q[1] - a[1]) ^ 2 + (q[2] - a[2]) ^ 2)
			if d > far then far, at = d, k end
		end
		if at and far > tol then keep[at] = true; stack[#stack + 1] = { r[1], at }; stack[#stack + 1] = { at, r[2] } end
	end
	local out = {}
	for k = 1, #pts do if keep[k] then out[#out + 1] = pts[k] end end
	return out
end
-- Chaikin corner cutting: rounds the corners (ends stay where they are)
local function Round(pts, times)
	for _ = 1, times do
		if #pts < 3 then return pts end
		local out = { pts[1] }
		for k = 1, #pts - 1 do
			local a, b = pts[k], pts[k + 1]
			out[#out + 1] = { a[1] * 0.75 + b[1] * 0.25, a[2] * 0.75 + b[2] * 0.25 }
			out[#out + 1] = { a[1] * 0.25 + b[1] * 0.75, a[2] * 0.25 + b[2] * 0.75 }
		end
		out[#out + 1] = pts[#pts]
		pts = out
	end
	return pts
end
ns.SmoothLine = function(pts, tol) return Round(Simplify(pts, tol or 12), 3) end
-- spots every `step` along a line of { x, y } (first one `first` in), each given to put(x, y); at most `max`
function ns.Along(pts, step, first, put, max)
	local carry, n = first or step / 2, 0
	for i = 2, #pts do
		local a, b = pts[i - 1], pts[i]
		local dx, dy = b[1] - a[1], b[2] - a[2]
		local len = math.sqrt(dx * dx + dy * dy)
		local d = carry
		while d < len do
			n = n + 1
			if max and n > max then return end
			put(a[1] + dx * d / len, a[2] + dy * d / len)
			d = d + step
		end
		carry = d - len
	end
end
-- the walking way: small spaced dots ("dots", the default) or a thin line ("line")
function ns.TrailStyle() return (JunhotsTravelDB and JunhotsTravelDB.trail) or "dots" end

-- our own art (media/*.tga, made by art/make_art.py): white parts take the colour of the leg
local MEDIA = "Interface\\AddOns\\JunhotsTravel\\media\\"
-- stops wear the game's own map art where the client has it ("atlas:"), else ours
local STOP = { fly = MEDIA .. "stop_fly", boat = MEDIA .. "stop_boat", zeppelin = MEDIA .. "stop_boat" }
local STOP_ATLAS = { boat = "flightmasterferry", zeppelin = "flightmasterferry" }
local function FlyAtlas()
	local f = UnitFactionGroup("player")
	return (f == "Alliance" or f == "Horde") and ("taxinode_" .. f:lower()) or "taxinode_neutral"
end
local CASE = { 0.03, 0.02, 0.005, 0.85 }   -- dark soft edge under every line: stands out on any map colour

-- OpenMap (the seamless world map addon) says where a world spot sits on its stitched map (its read-only OpenMapAPI)
local function OpenMap()
	local api = rawget(_G, "OpenMapAPI")
	if type(api) ~= "table" or api.major ~= 1 or (api.version or 0) < 2 or not api.IsStitched then return nil end
	local ok, on = pcall(api.IsStitched)
	return ok and on == true and api or nil
end
ns.OpenMap = OpenMap

-- We draw on a frame of our own on the map (no data provider: that is a write into the map, which can taint it).
local view, lines, icons, nl, ni = nil, {}, {}, 0, 0
local W, H, mapID, om, scale
-- the scale lines and pictures are sized for: the map's zoom in steps of about 12% (a zoom glide sizes them again a
-- few times, not every frame)
local qscale = 1
-- In combat OpenMap hides the game's map canvas (alpha 0) and shows its own view over it, panned and zoomed by
-- itself: then we draw on a frame of ours over that view (tgt = cview) and place spots as OpenMap does (ov).
local tgt, cview, ov
local pools = {}
local function usePool(f)
	local p = pools[f]
	if not p then p = { lines = {}, icons = {} }; pools[f] = p end
	tgt, lines, icons = f, p.lines, p.icons
end

-- What to draw is first written down (specs), then put on the map; a line or picture already showing the same thing
-- is left alone, so drawing an unchanged way again costs next to nothing.
local specs = {}
local function hideFrom(p, nl0, ni0)
	for k = nl0 + 1, #p.lines do local l = p.lines[k]; if l.jt.shown then l:Hide(); l.jt.shown = false end end
	for k = ni0 + 1, #p.icons do local t = p.icons[k]; if t.jt.shown then t:Hide(); t.jt.shown = false end end
end
local function clear()
	for _, p in pairs(pools) do hideFrom(p, 0, 0) end
	nl, ni = 0, 0
end
-- spots are kept as map fractions (u, v) and sizes in screen units: zooming or OpenMap's own view moving only moves
-- them on screen (here), it never works the way out again
local function tf(u, v)
	if ov then return ov.sw / 2 + (u - ov.x) * ov.w * ov.s, ov.sh / 2 + (v - ov.y) * ov.h * ov.s end
	return u * W, v * H
end
local function putLine(sp)
	nl = nl + 1
	local l = lines[nl]
	if not l then l = ns.NoSnap(tgt:CreateLine(nil, "ARTWORK")); l:SetTexture(MEDIA .. "aa"); l.jt = {}; lines[nl] = l end
	local c = l.jt
	if c[1] ~= sp[2] or c[2] ~= sp[3] then l:SetDrawLayer(sp[2], sp[3]); c[1], c[2] = sp[2], sp[3] end
	if c[3] ~= sp[8] or c[4] ~= sp[9] or c[5] ~= sp[10] or c[6] ~= sp[11] then
		l:SetVertexColor(sp[8], sp[9], sp[10], sp[11]); c[3], c[4], c[5], c[6] = sp[8], sp[9], sp[10], sp[11]
	end
	local th = sp[12] / qscale
	if c[7] ~= th then l:SetThickness(th); c[7] = th end
	local ax, ay = tf(sp[4], sp[5])
	local bx, by = tf(sp[6], sp[7])
	if c[8] ~= ax or c[9] ~= ay then l:SetStartPoint("TOPLEFT", tgt, ax, -ay); c[8], c[9] = ax, ay end
	if c[10] ~= bx or c[11] ~= by then l:SetEndPoint("TOPLEFT", tgt, bx, -by); c[10], c[11] = bx, by end
	if not c.shown then l:Show(); c.shown = true end
end
-- a picture: the game's atlas at its own shape, else our file (tinted)
local function putIcon(sp)
	ni = ni + 1
	local t = icons[ni]
	if not t then t = ns.NoSnap(tgt:CreateTexture(nil, "OVERLAY", nil, 7)); t.jt = {}; icons[ni] = t end
	local c = t.jt
	local atlas, tex, size = sp[2], sp[3], sp[4] / qscale
	if c.atlas ~= atlas or c.tex ~= tex or c.size ~= size then
		c.atlasOk = (atlas and ns.Atlas(t, atlas, size, size)) or false
		if not c.atlasOk then t:SetTexture(tex); t:SetTexCoord(0, 1, 0, 1); t:SetSize(size, size) end
		c.atlas, c.tex, c.size, c.r = atlas, tex, size, nil
	end
	local r, g, b, a = sp[5], sp[6], sp[7], sp[10]
	if c.atlasOk then r, g, b, a = 1, 1, 1, 1 end
	if c.r ~= r or c.g ~= g or c.b ~= b or c.a ~= a then t:SetVertexColor(r, g, b, a); c.r, c.g, c.b, c.a = r, g, b, a end
	local x, y = tf(sp[8], sp[9])
	if c.x ~= x or c.y ~= y then t:ClearAllPoints(); t:SetPoint("CENTER", tgt, "TOPLEFT", x, -y); c.x, c.y = x, y end
	if not c.shown then t:Show(); c.shown = true end
end

-- world spot -> its map fractions (u, v)
local function pos(cont, x, y)
	if om and om.CanvasFromWorldPos then
		local ok, u, v = pcall(om.CanvasFromWorldPos, cont, x, y)
		if ok and type(u) == "number" and type(v) == "number" then return u, v end
		return nil
	end
	local _, p = C_Map.GetMapPosFromWorldPos(cont, CreateVector2D(x, y), mapID)
	if not p then return nil end
	return p:GetXY()
end
local function off(a, b)
	if om then return false end   -- the stitched map shows the zones around too; the map itself clips the rest
	return (a[1] < -0.2 and b[1] < -0.2) or (a[1] > 1.2 and b[1] > 1.2) or (a[2] < -0.2 and b[2] < -0.2) or (a[2] > 1.2 and b[2] > 1.2)
end
local function line(layer, sub, ax, ay, bx, by, col, th)
	specs[#specs + 1] = { 1, layer, sub, ax, ay, bx, by, col[1], col[2], col[3], col[4], th }
end
-- one smooth line through world spots { {x, y}, ... }: a dark edge, then the colour on top
local function path(cont, pts, col, smooth, fade)
	if smooth then pts = ns.SmoothLine(pts) end
	local uv = {}
	for k, q in ipairs(pts) do
		local u, v = pos(cont, q[1], q[2])
		uv[k] = u and { u, v } or false
	end
	for k = 2, #uv do
		local a, b = uv[k - 1], uv[k]
		if a and b and not off(a, b) then
			local f = fade or 1
			-- (media/aa fades its outer thirds: drawn about 1.8x as wide as it looks, for smooth edges)
			line("ARTWORK", 1, a[1], a[2], b[1], b[2], { CASE[1], CASE[2], CASE[3], CASE[4] * f }, (2.6 + 2.8) * 1.8)
			line("OVERLAY", 1, a[1], a[2], b[1], b[2], { col[1], col[2], col[3], col[4] * f }, 2.6 * 1.8)
		end
	end
end
-- a picture at a world spot: the game's atlas at its own shape, else our file tinted (col)
local function icon(cont, x, y, atlas, tex, size, col)
	local u, v = pos(cont, x, y)
	if not u or (not om and (u < 0 or u > 1 or v < 0 or v > 1)) then return end
	specs[#specs + 1] = { 2, atlas, tex, size, col and col[1] or 1, col and col[2] or 1, col and col[3] or 1, u, v, 1 }
end

-- walking: small dots with a thin dark rim (media/dot.tga, tinted), spaced along the way
-- (spaced on screen: in pixels at the zoom it is drawn for; kept as map fractions)
local function trail(cont, pts, col, fade)
	local px = {}
	local sw, sh = W * qscale, H * qscale
	if ov then sw, sh = ov.w * ov.s, ov.h * ov.s end
	for _, q in ipairs(pts) do
		local u, v = pos(cont, q[1], q[2])
		if u then px[#px + 1] = { u * sw, v * sh } end
	end
	ns.Along(px, 11, 5.5, function(x, y)
		local u, v = x / sw, y / sh
		if not om and (u < -0.2 or u > 1.2 or v < -0.2 or v > 1.2) then return end
		specs[#specs + 1] = { 2, nil, MEDIA .. "dot", 6, col[1], col[2], col[3], u, v, fade or 1 }
	end, 1500)
end

-- OpenMap's own view (in combat): where it is looking, as canvas fractions, and its zoom as a canvas scale. Its scale
-- is not given, only a zoom; scale = zoom * (map width in world fractions) * C / canvas width, with C (the window's
-- fit size) measured out of combat, when the game's own canvas scale is known (saved, per window size).
local function OwnView(o, sc, canvas)
	if not (o and o.GetView and o.MapFromWorld and o.WorldFromMap and sc and canvas and canvas.GetAlpha and sc.GetWidth) then return nil end
	local w, h, sw, sh = canvas:GetWidth(), canvas:GetHeight(), sc:GetWidth(), sc:GetHeight()
	if not (w and w > 0 and h and h > 0 and sw and sw > 0) then return nil end
	local ok, u, v, zoom = pcall(o.GetView)
	if not (ok and type(u) == "number" and type(v) == "number" and type(zoom) == "number" and zoom > 0) then return nil end
	local ok1, l0 = pcall(o.WorldFromMap, mapID, 0, 0)
	local ok2, r0 = pcall(o.WorldFromMap, mapID, 1, 0)
	if not (ok1 and ok2 and type(l0) == "number" and type(r0) == "number" and r0 ~= l0) then return nil end
	local rl = r0 - l0
	local key = math.floor(sw + 0.5) .. "x" .. math.floor(sh + 0.5)
	JunhotsTravelDB.omFit = JunhotsTravelDB.omFit or {}
	if canvas:GetAlpha() > 0 then
		-- the game's canvas is showing: measure C
		local s0 = WorldMapFrame.GetCanvasScale and WorldMapFrame:GetCanvasScale()
		if s0 and s0 > 0 then JunhotsTravelDB.omFit[key] = s0 * w / (zoom * rl) end
		return nil
	end
	local C = JunhotsTravelDB.omFit[key]
	if not C then return nil end
	local ok3, x, y = pcall(o.MapFromWorld, mapID, u, v)
	if not (ok3 and type(x) == "number" and type(y) == "number") then return nil end
	return { sw = sw, sh = sh, w = w, h = h, x = x, y = y, s = zoom * rl * C / w }
end

-- the fixed part of the drawing (every step but the walk you are on), kept until the plan, map or zoom changes
local fixed = {}
local function DrawLeg(i, l, here, live, way, stops)
	local col = COLOR[l.k] or COLOR.walk
	local fade = i == 1 and 1 or 0.75   -- the step you are on stands out
	local a = (l == live) and here or l.from
	if l.k == "fly" then
		for _, h in ipairs(l.hops) do
			local c = P.Curve(h[1], h[2])
			local cont = D.taxi[h[1]][1]
			if c then
				local pts = {}
				for j = 1, #c - 1, 2 do pts[#pts + 1] = { c[j], c[j + 1] } end
				path(cont, pts, col, false, fade)   -- already the game's own smooth curve
			end
		end
		stops[#stops + 1] = { l.from, FlyAtlas(), STOP.fly, col }
		stops[#stops + 1] = { l.to, FlyAtlas(), STOP.fly, col }
	elseif l.k == "walk" then
		-- the walk you are on comes in two parts: from you to your next spot (redrawn as you move, round the wall in
		-- front of you) and from there on (drawn again only when you pass a spot)
		local at = l.at or 2
		local prev = (l == live and (way == "tail" and l.path[at] or here)) or l.path[1]
		local pts, cont = { { prev.x, prev.y } }, prev.map
		local j0, j1 = (l == live and (way == "tail" and at + 1 or at)) or 2, (l == live and way ~= "tail") and at or #l.path
		for j = j0, j1 do
			local q = l.path[j]
			if q.map ~= cont then break end
			-- from you to your next spot: round walls and buildings first
			local wy = l == live and j == at and type(way) == "table" and way or nil
			if wy then
				for k = 1, #wy - 1 do pts[#pts + 1] = { wy[k].x, wy[k].y } end
			else
				local r = P.Round(prev, q)
				if r then pts[#pts + 1] = { r.x, r.y } end
			end
			pts[#pts + 1] = { q.x, q.y }
			prev = q
		end
		if #pts < 2 then return end
		if ns.TrailStyle() == "line" then
			path(cont, pts, col, true, fade)
		else
			trail(cont, ns.SmoothLine(pts), col, fade)
		end
	elseif l.k ~= "hearth" and a.map == l.to.map then
		path(a.map, { { a.x, a.y }, { l.to.x, l.to.y } }, col, false, fade)
		stops[#stops + 1] = { l.from, STOP_ATLAS[l.k], STOP[l.k] or (MEDIA .. "stop"), col }
	end
end

local function DrawAll()
	local plan = S.plan
	local function none() clear(); fixed.sig, fixed.tsig = nil, nil end
	if not (plan and S.goal and view) then return none() end
	local map = WorldMapFrame
	mapID = map:GetMapID()
	if not mapID then return none() end
	om = OpenMap()
	W, H = view:GetWidth(), view:GetHeight()
	if not (W and W > 0 and H and H > 0) then return none() end
	scale = (map.GetCanvasScale and map:GetCanvasScale()) or 1
	local sc, canvas = map.ScrollContainer, map:GetCanvas()
	ov = om and OwnView(om, sc, canvas) or nil
	if ov then
		if not cview then
			cview = CreateFrame("Frame")   -- made with no parent, then moved (the gamepad interface follows frames made inside a window)
			cview:SetParent(sc)
			cview:SetAllPoints(sc)
			if cview.SetClipsChildren then cview:SetClipsChildren(true) end
		end
		if cview:GetFrameLevel() < 9300 then cview:SetFrameLevel(9300) end   -- over OpenMap's own view (9200), under its icons
		usePool(cview)
		scale = 1   -- drawn at screen size: OpenMap's zoom is in the spots, not in our frame
		qscale = 1
	else
		usePool(view)
		if canvas and canvas.GetAlpha and canvas:GetAlpha() == 0 then return none() end   -- hidden and no way to place spots: draw nothing wrong
	end
	if not ov then
		local qs = 2 ^ (math.floor(math.log(scale) / math.log(2) * 6 + 0.5) / 6)
		if math.abs(qs - qscale) > 0.001 then qscale = qs end
	end
	local here = ns.Here()
	local l1 = plan.legs[1]
	local live = here and l1 and l1.k == "walk" and l1.path and l1 or nil
	-- the walk you are on: from where you stand, round the wall in front of you
	local way, wsig = nil, ""
	if live then
		local q = live.path[live.at or 2]
		way = q and q.map == here.map and ns.LocalWay and ns.LocalWay(here, q) or nil
		wsig = math.floor(here.x) .. "," .. math.floor(here.y) .. ":" .. (live.at or 2) .. ":" .. (way and (#way .. ":" .. way[1].x .. "," .. way[1].y) or "-")
	end
	-- (the dots' spacing is on screen: worked out again when the zoom changes a step; lines only change size)
	local dots = ns.TrailStyle() ~= "line"
	local zk = dots and (ov and math.floor(math.log(ov.s) / math.log(2) * 6 + 0.5) or qscale) or 0
	local fsig = table.concat({ tostring(plan), mapID, zk, tostring(tgt), tostring(om ~= nil), ns.TrailStyle(), tostring(S.goal), S.goal.source or "" }, ":")
	-- nothing changed: leave it as it is (OpenMap's own view moves by itself: put again, without working it out again)
	local same = fsig == fixed.sig and wsig == fixed.wsig and W == fixed.W and H == fixed.H and qscale == fixed.qs
	if not ov and same then return end
	fixed.W, fixed.H, fixed.qs = W, H, qscale
	if fsig ~= fixed.sig then
		specs = {}
		local stops = {}
		for i, l in ipairs(plan.legs) do
			if l ~= live then DrawLeg(i, l, here, live, nil, stops) end
		end
		for _, st in ipairs(stops) do
			local p = st[1]
			icon(p.map, p.x, p.y, st[2], st[3], 18, st[4])
		end
		-- the goal: the game (or OpenMap) already shows its own pin when the goal is your map pin
		local g = S.goal
		if g.source ~= "pin" then icon(g.map, g.x, g.y, "Waypoint-MapPin-Tracked", MEDIA .. "pin", 22) end
		fixed.sig, fixed.specs = fsig, specs
	end
	fixed.wsig = wsig
	local tsig = live and (fsig .. ":" .. (live.at or 2)) or ""
	if tsig ~= fixed.tsig then
		specs = {}
		if live then DrawLeg(1, live, here, live, "tail", {}) end
		fixed.tsig, fixed.tail = tsig, specs
	end
	specs = {}
	if live then DrawLeg(1, live, here, live, way or false, {}) end
	nl, ni = 0, 0
	for _, p in pairs(pools) do if p.lines ~= lines then hideFrom(p, 0, 0) end end
	for _, sp in ipairs(fixed.specs) do if sp[1] == 1 then putLine(sp) else putIcon(sp) end end
	for _, sp in ipairs(fixed.tail) do if sp[1] == 1 then putLine(sp) else putIcon(sp) end end
	for _, sp in ipairs(specs) do if sp[1] == 1 then putLine(sp) else putIcon(sp) end end
	hideFrom(pools[tgt], nl, ni)
end

-- our frame on the map's canvas; while the map is open it redraws when the map, zoom or size changes, and 5 times a second
local function MakeView()
	if view then return true end
	if not (WorldMapFrame and WorldMapFrame.GetCanvas) then return false end
	local canvas = WorldMapFrame:GetCanvas()
	if not canvas then return false end
	view = CreateFrame("Frame")
	view:SetParent(canvas)
	view:SetAllPoints(canvas)
	local last, t = "", 0
	view:SetScript("OnUpdate", function(self, el)
		t = t + el
		local o = OpenMap()
		local lvl = canvas:GetFrameLevel() + 1500
		if o and o.ArtTopLevel then
			local ok, top = pcall(o.ArtTopLevel)
			if ok and type(top) == "number" and top + 10 > lvl then lvl = top + 10 end
		end
		if self:GetFrameLevel() ~= lvl then self:SetFrameLevel(lvl) end
		local key = tostring(WorldMapFrame:GetMapID()) .. ":" .. tostring(WorldMapFrame.GetCanvasScale and WorldMapFrame:GetCanvasScale()) .. ":" .. tostring(self:GetWidth()) .. ":" .. tostring(o ~= nil)
		if key ~= last or t > 0.05 then
			last, t = key, 0
			ns.Safe("map", DrawAll)
		end
	end)
	return true
end

function ns.Draw()
	if not MakeView() then return end
	if view:IsVisible() then DrawAll() end
end

-- the spot under the cursor on the map: (uiMap, 0-1 x, 0-1 y), read from OpenMap on its stitched map
local function CursorSpot(map)
	local o = OpenMap()
	if o and o.CursorPosition and o.MapAt and o.MapFromWorld then
		local ok, u, v = pcall(o.CursorPosition)
		if not (ok and u and v) then return nil end
		local ok2, ui = pcall(o.MapAt, u, v)
		if not (ok2 and ui) then return nil end
		local ok3, x, y = pcall(o.MapFromWorld, ui, u, v)
		if ok3 and x and y then return ui, x, y end
		return nil
	end
	local x, y = map:GetNormalizedCursorPosition()
	return map:GetMapID(), x, y
end

-- Shift+click a spot: the route goes there (our pin on the map; the game's own pin is left alone)
local function GoTo(ui, mx, my)
	if not (ui and mx and my) or mx < 0 or mx > 1 or my < 0 or my > 1 then return false end
	local g = ns.WorldFromMap(ui, mx, my)
	if not g then return false end
	local info = C_Map.GetMapInfo(ui)
	g.name = (info and info.name and (info.name .. " ") or "") .. string.format("%.0f, %.0f", mx * 100, my * 100)
	ns.SetGoal(g, "click")   -- our own pin only: nothing of the game's to clear later
	return true
end
ns.GoTo = GoTo

function ns.MapClickInit()
	if ns.clickInit or not WorldMapFrame then return end
	if WorldMapFrame.AddCanvasClickHandler then
		ns.clickInit = true
		-- higher runs first: ahead of OpenMap (1000) and Shortest Path (1001), so a Shift+click is ours
		WorldMapFrame:AddCanvasClickHandler(function(map, button)
			if button ~= "LeftButton" or not IsShiftKeyDown() or IsControlKeyDown() or (ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()) then return false end
			local ok, done = pcall(function() return GoTo(CursorSpot(map)) end)
			if not ok then ns.Error("click", done) end
			return ok and done or false
		end, 1002)
		return
	end
	-- older map without click handlers: watch the mouse on the map
	local sc = WorldMapFrame.ScrollContainer
	if not sc then return end
	ns.clickInit = true
	local down
	sc:HookScript("OnMouseDown", function(self, button)
		down = nil
		if button ~= "LeftButton" or not IsShiftKeyDown() or not self.GetNormalizedCursorPosition then return end
		local mx, my = self:GetNormalizedCursorPosition()
		down = { WorldMapFrame:GetMapID(), mx, my }
	end)
	sc:HookScript("OnMouseUp", function(_, button)
		local d = down
		down = nil
		if button == "LeftButton" and d then GoTo(d[1], d[2], d[3]) end
	end)
end

-- ---------- Shift+click on a map icon (quest giver, turn-in, objective, any other pin) ----------
-- Icons take the click themselves, so the map's own click handler never hears it: we listen to every mouse release
-- and act when it was a Shift+click over an icon on the world map. The route goes to the spot under the cursor.
-- A Questie icon also says what to do there (its quest and type); anything else is named from its tooltip.
local function Under()
	if GetMouseFoci then local f = GetMouseFoci(); return f and f[1] end
	return GetMouseFocus and GetMouseFocus()
end
local function OnMap(f)
	local sc = WorldMapFrame and WorldMapFrame.ScrollContainer
	if not sc or not f or f == sc or f == sc.Child then return false end   -- the bare map: its own click handler
	for _ = 1, 12 do
		f = f.GetParent and f:GetParent()
		if not f then return false end
		if f == sc then return true end
	end
	return false
end
-- a quest from the tooltip shown over the icon ("[48] A Sticky Situation" / "- 0/10 Hinterlands Honey Ripple")
local function TipQuest()
	if not (GameTooltip and GameTooltip:IsShown()) then return nil end
	local function line(i) local l = _G["GameTooltipTextLeft" .. i]; local t = l and l:GetText(); return type(t) == "string" and (t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) or nil end
	local t1 = line(1)
	local title = t1 and (t1:match("^%[%d+%+?%a?%]%s*(.+)$") or t1)
	if not title then return nil end
	local id = ns.QuestIdByTitle and ns.QuestIdByTitle(title)
	if not id then return nil end
	local q = { id = id, title = title }
	local t2 = line(2)
	if t2 and t2:find("%d+/%d+") then
		q.kind = "objective"
		local want = t2:gsub("^%s*%-%s*", ""):gsub("^%d+/%d+%s*", "")
		for i = 1, 8 do
			local txt = ns.QuestObjective(id, i)
			if not txt then break end
			if want ~= "" and txt:find(want, 1, true) then q.obj = i; break end
		end
	else
		local _, _, done = ns.QuestInLog(id)
		q.kind = (done == 1 or done == true) and "turnin" or "objective"
	end
	return q
end
local function TipName(f)
	if GameTooltip and GameTooltip:IsShown() and GameTooltip:GetOwner() == f then
		local l = _G.GameTooltipTextLeft1
		local t = l and l:GetText()
		if type(t) == "string" and t ~= "" then return (t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end
	end
end
-- a quest icon that is not Questie's: OpenMap's own quest pins (data.id, data.complete) and the game's QuestPin
-- (questID). What to do there comes from your quest log.
local function LogQuest(id, complete)
	local li, logTitle, done = ns.QuestInLog(id)
	local q = { id = id, title = logTitle }
	if not q.title and C_QuestLog and C_QuestLog.GetTitleForQuestID then q.title = C_QuestLog.GetTitleForQuestID(id) end
	if li then q.kind = (done == 1 or done == true or complete) and "turnin" or "objective"
	else q.kind = complete and "turnin" or "pickup" end
	return q
end
-- what a quest icon is for (read only)
local function QuestOf(f)
	-- the icon, or a part of it (its glow, its texture frame): up to 3 parents for the one with the quest
	local d
	for _ = 1, 4 do
		if not f then return nil end
		local fd = rawget(f, "data")
		if type(fd) == "table" and type(fd.Id) == "number" and type(fd.Type) == "string" then d = fd; break end
		if type(fd) == "table" and type(fd.id) == "number" and (fd.complete ~= nil or type(fd.map) == "number") then
			return LogQuest(fd.id, fd.complete == true)   -- OpenMap
		end
		local qid = rawget(f, "questID")
		if type(qid) == "number" and qid > 0 then return LogQuest(qid) end   -- the game's own quest icon
		f = f.GetParent and f:GetParent()
	end
	if not d then return nil end
	local qd = type(d.QuestData) == "table" and d.QuestData or {}
	local _, logTitle = ns.QuestInLog(d.Id)
	local q = { id = d.Id, title = logTitle or (type(qd.name) == "string" and qd.name) or nil }
	if d.Type == "complete" then q.kind = "turnin"
	elseif d.Type == "available" then q.kind = "pickup"
	else
		q.kind = "objective"
		q.obj = type(d.ObjectiveIndex) == "number" and d.ObjectiveIndex or nil
		q.otype = type(d.Type) == "string" and d.Type or nil
		local od = type(d.ObjectiveData) == "table" and d.ObjectiveData or {}
		if type(od.Description) == "string" then
			q.text = od.Description .. ((type(od.Needed) == "number" and od.Needed > 0) and (": " .. (tonumber(od.Collected) or 0) .. "/" .. od.Needed) or "")
		end
	end
	return q, type(d.Name) == "string" and d.Name or nil, d.Type
end
-- what was under the mouse when the button went down: the click itself can change the map (a city icon zooms into
-- the city, a quest icon opens the quest), so the spot is read before that
local pressed
local function Press()
	pressed = nil
	if not (WorldMapFrame and WorldMapFrame:IsShown()) then return end
	if not IsShiftKeyDown() or IsControlKeyDown() then return end
	local foci = GetMouseFoci and GetMouseFoci() or { Under() }
	local copy = {}
	for i, c in ipairs(foci) do copy[i] = c end
	local ui, mx, my = CursorSpot(WorldMapFrame)
	pressed = { t = GetTime(), foci = copy, ui = ui, mx = mx, my = my }
end
local function PinClick()
	local pr = pressed
	pressed = nil
	if pr and GetTime() - pr.t > 1.5 then pr = nil end
	if not (WorldMapFrame and WorldMapFrame:IsShown()) then return end
	if not IsShiftKeyDown() or IsControlKeyDown() or (ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()) then return end
	-- every frame under the mouse (an icon can sit under another map add-on's frame): the first with a quest
	if ns.mouseDown and not pr then return end   -- the press did not start on the map with Shift held
	local foci = pr and pr.foci or (GetMouseFoci and GetMouseFoci() or { Under() })
	local f, q, who, kind
	local qlog = WorldMapFrame.QuestLog or QuestMapFrame
	local function inLog(c)
		for _ = 1, 15 do
			if not c then return false end
			if c == qlog then return true end
			c = c.GetParent and c:GetParent()
		end
		return false
	end
	-- under the world map but not its scroll area: another map add-on's own layer (OpenMap moves its icons onto its
	-- stitched map in combat). Only a quest icon there counts.
	local function inMap(c)
		for _ = 1, 15 do
			if not c then return false end
			if c == WorldMapFrame then return true end
			c = c.GetParent and c:GetParent()
		end
		return false
	end
	for _, c in ipairs(foci) do
		-- the quest list beside (or, full screen, over) the map is on top: that click is for the quest list
		if not f and qlog and inLog(c) then return end
		if OnMap(c) then
			f = f or c
			q, who, kind = QuestOf(c)
			if q then f = c; break end
		elseif inMap(c) then
			local q2, who2, kind2 = QuestOf(c)
			if q2 then f, q, who, kind = c, q2, who2, kind2; break end
		end
	end
	if not f then return end
	local ui, mx, my
	if pr then ui, mx, my = pr.ui, pr.mx, pr.my else ui, mx, my = CursorSpot(WorldMapFrame) end
	if not GoTo(ui, mx, my) then return end
	if not q then q = TipQuest() end
	local g = S.goal
	if g then
		g.quest = q
		g.name = who or (q and q.title) or TipName(f) or g.name
		if JunhotsTravelCharDB.goal then JunhotsTravelCharDB.goal.quest, JunhotsTravelCharDB.goal.name = g.quest, g.name end
		-- the plan was made before the name was known: name its end too
		if S.plan then for _, l in ipairs(S.plan.legs) do if l.to and l.to.key == "T" then l.to.name = g.name end end end
	end
	-- Questie asks "hide this quest?" on a Shift+click of a quest giver: that click was for us
	if kind == "available" and StaticPopup_Hide then C_Timer.After(0, function() StaticPopup_Hide("QUESTIE_CONFIRMHIDE") end) end
	ns.Refresh()
end
function ns.PinClickInit()
	if ns.pinInit then return end
	ns.pinInit = true
	local f = CreateFrame("Frame")
	local ok = pcall(f.RegisterEvent, f, "GLOBAL_MOUSE_UP")
	if not ok then return end
	ns.mouseDown = pcall(f.RegisterEvent, f, "GLOBAL_MOUSE_DOWN") or nil
	f:SetScript("OnEvent", function(_, ev, button)
		if button ~= "LeftButton" then return end
		if ev == "GLOBAL_MOUSE_DOWN" then ns.Safe("pin click", Press) else ns.Safe("pin click", PinClick) end
	end)
	-- a Shift+click on the game's own map icons (a city, a quest) is ours: no zooming in, no quest window
	if WorldMapFrame and WorldMapFrame.AddGlobalPinMouseActionHandler then
		pcall(WorldMapFrame.AddGlobalPinMouseActionHandler, WorldMapFrame, function(_, _, button)
			return (button == nil or button == "LeftButton") and IsShiftKeyDown() and not IsControlKeyDown()
				and not (ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()) or false
		end, 1002)
	end
end

-- ---------- the game's flight map: mark the flight point to pick ----------
-- The game's gold ring round its button (its dark edge stands out on the yellow map), the game's arrow bobbing
-- above it, and "Fly here" under it (only when your next flight starts at this flight master).
local taxiMark
local function MakeTaxiMark(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetSize(40, 40)
	local ring = f:CreateTexture(nil, "OVERLAY")
	ring:SetPoint("CENTER", 0.3, -1.7)
	if not ns.Atlas(ring, "worldquest-tracker-ring-selected", 30, 30) then ring:SetSize(1, 1); ring:SetColorTexture(0, 0, 0, 0) end
	local glow = f:CreateTexture(nil, "ARTWORK")
	glow:SetPoint("CENTER")
	if not ns.Atlas(glow, "ArtifactsFX-YellowRing", 40, 40) then glow:SetSize(1, 1); glow:SetColorTexture(0, 0, 0, 0) end
	glow:SetVertexColor(0.3, 1, 0.3)
	local arrow = f:CreateTexture(nil, "OVERLAY")
	if ns.Atlas(arrow, "Navigation-Tracked-Arrow", 22, 18) then arrow:SetRotation(math.pi) else arrow:SetSize(1, 1); arrow:SetColorTexture(0, 0, 0, 0) end
	arrow:SetPoint("BOTTOM", f, "CENTER", 0, 15)
	local label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	label:SetPoint("TOP", f, "CENTER", 0, -15)
	local font, size = label:GetFont()
	if font then label:SetFont(font, (size or 10) + 1, "OUTLINE") end
	label:SetText("Fly here")
	-- the arrow bobs (its own animation, so the ring and words stay still)
	if arrow.CreateAnimationGroup then
		local ag = arrow:CreateAnimationGroup()
		ag:SetLooping("BOUNCE")
		local m = ag:CreateAnimation("Translation")
		m:SetOffset(0, -4)
		m:SetDuration(0.6)
		if m.SetSmoothing then m:SetSmoothing("IN_OUT") end
		local g2 = glow:CreateAnimationGroup()
		g2:SetLooping("BOUNCE")
		local a = g2:CreateAnimation("Alpha")
		if a.SetFromAlpha then a:SetFromAlpha(0.9); a:SetToAlpha(0.35) end
		a:SetDuration(0.6)
		f.pulse = { ag, g2 }
	end
	return f
end
function ns.TaxiMark()
	if taxiMark then taxiMark:Hide() end
	local plan = S.plan
	if not (plan and C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and GetTaxiMapID and TaxiNodeGetType) then return end
	local fly
	for _, l in ipairs(plan.legs) do if l.k == "fly" then fly = l; break end end
	if not fly then return end
	local map = GetTaxiMapID()
	if not map then return end
	local slot, here
	for _, node in ipairs(C_TaxiMap.GetAllTaxiNodes(map) or {}) do
		if node.nodeID == fly.b then slot = node.slotIndex end
		if node.nodeID == fly.a and node.slotIndex and TaxiNodeGetType(node.slotIndex) == "CURRENT" then here = true end
	end
	if not (slot and here) then return end
	local b = _G["TaxiButton" .. slot]
	if not (b and b:IsShown()) then return end
	if not taxiMark then taxiMark = MakeTaxiMark(b:GetParent()) end
	taxiMark:SetParent(b:GetParent())
	taxiMark:SetFrameLevel(b:GetFrameLevel() + 2)
	taxiMark:ClearAllPoints()
	taxiMark:SetPoint("CENTER", b, "CENTER")
	taxiMark:Show()
	ns.taxiMark = taxiMark
	for _, ag in ipairs(taxiMark.pulse or {}) do ag:Play() end
end
