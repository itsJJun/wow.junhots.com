-- Draws your way on the world map: walking (gold), flights along their real curves (green), boats and zeppelins (blue).
local _, ns = ...
local P = ns.Planner
local D = ns.D
local S = ns.state

local COLOR = {
	walk = { 1, 0.82, 0.2, 0.9 },
	fly = { 0.3, 1, 0.3, 0.95 },
	boat = { 0.35, 0.7, 1, 0.95 }, zeppelin = { 0.35, 0.7, 1, 0.95 }, tram = { 0.35, 0.7, 1, 0.95 }, lift = { 0.35, 0.7, 1, 0.95 },
	portal = { 0.8, 0.55, 1, 0.95 }, passage = { 0.8, 0.55, 1, 0.95 },
}

local provider
local function MakeProvider()
	if provider or not (WorldMapFrame and MapCanvasDataProviderMixin and WorldMapFrame.AddDataProvider) then return end
	provider = CreateFromMixins(MapCanvasDataProviderMixin)
	local lines, dots, nl, nd = {}, {}, 0, 0

	function provider:OnAdded(map)
		MapCanvasDataProviderMixin.OnAdded(self, map)
		local c = map:GetCanvas()
		self.f = CreateFrame("Frame", nil, c)
		self.f:SetAllPoints(c)
		self.f:SetFrameLevel(c:GetFrameLevel() + 1500)
	end
	function provider:RemoveAllData()
		for i = 1, #lines do lines[i]:Hide() end
		for i = 1, #dots do dots[i]:Hide() end
		nl, nd = 0, 0
	end
	function provider:OnCanvasScaleChanged() self:RefreshAllData() end

	local W, H, mapID, thick
	local function pos(cont, x, y)
		local _, p = C_Map.GetMapPosFromWorldPos(cont, CreateVector2D(x, y), mapID)
		if not p then return nil end
		local px, py = p:GetXY()
		return px * W, py * H, px, py
	end
	local function seg(cont, x1, y1, x2, y2, col)
		local ax, ay, u1, v1 = pos(cont, x1, y1)
		local bx, by, u2, v2 = pos(cont, x2, y2)
		if not (ax and bx) then return end
		if (u1 < -0.2 and u2 < -0.2) or (u1 > 1.2 and u2 > 1.2) or (v1 < -0.2 and v2 < -0.2) or (v1 > 1.2 and v2 > 1.2) then return end
		nl = nl + 1
		local l = lines[nl]
		if not l then l = provider.f:CreateLine(nil, "OVERLAY"); lines[nl] = l end
		l:SetColorTexture(col[1], col[2], col[3], col[4])
		l:SetThickness(thick)
		l:SetStartPoint("TOPLEFT", provider.f, ax, -ay)
		l:SetEndPoint("TOPLEFT", provider.f, bx, -by)
		l:Show()
	end
	local function dot(cont, x, y, col, size)
		local ax, ay, u, v = pos(cont, x, y)
		if not ax or u < 0 or u > 1 or v < 0 or v > 1 then return end
		nd = nd + 1
		local t = dots[nd]
		if not t then t = provider.f:CreateTexture(nil, "OVERLAY", nil, 7); t:SetTexture("Interface\\COMMON\\Indicator-Gray"); dots[nd] = t end
		t:SetVertexColor(col[1], col[2], col[3], 1)
		t:SetSize(size, size)
		t:ClearAllPoints()
		t:SetPoint("CENTER", provider.f, "TOPLEFT", ax, -ay)
		t:Show()
	end

	function provider:RefreshAllData()
		self:RemoveAllData()
		local plan = S.plan
		if not plan or not S.goal or not self.f then return end
		local map = self:GetMap()
		mapID = map:GetMapID()
		if not mapID then return end
		W, H = self.f:GetWidth(), self.f:GetHeight()
		local scale = (map.GetCanvasScale and map:GetCanvasScale()) or 1
		thick = 3 / scale
		local here = ns.Here()
		for i, l in ipairs(plan.legs) do
			local col = COLOR[l.k] or COLOR.walk
			local a = (i == 1 and here and l.k == "walk") and here or l.from
			if l.k == "fly" then
				for _, h in ipairs(l.hops) do
					local c = P.Curve(h[1], h[2])
					local cont = D.taxi[h[1]][1]
					if c then
						for j = 1, #c - 3, 2 do seg(cont, c[j], c[j + 1], c[j + 2], c[j + 3], col) end
					end
				end
			elseif l.k == "walk" then
				local prev = (i == 1 and here) or l.path[1]
				for j = (i == 1 and l.at or 2), #l.path do
					local q = l.path[j]
					local r = prev.map == q.map and P.Round(prev, q)
					if r then seg(q.map, prev.x, prev.y, r.x, r.y, col); prev = r end
					if prev.map == q.map then seg(q.map, prev.x, prev.y, q.x, q.y, col) end
					prev = q
				end
			elseif a.map == l.to.map then
				seg(a.map, a.x, a.y, l.to.x, l.to.y, col)
			end
			if i > 1 or l.k ~= "walk" then dot(l.from.map, l.from.x, l.from.y, col, 10 / scale) end
		end
		local g = S.goal
		dot(g.map, g.x, g.y, COLOR.walk, 14 / scale)
	end

	WorldMapFrame:AddDataProvider(provider)
end

function ns.Draw()
	MakeProvider()
	if provider and WorldMapFrame:IsShown() then provider:RefreshAllData() end
end

-- Shift+click the world map: puts the game's own map pin there (so the game shows it too), and the route follows it.
function ns.MapClickInit()
	local sc = WorldMapFrame and WorldMapFrame.ScrollContainer
	if not sc or sc.jtClick then return end
	sc.jtClick = true
	-- read the spot when the button goes down: a click can open another map before the button comes up
	local down
	sc:HookScript("OnMouseDown", function(self, button)
		down = nil
		if button ~= "LeftButton" or not IsShiftKeyDown() or not self.GetNormalizedCursorPosition then return end
		local mx, my = self:GetNormalizedCursorPosition()
		down = { WorldMapFrame:GetMapID(), mx, my }
	end)
	sc:HookScript("OnMouseUp", function(self, button)
		local d = down
		down = nil
		if button ~= "LeftButton" or not d then return end
		local mapID, mx, my = d[1], d[2], d[3]
		if not (mapID and mx and my) or mx < 0 or mx > 1 or my < 0 or my > 1 then return end
		if C_Map.CanSetUserWaypointOnMap and C_Map.CanSetUserWaypointOnMap(mapID) and UiMapPoint and C_Map.SetUserWaypoint then
			C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(mapID, mx, my))   -- USER_WAYPOINT_UPDATED plans the route
			if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
		else
			local g = ns.WorldFromMap(mapID, mx, my)
			if g then
				local info = C_Map.GetMapInfo(mapID)
				g.name = string.format("%.1f, %.1f", mx * 100, my * 100) .. (info and info.name and (" in " .. info.name) or "")
				ns.SetGoal(g, "click")
			end
		end
	end)
end
