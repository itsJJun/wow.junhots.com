-- Compass bar (Settings, off by default): a thin line of ticks across the top of the screen that turns with you;
-- the game's arrow marks the way to go, with the distance under it. No box: ticks and letters fade out at both ends.
local _, ns = ...
local S = ns.state
local P = ns.Planner
local canaccess = canaccessvalue or function() return true end
local pi, abs, floor = math.pi, math.abs, math.floor
local TWO = 2 * pi

local W, H = 320, 30
local SPAN = math.rad(150)        -- how much of the world the bar shows
local HALF = SPAN / 2
local EASE = 18
local LETTERS = { [0] = "N", [45] = "NW", [90] = "W", [135] = "SW", [180] = "S", [225] = "SE", [270] = "E", [315] = "NE" }

local bar, ticks, labels
local function Rel(b, facing) return (b - facing + pi) % TWO - pi end   -- + = to your left
local function X(rel) return -rel / HALF * (W / 2) end
local function Fade(x) local t = abs(x) / (W / 2); return math.max(0, math.min(1, (1 - t) / 0.35)) end

local function Make()
	bar = CreateFrame("Frame", "JunhotsTravelCompass", UIParent)
	bar:SetSize(W, H)
	bar:SetMovable(true)
	bar:EnableMouse(true)
	bar:RegisterForDrag("LeftButton")
	bar:SetClampedToScreen(true)
	bar:SetScript("OnDragStart", bar.StartMoving)
	bar:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local point, _, rel, x, y = self:GetPoint(1)
		JunhotsTravelDB.compassPos = { point, rel, x, y }
	end)
	local p = JunhotsTravelDB.compassPos
	if p then bar:SetPoint(p[1], UIParent, p[2] or p[1], p[3], p[4]) else bar:SetPoint("TOP", UIParent, "TOP", 0, -24) end
	-- thin gold hairline, fading at both ends (short pieces with their own alpha)
	bar.line = {}
	for i = 0, 31 do
		local t = bar:CreateTexture(nil, "BACKGROUND")
		t:SetColorTexture(0.86, 0.7, 0.35, 1)
		local x0 = -W / 2 + i * W / 32
		t:SetSize(W / 32, 1)
		t:SetPoint("LEFT", bar, "CENTER", x0, -2)
		t:SetAlpha(0.55 * Fade(x0 + W / 64))
		bar.line[i] = t
	end
	ticks, labels = {}, {}
	for deg = 0, 345, 15 do
		if LETTERS[deg] then
			local f = bar:CreateFontString(nil, "ARTWORK", deg % 90 == 0 and "GameFontNormalSmall" or "GameFontDisableSmall")
			f:SetText(LETTERS[deg])
			labels[#labels + 1] = { f = f, b = math.rad(deg) }
		else
			local t = bar:CreateTexture(nil, "ARTWORK")
			t:SetColorTexture(0.85, 0.78, 0.6, 1)
			t:SetSize(1, 5)
			ticks[#ticks + 1] = { t = t, b = math.rad(deg) }
		end
	end
	local m = bar:CreateTexture(nil, "OVERLAY")
	if not ns.Atlas(m, "Navigation-Tracked-Arrow", 22, 22) then
		m:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\arrow"); m:SetSize(18, 18)
	end
	bar.mark = m
	local glow = bar:CreateTexture(nil, "ARTWORK")
	if not ns.Atlas(glow, "ArtifactsFX-YellowRing", 30, 30) then glow:SetSize(1, 1); glow:SetColorTexture(0, 0, 0, 0) end
	glow:SetVertexColor(0.45, 1, 0.45)
	bar.glow = glow
	local d = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	bar.dist = d
	bar:SetScript("OnUpdate", function(self, el) ns.Safe("compass", ns.CompassUpdate, el) end)
	bar:Hide()
end

local shown
function ns.CompassUpdate(el)
	local facing = GetPlayerFacing and GetPlayerFacing()
	if not (facing and canaccess(facing)) then return end
	-- ease the heading like the arrow, so the ticks glide
	local h = bar.h
	if not h then h = facing else h = (h + Rel(facing, h) * (1 - math.exp(-EASE * (el or 0)))) % TWO end
	bar.h = h
	for _, k in ipairs(ticks) do
		local rel = Rel(k.b, h)
		if abs(rel) < HALF then
			local x = X(rel)
			k.t:ClearAllPoints(); k.t:SetPoint("BOTTOM", bar, "CENTER", x, -2); k.t:SetAlpha(0.8 * Fade(x)); k.t:Show()
		else k.t:Hide() end
	end
	for _, k in ipairs(labels) do
		local rel = Rel(k.b, h)
		if abs(rel) < HALF then
			local x = X(rel)
			k.f:ClearAllPoints(); k.f:SetPoint("BOTTOM", bar, "CENTER", x, 0); k.f:SetAlpha(Fade(x)); k.f:Show()
		else k.f:Hide() end
	end
	local b = ns.ArrowBearing and ns.ArrowBearing()
	if not b then bar.mark:Hide(); bar.glow:Hide(); bar.dist:SetText(""); return end
	local rel = Rel(b, h)
	local edge = abs(rel) > HALF * 0.92
	local x = X(math.max(-HALF * 0.92, math.min(HALF * 0.92, rel)))
	-- points down at the way; at an end of the bar it points out (turn that way)
	bar.mark:SetRotation(edge and (rel > 0 and pi / 2 or -pi / 2) or pi)
	bar.mark:ClearAllPoints(); bar.mark:SetPoint("BOTTOM", bar, "CENTER", x, 6); bar.mark:Show()
	local k = 1 - math.min(1, math.max(0, (abs(rel) - 0.1) / 0.3))
	bar.glow:ClearAllPoints(); bar.glow:SetPoint("CENTER", bar.mark, "CENTER", 0, 0); bar.glow:SetAlpha(k); bar.glow:Show()
	bar.dist:ClearAllPoints(); bar.dist:SetPoint("TOP", bar, "CENTER", x, -6)
	bar.dist:SetText(ns.ArrowDistanceText and ns.ArrowDistanceText() or "")
end

-- show it when it's on and you have somewhere to go
function ns.CompassRefresh()
	local want = JunhotsTravelDB.compass == true and S.goal ~= nil and not S.arrived
	if want and not bar then Make() end
	if bar then bar:SetShown(want) end
end
