-- Settings (1.10.6, 28 Nov): our own window (pages on the left, help for what the mouse is over at the bottom), opened by
-- the minimap button, /jt settings, or the "Open settings" button on Esc > Options > AddOns > Junhots Travel.
-- Everything also works by /jt commands.
local _, ns = ...

local MEDIA = "Interface\\AddOns\\JunhotsTravel\\media\\"
local win, outer, preview, mmPreview
local panel, y          -- the page being built and the next free row on it
local controls = {}     -- each has :Sync() to show the saved value

local function DB() return JunhotsTravelDB end
local function Changed(what)
	if what == "arrow" then ns.ArrowLayout(); ns.UIReset() end
	if what == "plan" then ns.Safe("plan", ns.Replan, true) end
	ns.Refresh()
	if ns.MinimapUpdate then ns.MinimapUpdate() end
	if preview then preview.Sync() end
end

-- the help line at the bottom of the window: what the mouse is over
local HINT = "Point at a setting to see what it does."
local function Hint(f, title, tip)
	if not tip then return end
	f:HookScript("OnEnter", function() if win then win.help:SetText("|cffffd100" .. title .. ":|r " .. tip) end end)
	f:HookScript("OnLeave", function() if win then win.help:SetText(HINT) end end)
end

local LX, VX = 0, 170    -- label column and value column, from the page's left edge
local function Label(text, dy)
	local l = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	l:SetPoint("TOPLEFT", LX, y - (dy or 6))
	l:SetJustifyH("LEFT")
	l:SetText(text)
	return l
end
-- a hover area over a whole row (label to value), so the help line shows wherever you point on it
local function RowHint(title, tip, h)
	local r = CreateFrame("Frame", nil, panel)
	r:SetPoint("TOPLEFT", LX, y)
	r:SetPoint("RIGHT", panel, "RIGHT")
	r:SetHeight(h or 26)
	r:EnableMouse(false)
	r:SetMouseMotionEnabled(true)
	Hint(r, title, tip)
	return r
end

local function Check(text, tip, get, set)
	local cb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
	cb:SetPoint("TOPLEFT", LX - 4, y)
	cb:SetSize(26, 26)
	local label = type(cb.Text) == "table" and cb.Text or cb:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:ClearAllPoints()
	label:SetPoint("LEFT", cb, "RIGHT", 4, 1)
	label:SetFontObject("GameFontHighlight")
	label:SetText(text)
	cb:SetHitRectInsets(0, -math.max(200, (tonumber(label:GetStringWidth()) or 200) + 8), 0, 0)
	cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false) end)
	Hint(cb, text, tip)
	cb.Sync = function(self) self:SetChecked(get()) end
	controls[#controls + 1] = cb
	y = y - 30
	return cb
end

-- a row of round choices
local function Choice(text, tip, options, get, set)
	Label(text)
	RowHint(text, tip)
	local x, buttons = VX, {}
	for _, o in ipairs(options) do
		local rb = CreateFrame("CheckButton", nil, panel, "UIRadioButtonTemplate")
		rb:SetPoint("TOPLEFT", x, y - 4)
		local t = (type(rb.text) == "table" and rb.text) or (type(rb.Text) == "table" and rb.Text) or rb:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
		t:ClearAllPoints()
		t:SetPoint("LEFT", rb, "RIGHT", 4, 0)
		t:SetFontObject("GameFontHighlight")
		t:SetText(o[2])
		local w = math.max(60, (tonumber(t:GetStringWidth()) or 60) + 14)
		rb:SetHitRectInsets(0, -w, 0, 0)
		rb:SetScript("OnClick", function()
			set(o[1])
			for _, b in ipairs(buttons) do b:Sync() end
		end)
		Hint(rb, text, tip)
		rb.Sync = function(self) self:SetChecked(get() == o[1]) end
		buttons[#buttons + 1] = rb
		controls[#controls + 1] = rb
		x = x + 26 + w
	end
	y = y - 32
end

local function Slider(text, tip, lo, hi, step, fmt, get, set)
	Label(text)
	RowHint(text, tip)
	local ok, s = pcall(CreateFrame, "Slider", nil, panel, "OptionsSliderTemplate")
	if not ok or not s then
		s = CreateFrame("Slider", nil, panel)
		s:SetOrientation("HORIZONTAL")
		s:SetSize(200, 16)
		s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
		local bg = s:CreateTexture(nil, "BACKGROUND")
		bg:SetColorTexture(0, 0, 0, 0.5)
		bg:SetPoint("LEFT", 0, 0); bg:SetPoint("RIGHT", 0, 0); bg:SetHeight(6)
	end
	s:SetWidth(200)
	s:SetPoint("TOPLEFT", VX + 4, y - 5)
	s:SetMinMaxValues(lo, hi)
	s:SetValueStep(step)
	if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
	for _, k in ipairs({ "Low", "High", "Text" }) do
		local r = s[k] or (s:GetName() and _G[s:GetName() .. k])
		if type(r) == "table" and r.SetText then r:SetText("") end
	end
	local val = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	val:SetPoint("LEFT", s, "RIGHT", 12, 0)
	local syncing
	s:SetScript("OnValueChanged", function(_, v)
		v = math.floor(v / step + 0.5) * step
		val:SetText(fmt(v))
		if not syncing then set(v) end
	end)
	Hint(s, text, tip)
	s.Sync = function(self)
		syncing = true
		self:SetValue(get())
		val:SetText(fmt(get()))
		syncing = false
	end
	controls[#controls + 1] = s
	y = y - 34
end

local function Button(text, tip, onClick, x)
	local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	b:SetSize(170, 24)
	b:SetPoint("TOPLEFT", x or LX, y)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	Hint(b, text, tip)
	y = y - 34
	return b
end

-- Your way's colours: a live preview on real map art (Tanaris tiles: a flight in to Gadgetzan, then walking to
-- Steamwheedle Port) beside the same walk on a round minimap, and a row of round gems per kind.
local PW, PH = 400, 128
local function bez(a, c, b, n, P)
	local out = {}
	for i = 0, n do
		local t = i / n
		out[#out + 1] = { P((1 - t) ^ 2 * a[1] + 2 * (1 - t) * t * c[1] + t * t * b[1], (1 - t) ^ 2 * a[2] + 2 * (1 - t) * t * c[2] + t * t * b[2]) }
	end
	return out
end
local function Frame2(f, x0, y0, x1, y1)
	-- a dark line, then a thin muted gold one
	local o = f:CreateTexture(nil, "BACKGROUND", nil, -2)
	o:SetPoint("TOPLEFT", x0 - 2, y0 + 2); o:SetPoint("BOTTOMRIGHT", x1 + 2, y1 - 2); o:SetColorTexture(0, 0, 0, 1)
	local g = f:CreateTexture(nil, "BACKGROUND", nil, -1)
	g:SetPoint("TOPLEFT", x0 - 1, y0 + 1); g:SetPoint("BOTTOMRIGHT", x1 + 1, y1 - 1); g:SetColorTexture(0.47, 0.39, 0.24, 1)
end
local function beadsAlong(f, pts, step, keep, layer)
	local out, acc, last = {}, 0, pts[1]
	for i = 2, #pts do
		local q = pts[i]
		acc = acc + math.sqrt((q[1] - last[1]) ^ 2 + (q[2] - last[2]) ^ 2); last = q
		if acc >= step and keep(q) then
			local t = ns.NoSnap(f:CreateTexture(nil, "ARTWORK", nil, layer or 1))
			t:SetSize(18, 18)
			t:SetPoint("CENTER", f, "TOPLEFT", q[1], q[2])
			out[#out + 1] = t
			acc = 0
		end
	end
	return out
end
local function Preview()
	local f = CreateFrame("Frame", nil, panel)
	f:SetSize(PW, PH)
	f:SetPoint("TOPLEFT", LX, y - 2)
	f:SetClipsChildren(true)
	local holder = CreateFrame("Frame", nil, panel)   -- the frame lines sit outside the clipped map
	holder:SetAllPoints(f)
	holder:SetFrameLevel(math.max(0, f:GetFrameLevel() - 1))
	Frame2(holder, 0, 0, 0, 0)
	-- the map: zone-map pixels CX..CX+CW (tiles are 256 wide, 4 a row: Tanaris2 and Tanaris3 hold this part)
	local CX, CY, CW = 440, 88, 330
	local sc = PW / CW
	local CH = PH / sc
	for _, t in ipairs({ { 2, 256 }, { 3, 512 } }) do
		local x0, x1 = math.max(CX, t[2]), math.min(CX + CW, t[2] + 256)
		local tex = f:CreateTexture(nil, "BACKGROUND")
		tex:SetTexture("Interface\\WorldMap\\Tanaris\\Tanaris" .. t[1])
		tex:SetTexCoord((x0 - t[2]) / 256, (x1 - t[2]) / 256, CY / 256, (CY + CH) / 256)
		tex:SetPoint("TOPLEFT", (x0 - CX) * sc, 0)
		tex:SetSize((x1 - x0) * sc, PH)
	end
	local v = f:CreateTexture(nil, "BORDER")
	v:SetAllPoints(); v:SetTexture(MEDIA .. "vignette")
	local function P(x, y0) return (x - CX) * sc, -(y0 - CY) * sc end
	local FM, PIN, BEND = { 513, 168 }, { 668, 147 }, { 590, 185 }
	local function lines(pts)
		local ls = {}
		for i = 2, #pts do
			local l = ns.NoSnap(f:CreateLine(nil, "ARTWORK"))
			l:SetThickness(24)
			l:SetStartPoint("TOPLEFT", f, pts[i - 1][1], pts[i - 1][2])
			l:SetEndPoint("TOPLEFT", f, pts[i][1], pts[i][2])
			ls[#ls + 1] = l
		end
		return ls
	end
	f.fly = lines(bez({ 440, 92 }, { 470, 150 }, FM, 24, P))
	f.walkLine = lines(bez(FM, BEND, PIN, 24, P))
	local walk = bez(FM, BEND, PIN, 160, P)
	local a, b = walk[1], walk[#walk]
	f.beads = beadsAlong(f, walk, 11, function(q)
		return math.sqrt((q[1] - a[1]) ^ 2 + (q[2] - a[2]) ^ 2) > 12 and math.sqrt((q[1] - b[1]) ^ 2 + (q[2] - b[2]) ^ 2) > 12
	end)
	local function icon(at, atlas, file)
		local t = f:CreateTexture(nil, "OVERLAY")
		t:SetPoint("CENTER", f, "TOPLEFT", P(at[1], at[2]))
		if not (atlas and ns.Atlas(t, atlas, 22, 22)) then t:SetTexture(file); t:SetSize(22, 22) end
	end
	icon(FM, ns.FlyAtlas and ns.FlyAtlas(), MEDIA .. "stop_fly")
	icon(PIN, "Waypoint-MapPin-Tracked", MEDIA .. "pin")
	local cap = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	cap:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, -6)
	cap:SetText("World map")

	-- the round minimap: the same walk, closer, you in the middle
	local MD, MZ = PH, 1.9
	local m = CreateFrame("Frame", nil, panel)
	m:SetSize(MD, MD)
	m:SetPoint("TOPLEFT", f, "TOPRIGHT", 28, 0)
	local round = m.CreateMaskTexture ~= nil
	local mask
	if round then
		mask = m:CreateMaskTexture()
		mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
		mask:SetAllPoints()
	end
	local function masked(t) if mask and t.AddMaskTexture then t:AddMaskTexture(mask) end return t end
	-- its edge: a dark ring and a thin muted gold one, also round
	for i, c in ipairs({ { 3, 0, 0, 0 }, { 2, 0.47, 0.39, 0.24 } }) do
		local r = m:CreateTexture(nil, "BACKGROUND", nil, i - 3)
		r:SetPoint("TOPLEFT", -c[1], c[1]); r:SetPoint("BOTTOMRIGHT", c[1], -c[1])
		r:SetColorTexture(c[2], c[3], c[4], 1)
		if round then
			local rm = m:CreateMaskTexture()
			rm:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
			rm:SetAllPoints(r)
			r:AddMaskTexture(rm)
		end
	end
	local MCX, MCY = 560, 176        -- zone-map spot in the middle (you, walking)
	local ms = sc * MZ
	local half = MD / 2 / ms
	local tex = masked(m:CreateTexture(nil, "BACKGROUND"))
	tex:SetTexture("Interface\\WorldMap\\Tanaris\\Tanaris3")
	tex:SetTexCoord((MCX - half - 512) / 256, (MCX + half - 512) / 256, (MCY - half) / 256, (MCY + half) / 256)
	tex:SetAllPoints()
	tex:SetVertexColor(0.85, 0.85, 0.85)
	local function MP(x, y0) return (x - MCX) * ms + MD / 2, -((y0 - MCY) * ms + MD / 2) end
	local mwalk = bez(FM, BEND, PIN, 300, MP)
	local start = 1
	for i, q in ipairs(mwalk) do
		if (q[1] - MD / 2) ^ 2 + (q[2] + MD / 2) ^ 2 < (mwalk[start][1] - MD / 2) ^ 2 + (mwalk[start][2] + MD / 2) ^ 2 then start = i end
	end
	local rest = {}
	for i = start, #mwalk do rest[#rest + 1] = mwalk[i] end
	m.beads = beadsAlong(m, rest, 11, function(q)
		local dx, dy = q[1] - MD / 2, q[2] + MD / 2
		local r2 = dx * dx + dy * dy
		return r2 > 81 and r2 < (MD / 2 - 6) ^ 2
	end)
	m.lines = {}
	for i = 2, #rest, 12 do
		local p0, p1 = rest[math.max(1, i - 12)], rest[i]
		local dx, dy = p1[1] - MD / 2, p1[2] + MD / 2
		if dx * dx + dy * dy < (MD / 2 - 4) ^ 2 then
			local l = ns.NoSnap(m:CreateLine(nil, "ARTWORK"))
			l:SetThickness(24)
			l:SetStartPoint("TOPLEFT", m, p0[1], p0[2]); l:SetEndPoint("TOPLEFT", m, p1[1], p1[2])
			m.lines[#m.lines + 1] = l
		end
	end
	local arrow = m:CreateTexture(nil, "OVERLAY")
	arrow:SetTexture("Interface\\Minimap\\MinimapArrow")
	arrow:SetSize(26, 26)
	arrow:SetPoint("CENTER")
	if arrow.SetRotation then
		local nx, ny = rest[math.min(#rest, 20)][1] - MD / 2, rest[math.min(#rest, 20)][2] + MD / 2
		arrow:SetRotation(math.atan2(-nx, ny))   -- face along the way
	end
	local mcap = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	mcap:SetPoint("TOP", m, "BOTTOM", 0, -6)
	mcap:SetText("Minimap")
	function f.Sync()
		local lineC, dotC = ns.LookTex()
		local asLine = ns.TrailStyle() == "line"
		for _, l in ipairs(f.fly) do l:SetTexture(MEDIA .. "line_" .. lineC) end
		for _, l in ipairs(f.walkLine) do l:SetTexture(MEDIA .. "line_" .. dotC); l:SetShown(asLine) end
		for _, t in ipairs(f.beads) do t:SetTexture(MEDIA .. "dot_" .. dotC); t:SetShown(not asLine) end
		for _, l in ipairs(m.lines) do l:SetTexture(MEDIA .. "line_" .. dotC); l:SetShown(asLine) end
		for _, t in ipairs(m.beads) do t:SetTexture(MEDIA .. "dot_" .. dotC); t:SetShown(not asLine) end
	end
	preview = f
	controls[#controls + 1] = f
	y = y - PH - 34
end

local function Gems(text, tip, colours, get, set)
	Label(text)
	RowHint(text, tip)
	local name = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	name:SetPoint("TOPLEFT", VX + 8 + #colours * 25 - 2, y - 6)
	local list, ring = {}, panel:CreateTexture(nil, "OVERLAY")
	ring:SetTexture(MEDIA .. "gem_ring"); ring:SetSize(26, 26)
	local function sync()
		local v = get()
		ring:Hide()
		for _, b in ipairs(list) do
			if b.key == v then ring:ClearAllPoints(); ring:SetPoint("CENTER", b); ring:Show(); name:SetText(b.title) end
		end
		if preview then preview.Sync() end
	end
	for i, o in ipairs(colours) do
		local b = CreateFrame("Button", nil, panel)
		b:SetSize(22, 22)
		b:SetPoint("CENTER", panel, "TOPLEFT", VX + 8 + (i - 1) * 25, y - 12)
		b.key, b.title = o[1], o[2]
		local t = b:CreateTexture(nil, "ARTWORK")
		t:SetTexture(MEDIA .. "gem_" .. o[1]); t:SetSize(16, 16); t:SetPoint("CENTER")
		local h = b:CreateTexture(nil, "HIGHLIGHT")
		h:SetTexture(MEDIA .. "gem_ring"); h:SetSize(26, 26); h:SetPoint("CENTER")
		h:SetVertexColor(1, 1, 1, 0.45)
		b:SetScript("OnClick", function() set(o[1]); sync() end)
		b:SetScript("OnEnter", function() if win then win.help:SetText("|cffffd100" .. text .. ":|r " .. o[2]) end end)
		b:SetScript("OnLeave", function() if win then win.help:SetText(HINT) end end)
		list[#list + 1] = b
	end
	controls[#controls + 1] = { Sync = sync }
	y = y - 34
end

local function Text(s, font, w)
	local t = panel:CreateFontString(nil, "ARTWORK", font or "GameFontHighlight")
	t:SetPoint("TOPLEFT", LX, y)
	t:SetWidth(w or 520); t:SetJustifyH("LEFT")
	t:SetText(s)
	y = y - math.max(16, (tonumber(t:GetStringHeight()) or 14)) - 8
	return t
end

-- the window ------------------------------------------------------------------------------------------------------
local WW, WH, NAVW = 760, 520, 160
local pages, navs = {}, {}
local function ShowPage(key)
	for k, p in pairs(pages) do p:SetShown(k == key) end
	for k, b in pairs(navs) do
		local on = k == key
		b.sel:SetShown(on); b.bar:SetShown(on)
		b.text:SetTextColor(on and 1 or 0.86, on and 0.82 or 0.85, on and 0 or 0.81)
	end
	DB().settingsPage = key
end
local function Page(key, title, sub)
	local p = CreateFrame("Frame", nil, win)
	p:SetPoint("TOPLEFT", NAVW + 24, -52)
	p:SetPoint("BOTTOMRIGHT", -24, 40)
	p:Hide()
	pages[key] = p
	panel, y = p, 0
	local t = p:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	t:SetPoint("TOPLEFT", 0, 0)
	t:SetText(title)
	local s = p:CreateFontString(nil, "ARTWORK", "GameFontDisable")
	s:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -6)
	s:SetText(sub)
	y = -50
	-- its button on the left
	local i = 0
	for _ in pairs(navs) do i = i + 1 end
	local b = CreateFrame("Button", nil, win)
	b:SetSize(NAVW - 16, 28)
	b:SetPoint("TOPLEFT", 8, -48 - i * 32 - (key == "about" and 18 or 0))
	b.sel = b:CreateTexture(nil, "BACKGROUND"); b.sel:SetAllPoints(); b.sel:SetColorTexture(1, 0.82, 0, 0.1)
	b.bar = b:CreateTexture(nil, "ARTWORK"); b.bar:SetPoint("TOPLEFT"); b.bar:SetPoint("BOTTOMLEFT"); b.bar:SetWidth(2); b.bar:SetColorTexture(1, 0.82, 0, 1)
	local hl = b:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints(); hl:SetColorTexture(1, 1, 1, 0.05)
	b.text = b:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	b.text:SetPoint("LEFT", 14, 0)
	b.text:SetText(title)
	b:SetScript("OnClick", function() ShowPage(key) end)
	navs[key] = b
	return p
end

local function Version()
	local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
	return get and get("JunhotsTravel", "Version") or ""
end

local function BuildWindow()
	win = CreateFrame("Frame", "JunhotsTravelSettings", UIParent)
	win:SetSize(WW, WH)
	win:SetPoint("CENTER")
	win:SetFrameStrata("DIALOG")
	win:SetToplevel(true)
	win:SetClampedToScreen(true)
	win:SetMovable(true)
	win:EnableMouse(true)
	win:Hide()
	if UISpecialFrames then table.insert(UISpecialFrames, "JunhotsTravelSettings") end   -- Esc closes it
	-- body: soft shadow, a black line, a thin bronze line, near black inside
	local function fill(layer, sub, inset, r, g, b, a)
		local t = win:CreateTexture(nil, layer, nil, sub)
		t:SetPoint("TOPLEFT", -inset, inset); t:SetPoint("BOTTOMRIGHT", inset, -inset)
		t:SetColorTexture(r, g, b, a)
		return t
	end
	fill("BACKGROUND", -8, 2, 0, 0, 0, 1)
	fill("BACKGROUND", -7, 1, 0.33, 0.28, 0.19, 1)
	fill("BACKGROUND", -6, 0, 0.06, 0.055, 0.047, 0.97)
	-- title bar (drag to move)
	local bar = CreateFrame("Frame", nil, win)
	bar:SetPoint("TOPLEFT"); bar:SetPoint("TOPRIGHT"); bar:SetHeight(38)
	bar:EnableMouse(true)
	bar:RegisterForDrag("LeftButton")
	bar:SetScript("OnDragStart", function() win:StartMoving() end)
	bar:SetScript("OnDragStop", function() win:StopMovingOrSizing() end)
	local bt = bar:CreateTexture(nil, "BACKGROUND"); bt:SetAllPoints(); bt:SetColorTexture(0.094, 0.086, 0.075, 1)
	local bl = bar:CreateTexture(nil, "ARTWORK"); bl:SetPoint("BOTTOMLEFT"); bl:SetPoint("BOTTOMRIGHT"); bl:SetHeight(1); bl:SetColorTexture(0.24, 0.2, 0.14, 1)
	local icon = bar:CreateTexture(nil, "ARTWORK")
	icon:SetTexture("Interface\\Icons\\Ability_Hunter_Pathfinding")
	icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	icon:SetSize(22, 22); icon:SetPoint("LEFT", 12, 0)
	local title = bar:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("LEFT", icon, "RIGHT", 8, 0)
	title:SetText("Junhots Travel")
	local ver = bar:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	ver:SetPoint("LEFT", title, "RIGHT", 10, -1)
	ver:SetText(Version())
	local close = CreateFrame("Button", nil, bar, "UIPanelCloseButton")
	close:SetPoint("RIGHT", -4, 0)
	close:SetScript("OnClick", function() win:Hide() end)
	-- left list divider and the help line at the bottom
	local div = win:CreateTexture(nil, "ARTWORK"); div:SetPoint("TOPLEFT", NAVW, -39); div:SetPoint("BOTTOMLEFT", NAVW, 34); div:SetWidth(1); div:SetColorTexture(0.17, 0.16, 0.13, 1)
	local foot = win:CreateTexture(nil, "ARTWORK"); foot:SetPoint("BOTTOMLEFT", 0, 34); foot:SetPoint("BOTTOMRIGHT", 0, 34); foot:SetHeight(1); foot:SetColorTexture(0.17, 0.16, 0.13, 1)
	win.help = win:CreateFontString(nil, "ARTWORK", "GameFontDisable")
	win.help:SetPoint("BOTTOMLEFT", 16, 11); win.help:SetPoint("BOTTOMRIGHT", -16, 11)
	win.help:SetJustifyH("LEFT"); win.help:SetWordWrap(false)
	win.help:SetText(HINT)

	Page("arrow", "Arrow", "The arrow on your screen that points the way.")
	Choice("Look", "A ring round the arrow, or just the arrow.", { { "ring", "Ring" }, { "plain", "Arrow only" } },
		function() return ns.ArrowStyle() end, function(v) DB().arrowStyle = v; Changed("arrow") end)
	Choice("In the ring", "What the number under the arrow shows.", { { "distance", "Distance" }, { "time", "Time left" }, { "both", "Both" } },
		function() return ns.ArrowLabel() end, function(v) DB().label = v; Changed() end)
	Slider("Size", "How big the arrow is.", 50, 200, 5, function(v) return v .. "%" end,
		function() return math.floor((DB().scale or 1) * 100 + 0.5) end, function(v) DB().scale = v / 100; Changed("arrow") end)
	Button("Center the arrow", "Moves it to the middle of the screen, side to side. When you drag it, it also snaps to the middle.",
		function() if ns.CenterArrow then ns.CenterArrow() end end, VX)
	y = y - 6
	Check("Compass bar at the top of the screen", "A thin compass that turns with you, marking the way to go. Drag it to move it.",
		function() return DB().compass == true end, function(v) DB().compass = v; Changed() end)
	Check("Game's waypoint marker at your next turn", "The game's own pin out in the world, moved to each turn of your way. It replaces any map pin you placed.",
		function() return DB().marker == true end, function(v) DB().marker = v; Changed() end)

	Page("way", "Your way", "How your way looks on the world map and the minimap.")
	Preview()
	Choice("On the maps", "Walking as dots or as a line.", { { "dots", "Dots" }, { "line", "Line" } },
		function() return ns.TrailStyle() end, function(v) DB().trail = v; Changed() end)
	Choice("Line weight", "Light, Medium or Bold lines and dots. Bold stands out most on busy maps.", { { "light", "Light" }, { "medium", "Medium" }, { "bold", "Bold" } },
		function() return ns.Weight() end, function(v) DB().weight = v; Changed() end)
	Gems("Flying", "the colour of flights, boats and other rides. Changes show at once.", ns.COLOURS or {},
		function() return (ns.LookParts()) end, function(v) DB().lineColour = v; Changed() end)
	Gems("Walking", "the colour of the dots from you to your next place. Changes show at once.", ns.COLOURS or {},
		function() return select(2, ns.LookParts()) end, function(v) DB().dotColour = v; Changed() end)
	Slider("You're there within", "How close counts as arriving: the arrow and your way clear there.", 5, 50, 5, function(v) return v .. " yd" end,
		function() return DB().arrive or 15 end, function(v) DB().arrive = v end)
	Check("Sound when you arrive", "A short ping when you get there.", function() return DB().sound == true end, function(v) DB().sound = v end)

	Page("route", "Route", "What the way may use to get you there faster.")
	Check("Use your Hearthstone", "When it is faster. Set your inn (or use the Hearthstone once) so it knows where it takes you.",
		function() return DB().hearth ~= false end, function(v) DB().hearth = v; Changed("plan") end)
	Check("Use class teleports", "Mage city teleports (with a Rune of Teleportation), Astral Recall, Teleport: Moonglade, when faster.",
		function() return DB().teleports ~= false end, function(v) DB().teleports = v; Changed("plan") end)
	Check("Go round zones far above your level", "Zones 5 or more levels above you. The other side's towns are always avoided.",
		function() return DB().avoidZones ~= false end, function(v) DB().avoidZones = v; Changed("plan") end)

	Page("about", "About", "Junhots Travel " .. Version() .. ", from wow.junhots.com")
	Text("|cffffd100Shift+click|r the world map to go there. Placing the game's map pin works too.")
	Text("|cffffd100/jt clear|r stops the trip.   |cffffd100/jt settings|r opens this window.")
	y = y - 6
	Check("Minimap button", "The round button on your minimap's edge. Left-click: this window. Right-click: stop the trip. Drag it round the edge.",
		function() return DB().mmButton ~= false end, function(v) DB().mmButton = v; if ns.MinimapButtonUpdate then ns.MinimapButtonUpdate() end end)

	win:SetScript("OnShow", function()
		for _, c in ipairs(controls) do c:Sync() end
		ShowPage(pages[DB().settingsPage or ""] and DB().settingsPage or "way")
	end)
end

-- the short page in the game's Options (Esc > Options > AddOns), like other addons: one button that opens the window
local function BuildOptionsPage()
	outer = CreateFrame("Frame")
	outer.name = "Junhots Travel"
	local title = outer:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText("Junhots Travel")
	local sub = outer:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
	sub:SetText("The fastest way to your map pin. Shift+click the world map to go somewhere.")
	local b = CreateFrame("Button", nil, outer, "UIPanelButtonTemplate")
	b:SetSize(170, 26)
	b:SetPoint("TOPLEFT", sub, "BOTTOMLEFT", 0, -18)
	b:SetText("Open settings")
	b:SetScript("OnClick", function()
		if SettingsPanel and SettingsPanel.IsShown and SettingsPanel:IsShown() and HideUIPanel then HideUIPanel(SettingsPanel) end
		if InterfaceOptionsFrame and InterfaceOptionsFrame:IsShown() and HideUIPanel then HideUIPanel(InterfaceOptionsFrame) end
		if win then win:Show() end
	end)
	local hint = outer:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	hint:SetPoint("LEFT", b, "RIGHT", 12, 0)
	hint:SetText("or /jt settings, or the minimap button")
	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		local cat = Settings.RegisterCanvasLayoutCategory(outer, outer.name)
		Settings.RegisterAddOnCategory(cat)
		ns.settingsCategory = cat
	elseif InterfaceOptions_AddCategory then
		InterfaceOptions_AddCategory(outer)
	end
end

-- the minimap button: the game's round tracking border round the travel icon, on the minimap's edge -------------------
local mm
local function MMPlace()
	if not (mm and Minimap) then return end
	local a = math.rad(DB().mmAngle or 200)
	local x, y0 = math.cos(a), math.sin(a)
	local w, h = (Minimap:GetWidth() or 140) / 2 + 10, (Minimap:GetHeight() or 140) / 2 + 10
	local shape = GetMinimapShape and GetMinimapShape() or "ROUND"
	if shape == "SQUARE" then
		-- along the square's edge: push the point out until it meets the side
		local k = 1 / math.max(math.abs(x), math.abs(y0))
		x, y0 = math.max(-1, math.min(1, x * k)), math.max(-1, math.min(1, y0 * k))
		w, h = w - 6, h - 6
	end
	mm:ClearAllPoints()
	mm:SetPoint("CENTER", Minimap, "CENTER", x * w, y0 * h)
end
function ns.MinimapButtonUpdate()
	if not Minimap then return end
	if DB().mmButton == false then if mm then mm:Hide() end return end
	if not mm then
		mm = CreateFrame("Button", "JunhotsTravelMinimapButton", Minimap)
		mm:SetSize(31, 31)
		mm:SetFrameStrata("MEDIUM")
		mm:SetFrameLevel(Minimap:GetFrameLevel() + 8)
		mm:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		mm:RegisterForDrag("LeftButton")
		mm:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
		local bg = mm:CreateTexture(nil, "BACKGROUND")
		bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
		bg:SetSize(20, 20); bg:SetPoint("TOPLEFT", 7, -5)
		local icon = mm:CreateTexture(nil, "ARTWORK")
		icon:SetTexture("Interface\\Icons\\Ability_Hunter_Pathfinding")
		icon:SetSize(17, 17); icon:SetPoint("TOPLEFT", 7, -6)
		icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
		if mm.CreateMaskTexture then
			local mk = mm:CreateMaskTexture()
			mk:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
			mk:SetAllPoints(icon)
			icon:AddMaskTexture(mk)
		end
		local border = mm:CreateTexture(nil, "OVERLAY")
		border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
		border:SetSize(53, 53); border:SetPoint("TOPLEFT")
		mm:SetScript("OnClick", function(_, button)
			if button == "RightButton" then
				if SlashCmdList and SlashCmdList.JUNHOTSTRAVEL then SlashCmdList.JUNHOTSTRAVEL("clear") end
			else
				ns.OpenSettings()
			end
		end)
		mm:SetScript("OnDragStart", function(self)
			self:SetScript("OnUpdate", function()
				local mx, my = Minimap:GetCenter()
				local cx, cy = GetCursorPosition()
				local s = Minimap:GetEffectiveScale()
				DB().mmAngle = math.deg(math.atan2(cy / s - my, cx / s - mx)) % 360
				MMPlace()
			end)
		end)
		mm:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
		mm:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_LEFT")
			GameTooltip:AddLine("Junhots Travel", 1, 0.82, 0)
			local g = ns.state and ns.state.goal
			if g and g.name then GameTooltip:AddLine("Going to " .. g.name, 1, 1, 1, true) end
			GameTooltip:AddLine("Left-click: settings", 0.8, 0.8, 0.8)
			GameTooltip:AddLine("Right-click: stop the trip", 0.8, 0.8, 0.8)
			GameTooltip:Show()
		end)
		mm:SetScript("OnLeave", function() GameTooltip:Hide() end)
	end
	MMPlace()
	mm:Show()
end

local function Build()
	BuildWindow()
	BuildOptionsPage()
	ns.MinimapButtonUpdate()
end

function ns.SettingsInit()
	if win then return end
	ns.Safe("settings", Build)
end

function ns.OpenSettings()
	if not win then return end
	if win:IsShown() then win:Hide() else win:Show() end
end
