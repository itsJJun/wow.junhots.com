-- Settings: Esc > Options > AddOns > Junhots Travel (or /jt settings). Everything also works by /jt commands.
local _, ns = ...

local panel
local controls = {}   -- each has :Sync() to show the saved value

local function DB() return JunhotsTravelDB end
local function Changed(what)
	if what == "arrow" then ns.ArrowLayout(); ns.UIReset() end
	if what == "plan" then ns.Safe("plan", ns.Replan, true) end
	ns.Refresh()
	if ns.MinimapUpdate then ns.MinimapUpdate() end
end

local y
local function Header(text)
	y = y - 14
	local h = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	h:SetPoint("TOPLEFT", 16, y)
	h:SetText(text)
	local line = panel:CreateTexture(nil, "ARTWORK")
	line:SetColorTexture(1, 0.82, 0, 0.25)
	line:SetHeight(1)
	line:SetPoint("LEFT", h, "RIGHT", 8, 0)
	line:SetPoint("RIGHT", panel, "RIGHT", -16, 0)
	y = y - 22
end

local function Check(text, tip, get, set)
	local cb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
	cb:SetPoint("TOPLEFT", 20, y)
	cb:SetSize(26, 26)
	local label = type(cb.Text) == "table" and cb.Text or cb:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:ClearAllPoints()
	label:SetPoint("LEFT", cb, "RIGHT", 4, 1)
	label:SetFontObject("GameFontHighlight")
	label:SetText(text)
	cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false) end)
	if tip then
		cb:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:AddLine(text, 1, 1, 1)
			GameTooltip:AddLine(tip, nil, nil, nil, true)
			GameTooltip:Show()
		end)
		cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
	end
	cb.Sync = function(self) self:SetChecked(get()) end
	controls[#controls + 1] = cb
	y = y - 28
	return cb
end

-- a row of round choices
local function Choice(text, options, get, set)
	local label = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:SetPoint("TOPLEFT", 24, y - 5)
	label:SetWidth(130)
	label:SetJustifyH("LEFT")
	label:SetText(text)
	local x, buttons = 160, {}
	for _, o in ipairs(options) do
		local rb = CreateFrame("CheckButton", nil, panel, "UIRadioButtonTemplate")
		rb:SetPoint("TOPLEFT", x, y - 4)
		local t = (type(rb.text) == "table" and rb.text) or (type(rb.Text) == "table" and rb.Text) or rb:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
		t:ClearAllPoints()
		t:SetPoint("LEFT", rb, "RIGHT", 3, 0)
		t:SetFontObject("GameFontHighlightSmall")
		t:SetText(o[2])
		rb:SetScript("OnClick", function()
			set(o[1])
			for _, b in ipairs(buttons) do b:Sync() end
		end)
		rb.Sync = function(self) self:SetChecked(get() == o[1]) end
		buttons[#buttons + 1] = rb
		controls[#controls + 1] = rb
		x = x + 26 + math.max(60, (tonumber(t:GetStringWidth()) or 60) + 14)
	end
	y = y - 28
end

local function Slider(text, lo, hi, step, fmt, get, set)
	local label = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:SetPoint("TOPLEFT", 24, y - 6)
	label:SetText(text)
	local ok, s = pcall(CreateFrame, "Slider", nil, panel, "OptionsSliderTemplate")
	if not ok or not s then
		s = CreateFrame("Slider", nil, panel)
		s:SetOrientation("HORIZONTAL")
		s:SetSize(180, 16)
		s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
		local bg = s:CreateTexture(nil, "BACKGROUND")
		bg:SetColorTexture(0, 0, 0, 0.5)
		bg:SetPoint("LEFT", 0, 0); bg:SetPoint("RIGHT", 0, 0); bg:SetHeight(6)
	end
	s:SetWidth(180)
	s:SetPoint("TOPLEFT", 166, y - 4)
	s:SetMinMaxValues(lo, hi)
	s:SetValueStep(step)
	if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
	for _, k in ipairs({ "Low", "High", "Text" }) do
		local r = s[k] or (s:GetName() and _G[s:GetName() .. k])
		if type(r) == "table" and r.SetText then r:SetText("") end
	end
	local val = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
	val:SetPoint("LEFT", s, "RIGHT", 10, 0)
	local syncing
	s:SetScript("OnValueChanged", function(_, v)
		v = math.floor(v / step + 0.5) * step
		val:SetText(fmt(v))
		if not syncing then set(v) end
	end)
	s.Sync = function(self)
		syncing = true
		self:SetValue(get())
		val:SetText(fmt(get()))
		syncing = false
	end
	controls[#controls + 1] = s
	y = y - 32
end

local function Build()
	panel = CreateFrame("Frame")
	panel.name = "Junhots Travel"
	local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText("Junhots Travel")
	local sub = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
	sub:SetText("The fastest way to your map pin. Shift+click the world map to go somewhere.")
	y = -56

	Header("Arrow")
	Choice("Look", { { "ring", "Ring" }, { "plain", "Arrow only" } },
		function() return ns.ArrowStyle() end, function(v) DB().arrowStyle = v; Changed("arrow") end)
	Choice("In the ring", { { "distance", "Distance" }, { "time", "Time left" }, { "both", "Both" } },
		function() return ns.ArrowLabel() end, function(v) DB().label = v; Changed() end)
	Slider("Size", 50, 200, 5, function(v) return v .. "%" end,
		function() return math.floor((DB().scale or 1) * 100 + 0.5) end, function(v) DB().scale = v / 100; Changed("arrow") end)

	Header("Your way")
	Choice("On the maps", { { "dots", "Dots" }, { "line", "Line" } },
		function() return ns.TrailStyle() end, function(v) DB().trail = v; Changed() end)
	Slider("You're there within", 5, 50, 5, function(v) return v .. " yd" end,
		function() return DB().arrive or 15 end, function(v) DB().arrive = v end)
	Check("Sound when you arrive", nil, function() return DB().sound == true end, function(v) DB().sound = v end)

	Header("Route")
	Check("Use your Hearthstone", "When it is faster. Set your inn (or use the Hearthstone once) so it knows where it takes you.",
		function() return DB().hearth ~= false end, function(v) DB().hearth = v; Changed("plan") end)
	Check("Go round zones far above your level", "Zones 5 or more levels above you. The other side's towns are always avoided.",
		function() return DB().avoidZones ~= false end, function(v) DB().avoidZones = v; Changed("plan") end)

	panel:SetScript("OnShow", function() for _, c in ipairs(controls) do c:Sync() end end)
	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		local cat = Settings.RegisterCanvasLayoutCategory(panel, panel.name)
		Settings.RegisterAddOnCategory(cat)
		ns.settingsCategory = cat
	elseif InterfaceOptions_AddCategory then
		InterfaceOptions_AddCategory(panel)
	end
end

function ns.SettingsInit()
	if panel then return end
	ns.Safe("settings", Build)
end

function ns.OpenSettings()
	if not panel then return end
	local cat = ns.settingsCategory
	if cat and Settings and Settings.OpenToCategory then
		Settings.OpenToCategory(cat.GetID and cat:GetID() or cat.ID or panel.name)
	elseif InterfaceOptionsFrame_OpenToCategory then
		InterfaceOptionsFrame_OpenToCategory(panel)
		InterfaceOptionsFrame_OpenToCategory(panel)
	end
end
