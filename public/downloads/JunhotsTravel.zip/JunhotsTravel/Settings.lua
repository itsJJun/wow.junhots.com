-- Settings: Esc > Options > AddOns > Junhots Travel (or /jt settings). Everything also works by /jt commands.
local _, ns = ...

local panel, outer, preview   -- panel: the page inside a scroll frame (outer) so it all fits any window size
local controls = {}   -- each has :Sync() to show the saved value

local function DB() return JunhotsTravelDB end
local function Changed(what)
	if what == "arrow" then ns.ArrowLayout(); ns.UIReset() end
	if what == "plan" then ns.Safe("plan", ns.Replan, true) end
	ns.Refresh()
	if ns.MinimapUpdate then ns.MinimapUpdate() end
	if preview then preview.Sync() end
end

local y
local function Header(text)
	y = y - 14
	local h = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	h:SetPoint("TOPLEFT", 16, y)
	h:SetText(text)
	local line = panel:CreateTexture(nil, "ARTWORK")
	line:SetColorTexture(1, 0.82, 0, 0.25)
	line:SetHeight(1)
	line:SetPoint("LEFT", h, "RIGHT", 8, 0)
	line:SetPoint("RIGHT", panel, "RIGHT", -16, 0)
	y = y - 22
end

local function Check(text, tip, get, set)
	local cb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
	cb:SetPoint("TOPLEFT", 20, y)
	cb:SetSize(26, 26)
	local label = type(cb.Text) == "table" and cb.Text or cb:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:ClearAllPoints()
	label:SetPoint("LEFT", cb, "RIGHT", 4, 1)
	label:SetFontObject("GameFontHighlight")
	label:SetText(text)
	cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false) end)
	if tip then
		cb:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:AddLine(text, 1, 1, 1)
			GameTooltip:AddLine(tip, nil, nil, nil, true)
			GameTooltip:Show()
		end)
		cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
	end
	cb.Sync = function(self) self:SetChecked(get()) end
	controls[#controls + 1] = cb
	y = y - 28
	return cb
end

-- a row of round choices
local function Choice(text, options, get, set)
	local label = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:SetPoint("TOPLEFT", 24, y - 5)
	label:SetWidth(130)
	label:SetJustifyH("LEFT")
	label:SetText(text)
	local x, buttons = 160, {}
	for _, o in ipairs(options) do
		local rb = CreateFrame("CheckButton", nil, panel, "UIRadioButtonTemplate")
		rb:SetPoint("TOPLEFT", x, y - 4)
		local t = (type(rb.text) == "table" and rb.text) or (type(rb.Text) == "table" and rb.Text) or rb:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
		t:ClearAllPoints()
		t:SetPoint("LEFT", rb, "RIGHT", 3, 0)
		t:SetFontObject("GameFontHighlightSmall")
		t:SetText(o[2])
		rb:SetScript("OnClick", function()
			set(o[1])
			for _, b in ipairs(buttons) do b:Sync() end
		end)
		rb.Sync = function(self) self:SetChecked(get() == o[1]) end
		buttons[#buttons + 1] = rb
		controls[#controls + 1] = rb
		x = x + 26 + math.max(60, (tonumber(t:GetStringWidth()) or 60) + 14)
	end
	y = y - 28
end

-- Your way's colours (28 Nov): a live preview on real map art (Tanaris tiles: a flight in to Gadgetzan, then walking
-- to Steamwheedle Port) and a row of round gems per kind, the picked one in a thin gold ring.
local MEDIA = "Interface\\AddOns\\JunhotsTravel\\media\\"
local PW, PH = 400, 112
local function Preview()
	local f = CreateFrame("Frame", nil, panel)
	f:SetSize(PW, PH)
	f:SetPoint("TOPLEFT", 160, y - 2)
	f:SetClipsChildren(true)
	local label = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:SetPoint("TOPLEFT", 24, y - 6)
	label:SetText("Preview")
	local sub = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	sub:SetPoint("TOPLEFT", label, "BOTTOMLEFT", 0, -4)
	sub:SetWidth(126); sub:SetJustifyH("LEFT")
	sub:SetText("Your way on the map and minimap")
	-- frame: a dark line, then a thin muted gold one
	local o = f:CreateTexture(nil, "BACKGROUND", nil, -2)
	o:SetPoint("TOPLEFT", -2, 2); o:SetPoint("BOTTOMRIGHT", 2, -2); o:SetColorTexture(0, 0, 0, 1)
	local g = f:CreateTexture(nil, "BACKGROUND", nil, -1)
	g:SetPoint("TOPLEFT", -1, 1); g:SetPoint("BOTTOMRIGHT", 1, -1); g:SetColorTexture(0.47, 0.39, 0.24, 1)
	-- the map: zone-map pixels CX..CX+CW (tiles are 256 wide, 4 a row: Tanaris2 and Tanaris3 hold this part)
	local CX, CY, CW = 440, 92, 328
	local sc = PW / CW
	local CH = PH / sc
	for _, t in ipairs({ { 2, 256 }, { 3, 512 } }) do
		local x0, x1 = math.max(CX, t[2]), math.min(CX + CW, t[2] + 256)
		local tex = f:CreateTexture(nil, "BACKGROUND")
		tex:SetTexture("Interface\\WorldMap\\Tanaris\\Tanaris" .. t[1])
		tex:SetTexCoord((x0 - t[2]) / 256, (x1 - t[2]) / 256, CY / 256, (CY + CH) / 256)
		tex:SetPoint("TOPLEFT", (x0 - CX) * sc, 0)
		tex:SetSize((x1 - x0) * sc, PH)
	end
	local v = f:CreateTexture(nil, "BORDER")
	v:SetAllPoints(); v:SetTexture(MEDIA .. "vignette")
	local function P(x, y0) return (x - CX) * sc, -(y0 - CY) * sc end
	local function bez(a, c, b, n)
		local out = {}
		for i = 0, n do
			local t = i / n
			out[#out + 1] = { P((1 - t) ^ 2 * a[1] + 2 * (1 - t) * t * c[1] + t * t * b[1], (1 - t) ^ 2 * a[2] + 2 * (1 - t) * t * c[2] + t * t * b[2]) }
		end
		return out
	end
	local FM, PIN = { 513, 168 }, { 668, 147 }
	local function lines(pts)
		local ls = {}
		for i = 2, #pts do
			local l = ns.NoSnap(f:CreateLine(nil, "ARTWORK"))
			l:SetThickness(24)
			l:SetStartPoint("TOPLEFT", f, pts[i - 1][1], pts[i - 1][2])
			l:SetEndPoint("TOPLEFT", f, pts[i][1], pts[i][2])
			ls[#ls + 1] = l
		end
		return ls
	end
	f.fly = lines(bez({ 440, 96 }, { 470, 150 }, FM, 24))
	local walk = bez(FM, { 590, 185 }, PIN, 160)
	f.walkLine = lines(bez(FM, { 590, 185 }, PIN, 24))
	-- beads every 11 px, clear of the two icons
	f.beads = {}
	local acc, last = 0, walk[1]
	for i = 2, #walk do
		local q = walk[i]
		acc = acc + math.sqrt((q[1] - last[1]) ^ 2 + (q[2] - last[2]) ^ 2); last = q
		local d0 = math.sqrt((q[1] - walk[1][1]) ^ 2 + (q[2] - walk[1][2]) ^ 2)
		local d1 = math.sqrt((q[1] - walk[#walk][1]) ^ 2 + (q[2] - walk[#walk][2]) ^ 2)
		if acc >= 11 and d0 > 12 and d1 > 12 then
			local t = ns.NoSnap(f:CreateTexture(nil, "ARTWORK", nil, 1))
			t:SetSize(18, 18)
			t:SetPoint("CENTER", f, "TOPLEFT", q[1], q[2])
			f.beads[#f.beads + 1] = t
			acc = 0
		end
	end
	local function icon(at, atlas, file)
		local t = f:CreateTexture(nil, "OVERLAY")
		t:SetPoint("CENTER", f, "TOPLEFT", P(at[1], at[2]))
		if not (atlas and ns.Atlas(t, atlas, 22, 22)) then t:SetTexture(file); t:SetSize(22, 22) end
	end
	icon(FM, ns.FlyAtlas and ns.FlyAtlas(), MEDIA .. "stop_fly")
	icon(PIN, "Waypoint-MapPin-Tracked", MEDIA .. "pin")
	function f.Sync()
		local lineC, dotC = ns.LookParts()
		local asLine = ns.TrailStyle() == "line"
		for _, l in ipairs(f.fly) do l:SetTexture(MEDIA .. "line_" .. lineC) end
		for _, l in ipairs(f.walkLine) do l:SetTexture(MEDIA .. "line_" .. dotC); l:SetShown(asLine) end
		for _, t in ipairs(f.beads) do t:SetTexture(MEDIA .. "dot_" .. dotC); t:SetShown(not asLine) end
	end
	preview = f
	controls[#controls + 1] = f
	y = y - PH - 16
end

local function Gems(text, colours, get, set)
	local label = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:SetPoint("TOPLEFT", 24, y - 6)
	label:SetText(text)
	local name = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	name:SetPoint("TOPLEFT", 160 + 8 + #colours * 25 - 4, y - 6)
	local list, ring = {}, panel:CreateTexture(nil, "OVERLAY")
	ring:SetTexture(MEDIA .. "gem_ring"); ring:SetSize(26, 26)
	local function sync()
		local v = get()
		ring:Hide()
		for _, b in ipairs(list) do
			if b.key == v then ring:ClearAllPoints(); ring:SetPoint("CENTER", b); ring:Show(); name:SetText(b.title) end
		end
		if preview then preview.Sync() end
	end
	for i, o in ipairs(colours) do
		local b = CreateFrame("Button", nil, panel)
		b:SetSize(22, 22)
		b:SetPoint("CENTER", panel, "TOPLEFT", 160 + 8 + (i - 1) * 25, y - 12)
		b.key, b.title = o[1], o[2]
		local t = b:CreateTexture(nil, "ARTWORK")
		t:SetTexture(MEDIA .. "gem_" .. o[1]); t:SetSize(16, 16); t:SetPoint("CENTER")
		local h = b:CreateTexture(nil, "HIGHLIGHT")
		h:SetTexture(MEDIA .. "gem_ring"); h:SetSize(26, 26); h:SetPoint("CENTER")
		h:SetVertexColor(1, 1, 1, 0.45)
		b:SetScript("OnClick", function() set(o[1]); sync() end)
		b:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_TOP")
			GameTooltip:SetText(o[2], 1, 1, 1)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", function() GameTooltip:Hide() end)
		list[#list + 1] = b
	end
	controls[#controls + 1] = { Sync = sync }
	y = y - 34
end

local function Slider(text, lo, hi, step, fmt, get, set)
	local label = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	label:SetPoint("TOPLEFT", 24, y - 6)
	label:SetText(text)
	local ok, s = pcall(CreateFrame, "Slider", nil, panel, "OptionsSliderTemplate")
	if not ok or not s then
		s = CreateFrame("Slider", nil, panel)
		s:SetOrientation("HORIZONTAL")
		s:SetSize(180, 16)
		s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
		local bg = s:CreateTexture(nil, "BACKGROUND")
		bg:SetColorTexture(0, 0, 0, 0.5)
		bg:SetPoint("LEFT", 0, 0); bg:SetPoint("RIGHT", 0, 0); bg:SetHeight(6)
	end
	s:SetWidth(180)
	s:SetPoint("TOPLEFT", 166, y - 4)
	s:SetMinMaxValues(lo, hi)
	s:SetValueStep(step)
	if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
	for _, k in ipairs({ "Low", "High", "Text" }) do
		local r = s[k] or (s:GetName() and _G[s:GetName() .. k])
		if type(r) == "table" and r.SetText then r:SetText("") end
	end
	local val = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
	val:SetPoint("LEFT", s, "RIGHT", 10, 0)
	local syncing
	s:SetScript("OnValueChanged", function(_, v)
		v = math.floor(v / step + 0.5) * step
		val:SetText(fmt(v))
		if not syncing then set(v) end
	end)
	s.Sync = function(self)
		syncing = true
		self:SetValue(get())
		val:SetText(fmt(get()))
		syncing = false
	end
	controls[#controls + 1] = s
	y = y - 32
end

local function Button(text, tip, onClick)
	local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	b:SetSize(160, 22)
	b:SetPoint("TOPLEFT", 20, y)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	if tip then
		b:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:AddLine(tip, 1, 1, 1, true)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	end
	y = y - 30
end

local function Build()
	outer = CreateFrame("Frame")
	outer.name = "Junhots Travel"
	local scroll = CreateFrame("ScrollFrame", nil, outer, "UIPanelScrollFrameTemplate")
	scroll:SetPoint("TOPLEFT", 0, -4)
	scroll:SetPoint("BOTTOMRIGHT", -28, 4)
	panel = CreateFrame("Frame", nil, scroll)
	panel:SetSize(600, 800)
	scroll:SetScrollChild(panel)
	scroll:SetScript("OnSizeChanged", function(self, w) if w and w > 0 then panel:SetWidth(w) end end)
	local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText("Junhots Travel")
	local sub = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
	sub:SetText("The fastest way to your map pin. Shift+click the world map to go somewhere.")
	y = -56

	Header("Arrow")
	Choice("Look", { { "ring", "Ring" }, { "plain", "Arrow only" } },
		function() return ns.ArrowStyle() end, function(v) DB().arrowStyle = v; Changed("arrow") end)
	Choice("In the ring", { { "distance", "Distance" }, { "time", "Time left" }, { "both", "Both" } },
		function() return ns.ArrowLabel() end, function(v) DB().label = v; Changed() end)
	Slider("Size", 50, 200, 5, function(v) return v .. "%" end,
		function() return math.floor((DB().scale or 1) * 100 + 0.5) end, function(v) DB().scale = v / 100; Changed("arrow") end)

	Button("Center the arrow", "Moves it to the middle of the screen, side to side. When you drag it, it also snaps to the middle.",
		function() if ns.CenterArrow then ns.CenterArrow() end end)

	Check("Compass bar at the top of the screen", "A thin compass that turns with you, marking the way to go. Drag it to move it.",
		function() return DB().compass == true end, function(v) DB().compass = v; Changed() end)

	Check("Game's waypoint marker at your next turn", "The game's own pin out in the world, moved to each turn of your way. It replaces any map pin you placed.",
		function() return DB().marker == true end, function(v) DB().marker = v; Changed() end)

	Header("Your way")
	Choice("On the maps", { { "dots", "Dots" }, { "line", "Line" } },
		function() return ns.TrailStyle() end, function(v) DB().trail = v; Changed() end)
	Preview()
	Gems("Flying", ns.COLOURS or {},
		function() return (ns.LookParts()) end, function(v) DB().lineColour = v; Changed() end)
	Gems("Walking", ns.COLOURS or {},
		function() return select(2, ns.LookParts()) end, function(v) DB().dotColour = v; Changed() end)
	Slider("You're there within", 5, 50, 5, function(v) return v .. " yd" end,
		function() return DB().arrive or 15 end, function(v) DB().arrive = v end)
	Check("Sound when you arrive", nil, function() return DB().sound == true end, function(v) DB().sound = v end)

	Header("Route")
	Check("Use your Hearthstone", "When it is faster. Set your inn (or use the Hearthstone once) so it knows where it takes you.",
		function() return DB().hearth ~= false end, function(v) DB().hearth = v; Changed("plan") end)
	Check("Use class teleports", "Mage city teleports (with a Rune of Teleportation), Astral Recall, Teleport: Moonglade, when faster.",
		function() return DB().teleports ~= false end, function(v) DB().teleports = v; Changed("plan") end)
	Check("Go round zones far above your level", "Zones 5 or more levels above you. The other side's towns are always avoided.",
		function() return DB().avoidZones ~= false end, function(v) DB().avoidZones = v; Changed("plan") end)

	panel:SetHeight(-y + 16)
	outer:SetScript("OnShow", function() for _, c in ipairs(controls) do c:Sync() end end)
	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		local cat = Settings.RegisterCanvasLayoutCategory(outer, outer.name)
		Settings.RegisterAddOnCategory(cat)
		ns.settingsCategory = cat
	elseif InterfaceOptions_AddCategory then
		InterfaceOptions_AddCategory(outer)
	end
end

function ns.SettingsInit()
	if panel then return end
	ns.Safe("settings", Build)
end

function ns.OpenSettings()
	if not panel then return end
	local cat = ns.settingsCategory
	if cat and Settings and Settings.OpenToCategory then
		Settings.OpenToCategory(cat.GetID and cat:GetID() or cat.ID or outer.name)
	elseif InterfaceOptionsFrame_OpenToCategory then
		InterfaceOptionsFrame_OpenToCategory(outer)
		InterfaceOptionsFrame_OpenToCategory(outer)
	end
end
