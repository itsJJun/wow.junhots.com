-- Boat, zeppelin, lift and tram times.
-- Timing from your ride: each second you move at boat speed, your spot is matched to every route's path (D.frames).
-- Each match says where in its loop that route would be now. On a real ride every match agrees on one loop start
-- for the whole ride; someone running past a path agrees only for a moment. The method and its numbers come from
-- Shortest Path Forever (Transport/Model.lua, Observer.lua) by cjber, GPL-3.0-or-later.
-- Saved for the account: JunhotsTravelDB.boats[route] = server ms of the loop's start (mod its period),
-- boatSeen[route] = server seconds when it was timed, boatBy[route] = "shared" when a guild or group member timed it.
-- Shared in game with the guild and group (newest wins), and every ride checks how far off the time held was
-- (boatLog, /jt boats).
local ADDON, ns = ...
local D = ns.D
local canaccess = canaccessvalue or function() return true end
local floor, abs, min, max, sqrt, random = math.floor, math.abs, math.min, math.max, math.sqrt, math.random

local AGREE, AGREE_LIFT = 8000, 2000    -- one ride's matches agree on the loop start this closely (ms)
local NEAR, NEAR_LIFT = 40, 10          -- a spot this far from a route's path is not on it (yd)
local MIN_SAMPLES, MIN_SPAN = 10, 30000 -- a fit needs this many agreeing matches over this long
local CLEAR_LEAD = 1.25                 -- routes sharing a lane: the winner needs this much more support
local RIDE_GAP = 30000                  -- no moving match for this long: the ride is over
local MIN_SPEED = 12                    -- boats sail at 30 yd/s, a runner makes 7
local FIT_EVERY = 10
local MAX_SAMPLES = 300
local LOG_MAX = 60
local PREFIX = "JunhotsTravel"          -- addon messages (16 characters at most)
local VER = "T1"

local T = {}
ns.Transport = T

local function DB() JunhotsTravelDB = JunhotsTravelDB or {}; return JunhotsTravelDB end

-- server time in ms: GetServerTime ticks in whole seconds, GetTime is smooth; keep the largest lead between them
local lead
function T.NowMs()
	local l = GetServerTime() - GetTime()
	if not lead or l > lead or lead - l > 2 then lead = l end
	return (GetTime() + lead) * 1000
end

local function wrap(d, period) return (d + period / 2) % period - period / 2 end

-- Every point in its loop where route ri passes within reach of (map, x, y, z) while moving.
function T.Phases(ri, map, x, y, z, out)
	local fr, r = D.frames[ri], D.routes[ri]
	local near = r[1] == "lift" and NEAR_LIFT or NEAR
	local n2 = near * near
	for i = 1, #fr - 1 do
		local a, b = fr[i], fr[i + 1]
		if a[3] == map and not a[6] then
			local dx, dy = b[4] - a[4], b[5] - a[5]
			local dz, oz = 0, 0
			if z and a[7] and b[7] then dz, oz = b[7] - a[7], z - a[7] end
			local len = dx * dx + dy * dy + dz * dz
			local t = len > 0 and min(1, max(0, ((x - a[4]) * dx + (y - a[5]) * dy + oz * dz) / len)) or 0
			if t > 0 and t < 1 then
				local px, py, pz = a[4] + t * dx - x, a[5] + t * dy - y, t * dz - oz
				if px * px + py * py + pz * pz <= n2 then
					out = out or {}
					out[#out + 1] = a[2] + t * (b[1] - a[2])
				end
			end
		end
	end
	return out
end

-- The loop start most of one ride's matches agree on, and how many agree (nil when too few, or over too short a
-- time). Same answer as SPF's FitEpoch, but sorted with a sliding window (n log n, not n squared), so a long ride
-- never stalls a frame.
local offs, ext = {}, {}
function T.Fit(ri, samples)
	local r, fit = D.routes[ri], D.frames[ri].fit
	local period = r[3]
	local agree = (r[1] == "lift" and AGREE_LIFT or AGREE) / 2
	local n = 0
	for _, s in ipairs(samples) do
		for _, ph in ipairs(s.ph) do
			n = n + 1
			local o = offs[n] or {}
			offs[n] = o
			o[1], o[2] = (s.now - ph) % period, s.now
		end
	end
	for i = n + 1, #offs do offs[i] = nil end
	if n == 0 then return nil, 0 end
	table.sort(offs, function(a, b) return a[1] < b[1] end)
	-- the loop wraps: copies one period below and above
	local m = 0
	for k = -1, 1 do
		for i = 1, n do
			m = m + 1
			local e = ext[m] or {}
			ext[m] = e
			e[1], e[2] = offs[i][1] + k * period, offs[i][2]
		end
	end
	for i = m + 1, #ext do ext[i] = nil end
	local best, support = nil, 0
	local lo, hi = 1, 1
	for c = n + 1, 2 * n do
		local oc = ext[c][1]
		while ext[lo][1] < oc - agree do lo = lo + 1 end
		while hi < m and ext[hi + 1][1] <= oc + agree do hi = hi + 1 end
		local members = hi - lo + 1
		if members > support then
			local first, last, sum = math.huge, -math.huge, 0
			for i = lo, hi do
				local e = ext[i]
				sum = sum + (e[1] - oc)
				if e[2] < first then first = e[2] end
				if e[2] > last then last = e[2] end
			end
			if last - first >= (fit and fit[2] or MIN_SPAN) then
				best, support = (oc + sum / members) % period, members
			end
		end
	end
	if support < (fit and fit[1] or MIN_SAMPLES) then return nil, support end
	return best, support
end

-- The route a ride was on: the best fit, clearly ahead of every other. Two boats share the Menethil-Auberdine lane
-- and fit it alike; then the one whose time held agrees with the ride is it (SPF leaves those untimed).
-- held(ri) = loop start held for a route, or nil.
function T.Winner(fits, held)
	local best, second
	for ri, f in pairs(fits) do
		if not best or f[2] > fits[best][2] then
			second = best and fits[best][2] or second
			best = ri
		elseif not second or f[2] > second then
			second = f[2]
		end
	end
	if not best then return nil end
	if not second or fits[best][2] >= CLEAR_LEAD * second then return best end
	if not held then return nil end
	local pick
	for ri, f in pairs(fits) do
		if f[2] * CLEAR_LEAD > fits[best][2] then
			local e = held(ri)
			if e and abs(wrap(f[1] - e, D.routes[ri][3])) <= AGREE / 2 then
				if pick then return nil end
				pick = ri
			end
		end
	end
	return pick
end

-- ---------- what is held ----------
local function Held(ri)
	local db = DB()
	local e = db.boats and db.boats[ri]
	if not e then return nil end
	return e, db.boatSeen and db.boatSeen[ri] or 0, db.boatBy and db.boatBy[ri]
end

-- Keep a time unless the one held is newer. by = nil (your ride) or "shared".
local function Store(ri, epoch, seen, by)
	local db = DB()
	local _, held = Held(ri)
	if held and held >= seen then return false end
	db.boats, db.boatSeen, db.boatBy = db.boats or {}, db.boatSeen or {}, db.boatBy or {}
	db.boats[ri] = floor(epoch % D.routes[ri][3] + 0.5)
	db.boatSeen[ri], db.boatBy[ri] = seen, by
	return true
end
T.Store = Store

-- "Boat Ratchet - Booty Bay", "Zeppelin Orgrimmar - Undercity", "Thunder Bluff, west lift", "Deeprun Tram"
local function RouteName(ri)
	local r = D.routes[ri]
	local names, seen = {}, {}
	for _, s in ipairs(r[4]) do
		local d = D.docks[s[1]]
		local n = d and d[4]:gsub(" %(%a+%)$", "") or "?"
		if not seen[n] then seen[n] = true; names[#names + 1] = n end
	end
	if r[1] == "lift" or r[1] == "tram" then return names[1] end
	return (r[1] == "boat" and "Boat " or "Zeppelin ") .. table.concat(names, " - ")
end
T.RouteName = RouteName

-- ---------- your ride ----------
local ride, prev = nil, {}
local Share

local function Record(final)
	if not ride then return end
	local fits = {}
	for ri, ss in pairs(ride.samples) do
		local e, sup = T.Fit(ri, ss)
		if e then fits[ri] = { e, sup } end
	end
	local ri = T.Winner(fits, Held)
	if not ri then return end
	local epoch, now = fits[ri][1], GetServerTime()
	local held, seen, by = Held(ri)
	-- self-check: a time held from before this ride, against what the ride shows
	if held and seen < ride.start and not ride.logged then
		ride.logged = true
		local db = DB()
		db.boatLog = db.boatLog or {}
		local log = db.boatLog
		log[#log + 1] = { ri, floor(wrap(epoch - held, D.routes[ri][3]) + 0.5), now - seen, by, now }
		while #log > LOG_MAX do table.remove(log, 1) end
	end
	Store(ri, epoch, now)
	-- one line the first time a boat or zeppelin is timed (lifts and later rides stay quiet; /jt boats lists them)
	local kind = D.routes[ri][1]
	if not held and not ride.told and (kind == "boat" or kind == "zeppelin") then
		print("|cff66ccffJunhots Travel|r: " .. RouteName(ri) .. " timed from your ride. Its steps now say when it leaves.")
	end
	ride.ri, ride.told = ri, true
	if Share and (final or not ride.shared) then ride.shared = true; Share(ri) end
end

-- Called every second (Core's ticker).
local scratch
function T.Tick()
	if not (GetServerTime and D.frames) then return end
	local now = T.NowMs()
	local x, y, z, map = UnitPosition("player")
	if not (x and y and map and canaccess(x) and canaccess(y) and canaccess(map)) then x = nil end
	if z and not canaccess(z) then z = nil end
	local speed = 0
	if x and not (UnitOnTaxi and UnitOnTaxi("player")) then
		if prev.map == map and now > prev.now then
			local dz = (z and prev.z) and (z - prev.z) or 0
			speed = sqrt((x - prev.x) ^ 2 + (y - prev.y) ^ 2 + dz * dz) * 1000 / (now - prev.now)
		end
		prev.now, prev.x, prev.y, prev.z, prev.map = now, x, y, z, map
	else
		prev.map = nil
	end
	if speed >= 6 and speed < 60 then
		local hit = false
		for ri, fr in pairs(D.frames) do
			if speed >= (fr.fit and fr.fit[3] or MIN_SPEED) then
				local ph = T.Phases(ri, map, x, y, z, scratch)
				if ph and #ph > 0 then
					scratch = nil
					ride = ride or { samples = {}, count = 0, start = floor(now / 1000) }
					local ss = ride.samples[ri] or {}
					ride.samples[ri] = ss
					ss[#ss + 1] = { now = now, ph = ph }
					if #ss > MAX_SAMPLES then table.remove(ss, 1) end
					hit = true
				end
			end
		end
		if hit then
			ride.last, ride.count = now, ride.count + 1
			if not ride.told and ride.count % FIT_EVERY == 0 and not InCombatLockdown() then Record(false) end
		end
	end
	if ride and now - ride.last > RIDE_GAP and not InCombatLockdown() then
		Record(true)
		ride = nil
	end
end

-- ---------- sharing with your guild and group ----------
-- Message: "T1 <kind> route:start:seen route:start:seen ..." (start = loop start in ms mod its period, seen = server
-- seconds when it was timed; relaying keeps the first seen, so newest wins everywhere). Kinds: h = hello, all I
-- hold (after you log in or join a group); a = an answer to a hello; c = more of the message before (255 characters
-- a message); r = a ride just timed. After a hello, whoever holds newer times than the channel has shown since
-- answers once, a few seconds later; anyone who hears that answer first sends only what is newer still.
local heard = {}      -- [channel][route] = newest seen shown there since the last hello
local pending = {}    -- [channel] = true while an answer waits
local lastHello = {}  -- [channel] = GetTime()
local function Sharing() return DB().share ~= false and C_ChatInfo and C_ChatInfo.SendAddonMessage end

local function Channels()
	local out = {}
	if IsInGuild and IsInGuild() then out[#out + 1] = "GUILD" end
	if IsInRaid and IsInRaid() then out[#out + 1] = "RAID"
	elseif IsInGroup and IsInGroup() then out[#out + 1] = "PARTY" end
	return out
end

local function Note(ch, ri, seen)
	local h = heard[ch] or {}
	heard[ch] = h
	if seen > (h[ri] or 0) then h[ri] = seen end
end

-- what to send: only = one route (a ride), all = everything held (a hello), else what is newer than the channel showed
local function Pack(ch, kind, only)
	local parts, h = {}, heard[ch] or {}
	for ri in pairs(D.routes) do
		local e, seen = Held(ri)
		if e and seen > 0 and (only == ri or (not only and (kind == "h" or seen > (h[ri] or 0)))) then
			parts[#parts + 1] = ri .. ":" .. floor(e) .. ":" .. seen
		end
	end
	table.sort(parts)
	local msgs, cur = {}, VER .. " " .. kind
	for _, p in ipairs(parts) do
		if #cur + 1 + #p > 250 then msgs[#msgs + 1] = cur; cur = VER .. " c" end
		cur = cur .. " " .. p
	end
	msgs[#msgs + 1] = cur
	return msgs, #parts
end

local function Send(ch, msgs)
	for k, m in ipairs(msgs) do
		-- the game lets an addon send about one message a second (10 at once)
		C_Timer.After((k - 1) * 1.2, function()
			if Sharing() then pcall(C_ChatInfo.SendAddonMessage, PREFIX, m, ch) end
		end)
		for a, _, c in m:gmatch("(%d+):(%d+):(%d+)") do Note(ch, tonumber(a), tonumber(c)) end
	end
end

Share = function(ri)
	if not Sharing() then return end
	for _, ch in ipairs(Channels()) do Send(ch, (Pack(ch, "r", ri))) end
end

local function Hello(ch)
	if not Sharing() then return end
	if lastHello[ch] and GetTime() - lastHello[ch] < 60 then return end
	lastHello[ch] = GetTime()
	heard[ch] = {}
	Send(ch, (Pack(ch, "h")))
end
T.Hello = Hello

-- A message from someone else: keep each newer time; after a hello, answer with what we hold newer.
function T.Heard(text, ch, sender)
	if type(text) ~= "string" or #text > 255 then return end
	local kind = text:match("^" .. VER .. " ([hacr])")
	if not kind then return end
	if ch ~= "GUILD" and ch ~= "PARTY" and ch ~= "RAID" then return end
	local me = UnitName("player")
	if sender and me and (sender == me or sender:match("^([^%-]+)") == me) then return end
	if kind == "h" then heard[ch] = {} end
	local now, got = GetServerTime(), 0
	for a, b, c in text:gmatch("(%d+):(%d+):(%d+)") do
		local ri, e, seen = tonumber(a), tonumber(b), tonumber(c)
		local r = D.routes[ri]
		-- only real routes, a start inside the loop, timed in the last 30 days and not in the future
		if r and D.frames[ri] and e < r[3] and seen <= now + 120 and seen > now - 30 * 86400 then
			Note(ch, ri, seen)
			if Store(ri, e, seen, "shared") then got = got + 1 end
		end
	end
	if kind == "h" and not pending[ch] and Sharing() then
		pending[ch] = true
		C_Timer.After(2 + random() * 6, function()
			pending[ch] = nil
			local msgs, n = Pack(ch, "a")
			if n > 0 then Send(ch, msgs) end
		end)
	end
	return got
end

-- ---------- /jt boats ----------
local function Ago(s)
	if s < 90 then return "just now" end
	if s < 5400 then return floor(s / 60 + 0.5) .. " min ago" end
	if s < 129600 then return floor(s / 3600 + 0.5) .. " h ago" end
	return floor(s / 86400 + 0.5) .. " days ago"
end
T.Ago = Ago

function T.Report()
	local now, db = GetServerTime(), DB()
	print("|cff66ccffJunhots Travel|r: boat, zeppelin and lift times")
	local n = 0
	for ri in ipairs(D.routes) do
		local e, seen, by = Held(ri)
		if e then
			n = n + 1
			print("  " .. RouteName(ri) .. ": " .. (seen > 0 and ("timed " .. Ago(now - seen)) or "timed by an older version")
				.. (by == "shared" and " by a guild or group member" or (seen > 0 and " on your ride" or "")))
		end
	end
	if n == 0 then print("  None yet. Ride one once and it is timed from then on.") end
	local log = db.boatLog or {}
	if #log > 0 then
		local errs = {}
		for _, l in ipairs(log) do errs[#errs + 1] = abs(l[2]) end
		table.sort(errs)
		local mid = errs[floor((#errs + 1) / 2)]
		print(("  Check on your rides: %d %s, off by %.1f s (middle), %.1f s at most."):format(#log, #log == 1 and "ride" or "rides", mid / 1000, errs[#errs] / 1000))
		for k = max(1, #log - 4), #log do
			local l = log[k]
			print(("    %s: off by %.1f s, time was %s%s"):format(RouteName(l[1]), l[2] / 1000, Ago(l[3]), l[4] == "shared" and " (shared)" or ""))
		end
	end
	print("  Sharing with guild and group: " .. (db.share ~= false and "on" or "off") .. " (/jt share to switch).")
end

-- ---------- events ----------
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self, ev, ...)
	if ev == "PLAYER_LOGIN" then
		if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
			C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
			self:RegisterEvent("CHAT_MSG_ADDON")
		end
		self:RegisterEvent("PLAYER_LEAVING_WORLD")
		self:RegisterEvent("GROUP_JOINED")
		C_Timer.After(30, function() for _, ch in ipairs(Channels()) do Hello(ch) end end)
	elseif ev == "CHAT_MSG_ADDON" then
		local prefix, text, ch, sender = ...
		if prefix == PREFIX and canaccess(text) and canaccess(sender) then
			if ns.Safe then ns.Safe("share", T.Heard, text, ch, sender) else pcall(T.Heard, text, ch, sender) end
		end
	elseif ev == "PLAYER_LEAVING_WORLD" then
		-- a /reload or logout on board would lose the ride so far; a loading screen mid-crossing keeps it
		if ride then pcall(Record, false) end
	elseif ev == "GROUP_JOINED" then
		C_Timer.After(5, function()
			if IsInRaid and IsInRaid() then Hello("RAID") elseif IsInGroup and IsInGroup() then Hello("PARTY") end
		end)
	end
end)
