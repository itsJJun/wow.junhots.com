-- Junhots Travel: the fastest way to your map pin, with the flights you know.
local ADDON, ns = ...
local P = ns.Planner
local D = ns.D

local canaccess = canaccessvalue or function() return true end
local floor, sqrt = math.floor, math.sqrt
local ARRIVE = 15 -- yards
local KEEP = 15 -- seconds a new plan must save before the next stop changes

ns.state = { goal = nil, plan = nil, flying = nil }
local S = ns.state

-- Errors: said once in chat (so you can tell us), kept in /jt status, and never stop the rest from working.
local said = {}
function ns.Error(where, err)
	err = tostring(err)
	ns.errors = ns.errors or {}
	table.insert(ns.errors, 1, where .. ": " .. err)
	if #ns.errors > 5 then table.remove(ns.errors) end
	if not said[where] then
		said[where] = true
		print("|cffff6666Junhots Travel hit a problem|r (" .. where .. "): " .. err .. "  |cff999999Please send us a screenshot.|r")
	end
end
-- smooth (not snapped to whole pixels) for anything that turns or runs at an angle
function ns.NoSnap(t)
	if t.SetSnapToPixelGrid then t:SetSnapToPixelGrid(false) end
	if t.SetTexelSnappingBias then t:SetTexelSnappingBias(0) end
	return t
end

-- the game's own art (an atlas) on a texture, as large as fits w x h at its own shape; false if this client lacks it
function ns.Atlas(t, name, w, h)
	local info = C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(name)
	if not (info and info.width and info.width > 0 and info.height and info.height > 0) then return false end
	t:SetAtlas(name)
	local s = math.min(w / info.width, h / info.height)
	t:SetSize(info.width * s, info.height * s)
	return true
end
function ns.Safe(where, fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then ns.Error(where, err) end
	return ok
end

-- Where you are: { map = continent id, x = north, y = west }, from UnitPosition or else the map.
function ns.Here()
	local x, y, _, map = UnitPosition("player")
	if x and y and map and canaccess(x) and canaccess(y) and canaccess(map) then return { map = map, x = x, y = y } end
	local ui = C_Map.GetBestMapForUnit("player")
	if not (ui and canaccess(ui)) then return nil end
	local pos = C_Map.GetPlayerMapPosition(ui, "player")
	if not (pos and canaccess(pos)) then return nil end
	local cont, world = C_Map.GetWorldPosFromMapPos(ui, pos)
	if not (cont and world and canaccess(cont) and canaccess(world)) then return nil end
	local wx, wy = world:GetXY()
	if not (wx and wy) then return nil end
	return { map = cont, x = wx, y = wy }
end

-- Map point (uiMap, 0-1 x, 0-1 y) -> world spot
function ns.WorldFromMap(ui, mx, my)
	local cont, world = C_Map.GetWorldPosFromMapPos(ui, CreateVector2D(mx, my))
	if not (cont and world) then return nil end
	local wx, wy = world:GetXY()
	return { map = cont, x = wx, y = wy }
end

-- ---------- flight points you know ----------
local function Known()
	JunhotsTravelCharDB.known = JunhotsTravelCharDB.known or {}
	return JunhotsTravelCharDB.known
end
function ns.KnownCount()
	local n = 0
	for _ in pairs(Known()) do n = n + 1 end
	return n
end
-- Gear Snapshot (our site's addon) saves the same list: take any it has.
local function FromGearSnapshot()
	local fl = GearSnapshotDB and GearSnapshotDB.flights
	if type(fl) ~= "table" then return end
	local k = Known()
	for id in pairs(fl) do if type(id) == "number" and D.taxi[id] then k[id] = true end end
end
-- A flight master's map lists the points you have as where you are or somewhere you can fly.
local function ReadTaxiMap()
	if not (C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and GetTaxiMapID) then return end
	local map = GetTaxiMapID()
	if not map then return end
	local k, n = Known(), 0
	for _, node in ipairs(C_TaxiMap.GetAllTaxiNodes(map) or {}) do
		local kind = node.slotIndex and TaxiNodeGetType(node.slotIndex)
		if node.nodeID and (kind == "CURRENT" or kind == "REACHABLE") then k[node.nodeID] = true; n = n + 1 end
	end
	if n > 0 then ns.Replan(true) end
end

-- ---------- how fast you go ----------
local function Speed()
	local _, run = GetUnitSpeed("player")
	run = (run and canaccess(run)) and run or P.RUN
	if IsMounted() and run > P.RUN then
		JunhotsTravelCharDB.mount = math.max(JunhotsTravelCharDB.mount or 0, run)
	end
	return math.max(P.RUN, run, JunhotsTravelCharDB.mount or 0)
end

local function Opts()
	local fac = UnitFactionGroup("player")
	return { known = Known(), fac = fac == "Alliance" and "A" or "H", cls = select(2, UnitClass("player")), speed = Speed() }
end

-- ---------- the goal ----------
function ns.SetGoal(g, source)
	-- the same spot again (the game's pin we just followed): keep going, no need to start over
	if g and S.goal and g.map == S.goal.map and P.dist(g, S.goal) < 1 then
		S.goal.name, S.goal.source = g.name or S.goal.name, source
		return
	end
	S.goal = g and { map = g.map, x = g.x, y = g.y, name = g.name, source = source } or nil
	S.plan, S.arrived = nil, nil
	ns.Replan(true)
end

local function GoalFromPin()
	if not (C_Map.HasUserWaypoint and C_Map.HasUserWaypoint()) then return nil end
	local wp = C_Map.GetUserWaypoint()
	if not wp then return nil end
	local mx, my = wp.position:GetXY()
	local g = ns.WorldFromMap(wp.uiMapID, mx, my)
	if not g then return nil end
	local info = C_Map.GetMapInfo(wp.uiMapID)
	g.name = "your map pin" .. (info and info.name and (" in " .. info.name) or "")
	return g
end
local function PinChanged()
	local g = GoalFromPin()
	if g then ns.SetGoal(g, "pin")
	elseif S.goal and S.goal.source == "pin" then ns.SetGoal(nil) end
end

-- You're there: say so for a moment, then everything goes away (the game's map pin too).
local SHOW_THERE = 3 -- seconds
local function Arrive()
	if S.arrived then return end
	S.arrived, S.plan = true, nil
	local g = S.goal
	ns.Refresh()
	C_Timer.After(SHOW_THERE, function()
		if S.goal ~= g then return end
		if g.source == "pin" and C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
		ns.SetGoal(nil)
	end)
end

-- ---------- planning ----------
-- A walk goes through fixed places (path). l.at = the place you head for now; places within 20 yd count as passed,
-- and a passed place stays passed, so walking away from it never sends you back.
local function Advance(plan, here)
	local l = plan and plan.legs[1]
	if not (l and l.k == "walk" and here) then return end
	l.at = l.at or 2
	while l.at < #l.path do
		local q, nx = l.path[l.at], l.path[l.at + 1]
		-- reached it, or already closer to the one after it than it is (you cut the corner)
		if q.map == here.map and (P.dist(here, q) < 20 or (nx.map == here.map and P.dist(here, nx) < P.dist(q, nx))) then
			l.at = l.at + 1
		else
			break
		end
	end
end

-- The next place you head for: the place on your walk, or where a ride starts.
local function Waypoint(plan)
	local l = plan and plan.legs[1]
	if not l then return nil end
	if l.k ~= "walk" then return l.from end
	return l.path[l.at or 2]
end
ns.Waypoint = Waypoint

-- Seconds left on the plan you are on, from here.
local function KeepCost(old, here, speed)
	local l = old.legs[1]
	if not l or l.k ~= "walk" then return nil end
	local i = l.at or 2
	local w, before = l.path[i], l.path[i - 1]
	-- at the end of the walk already: the new plan starts from here
	if w.map ~= here.map or P.dist(here, w) < 20 then return nil end
	local toW
	if before.key ~= "S" and before.map == here.map and P.dist(before, w) > 1 then
		-- the part of this stretch still ahead, at the stretch's own walking time
		toW = (l.cum[i] - l.cum[i - 1]) * math.min(1.5, P.dist(here, w) / P.dist(before, w))
	else
		toW = P.dist(here, w) * 1.4 / speed
	end
	return toW + old.secs0 - l.cum[i], toW + l.secs0 - l.cum[i]
end

function ns.Replan(force)
	local g = S.goal
	if not g then S.plan = nil; ns.Refresh(); return end
	if UnitOnTaxi("player") then ns.Refresh(); return end
	local here = ns.Here()
	if not here then ns.Refresh(); return end
	if here.map == g.map and P.dist(here, g) <= ARRIVE then return Arrive() end
	S.arrived = nil
	local o = Opts()
	local old = S.plan
	Advance(old, here)
	local new = P.Route(here, g, o)
	if new then
		new.secs0 = new.secs
		if new.legs[1] then new.legs[1].secs0 = new.legs[1].secs end
	end
	Advance(new, here)
	if new and old and not force then
		local keep, firstLeft = KeepCost(old, here, o.speed)
		-- stay on your plan unless the new one saves real time
		if keep and new.secs + KEEP >= keep then
			old.secs, old.legs[1].secs, old.legs[1].here = keep, firstLeft, here
			new = old
		end
	end
	S.plan = new
	ns.Refresh()
end

-- between replans: tick off the spots you passed, and say when you are there
function ns.Follow()
	local here = ns.Here()
	local g = S.goal
	if not (here and g) then return end
	if here.map == g.map and P.dist(here, g) <= ARRIVE then return Arrive() end
	local l = S.plan and S.plan.legs[1]
	-- a ride is over (or you went another way): plan again now
	if not l or (l.k ~= "walk" and (here.map ~= l.from.map or P.dist(here, l.from) > 100)) then return ns.Replan(true) end
	Advance(S.plan, here)
	ns.Refresh()
end

-- the spot the arrow points at
-- (goes round a ridge first when the straight line to the waypoint crosses one)
function ns.NextSpot()
	local w = Waypoint(S.plan)
	local here = ns.Here()
	if w and here and w.map == here.map and S.plan.legs[1].k == "walk" then return P.Round(here, w) or w end
	return w
end

-- ---------- events ----------
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self, ev, arg)
	if ev == "ADDON_LOADED" and arg == ADDON then
		JunhotsTravelDB = JunhotsTravelDB or {}
		JunhotsTravelCharDB = JunhotsTravelCharDB or {}
	elseif ev == "PLAYER_LOGIN" then
		FromGearSnapshot()
		self:RegisterEvent("TAXIMAP_OPENED")
		self:RegisterEvent("USER_WAYPOINT_UPDATED")
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
		self:RegisterEvent("PLAYER_CONTROL_GAINED")
		ns.Safe("start", ns.UIInit)
		if ns.MapClickInit then ns.Safe("map click", ns.MapClickInit) end
		if ns.MinimapInit then ns.Safe("minimap", ns.MinimapInit) end
		ns.Safe("pin", PinChanged)
		-- every second: follow your plan; every 4 seconds: look for a faster one
		local n = 0
		C_Timer.NewTicker(1, function()
			if not ns.clickInit then ns.Safe("map click", ns.MapClickInit) end   -- the map can load after login
			if not S.goal then ns.Safe("map", ns.Draw); return end
			n = n + 1
			if n % 4 == 0 or not S.plan then ns.Safe("plan", ns.Replan, false) else ns.Safe("follow", ns.Follow) end
		end)
	elseif ev == "TAXIMAP_OPENED" then
		C_Timer.After(0.3, function() pcall(ReadTaxiMap) end)
	elseif ev == "USER_WAYPOINT_UPDATED" then
		ns.Safe("pin", PinChanged)
	elseif ev == "PLAYER_ENTERING_WORLD" or ev == "PLAYER_CONTROL_GAINED" then
		C_Timer.After(1, function() S.flying = UnitOnTaxi("player") and S.flying or nil; ns.Safe("plan", ns.Replan, true) end)
	end
end)

-- the flight you just took, for "Flying to X"
if TakeTaxiNode then
	hooksecurefunc("TakeTaxiNode", function(slot)
		S.flying = TaxiNodeName and TaxiNodeName(slot) or "your flight point"
		ns.Refresh()
	end)
end

-- ---------- slash ----------
SLASH_JUNHOTSTRAVEL1, SLASH_JUNHOTSTRAVEL2 = "/jt", "/travel"
SlashCmdList.JUNHOTSTRAVEL = function(msg)
	msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
	local x, y = msg:match("^([%d%.]+)[%s,]+([%d%.]+)$")
	if x then
		local ui = C_Map.GetBestMapForUnit("player")
		local g = ui and ns.WorldFromMap(ui, tonumber(x) / 100, tonumber(y) / 100)
		if g then
			local info = C_Map.GetMapInfo(ui)
			g.name = x .. ", " .. y .. (info and (" in " .. info.name) or "")
			ns.SetGoal(g, "slash")
		end
	elseif msg == "clear" or msg == "stop" then
		if C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
		ns.SetGoal(nil)
	elseif msg == "status" then
		local p = S.plan
		print("|cff66ccffJunhots Travel|r " .. (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON, "Version") or ""))
		print("  Going to: " .. (S.goal and (S.goal.name or "a spot") or "nowhere (Shift+click the world map)"))
		print("  Route: " .. (p and (#p.legs .. " steps, " .. P.Time(p.secs)) or (S.arrived and "you're there" or "none")))
		print("  Flight points known: " .. ns.KnownCount() .. "   Stitched map (OpenMap): " .. (ns.OpenMap and ns.OpenMap() and "yes" or "no"))
		print("  Map click ready: " .. (ns.clickInit and "yes" or "no"))
		print("  Arrow art: " .. tostring(ns.arrowArt))
		for _, e in ipairs(ns.errors or {}) do print("  |cffff6666" .. e .. "|r") end
	elseif msg == "reset" then
		JunhotsTravelDB.arrow = nil
		ns.UIReset()
	else
		ns.TogglePanel()
		if msg ~= "" then
			print("|cff66ccffJunhots Travel|r: Shift+click the world map, or type /jt 45.2 61.8 for a spot in this zone. /jt clear stops. /jt status shows what it is doing.")
		end
	end
end

-- For our other addons (the leveling guide later): JunhotsTravel.SetGoal(continent, x, y, "name")
JunhotsTravel = {
	SetGoal = function(map, x, y, name) ns.SetGoal({ map = map, x = x, y = y, name = name }, "api") end,
	Clear = function() ns.SetGoal(nil) end,
	Plan = function() return S.plan end,
}
