-- Junhots Travel: the fastest way to your map pin, with the flights you know.
local ADDON, ns = ...
local P = ns.Planner
local D = ns.D

local canaccess = canaccessvalue or function() return true end
local floor, sqrt = math.floor, math.sqrt
-- how close counts as there (Settings: 5 to 50 yards)
local function ArriveDist() return (JunhotsTravelDB and JunhotsTravelDB.arrive) or 15 end
-- a new plan must save a tenth of the time left, or 30 seconds, whichever is less, before the next stop changes
local function KeepMargin(left) return math.min(30, math.max(5, left * 0.1)) end

ns.state = { goal = nil, plan = nil, flying = nil }
local S = ns.state

-- Errors: said once in chat (so you can tell us), kept in /jt status, and never stop the rest from working.
local said = {}
function ns.Error(where, err)
	err = tostring(err)
	ns.errors = ns.errors or {}
	table.insert(ns.errors, 1, where .. ": " .. err)
	if #ns.errors > 5 then table.remove(ns.errors) end
	if not said[where] then
		said[where] = true
		print("|cffff6666Junhots Travel hit a problem|r (" .. where .. "): " .. err .. "  |cff999999Please send us a screenshot.|r")
	end
end
-- smooth (not snapped to whole pixels) for anything that turns or runs at an angle
function ns.NoSnap(t)
	if t.SetSnapToPixelGrid then t:SetSnapToPixelGrid(false) end
	if t.SetTexelSnappingBias then t:SetTexelSnappingBias(0) end
	return t
end

-- the game's own art (an atlas) on a texture, as large as fits w x h at its own shape; false if this client lacks it
function ns.Atlas(t, name, w, h)
	local info = C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(name)
	if not (info and info.width and info.width > 0 and info.height and info.height > 0) then return false end
	t:SetAtlas(name)
	local s = math.min(w / info.width, h / info.height)
	t:SetSize(info.width * s, info.height * s)
	return true
end
function ns.Safe(where, fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then ns.Error(where, err) end
	return ok
end

-- Where you are: { map = continent id, x = north, y = west }, from UnitPosition or else the map.
function ns.Here()
	local x, y, _, map = UnitPosition("player")
	if x and y and map and canaccess(x) and canaccess(y) and canaccess(map) then return { map = map, x = x, y = y } end
	local ui = C_Map.GetBestMapForUnit("player")
	if not (ui and canaccess(ui)) then return nil end
	local pos = C_Map.GetPlayerMapPosition(ui, "player")
	if not (pos and canaccess(pos)) then return nil end
	local cont, world = C_Map.GetWorldPosFromMapPos(ui, pos)
	if not (cont and world and canaccess(cont) and canaccess(world)) then return nil end
	local wx, wy = world:GetXY()
	if not (wx and wy) then return nil end
	return { map = cont, x = wx, y = wy }
end

-- the city maps that are under the ground (a spot on them is down there, not on the land above)
local UNDERGROUND = { [1458] = true, [1455] = true }   -- Undercity, Ironforge
-- Map point (uiMap, 0-1 x, 0-1 y) -> world spot
function ns.WorldFromMap(ui, mx, my)
	local cont, world = C_Map.GetWorldPosFromMapPos(ui, CreateVector2D(mx, my))
	if not (cont and world) then return nil end
	local wx, wy = world:GetXY()
	return { map = cont, x = wx, y = wy, under = UNDERGROUND[ui] }
end

-- ---------- flight points you know ----------
local function Known()
	JunhotsTravelCharDB.known = JunhotsTravelCharDB.known or {}
	return JunhotsTravelCharDB.known
end
function ns.KnownCount()
	local n = 0
	for _ in pairs(Known()) do n = n + 1 end
	return n
end
-- Gear Snapshot (our site's addon) saves the same list: take any it has.
local function FromGearSnapshot()
	local fl = GearSnapshotDB and GearSnapshotDB.flights
	if type(fl) ~= "table" then return end
	local k = Known()
	for id in pairs(fl) do if type(id) == "number" and D.taxi[id] then k[id] = true end end
end
-- A flight master's map lists the points you have as where you are or somewhere you can fly.
local function ReadTaxiMap()
	if not (C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and GetTaxiMapID) then return end
	local map = GetTaxiMapID()
	if not map then return end
	local k, n = Known(), 0
	for _, node in ipairs(C_TaxiMap.GetAllTaxiNodes(map) or {}) do
		local kind = node.slotIndex and TaxiNodeGetType(node.slotIndex)
		if node.nodeID and (kind == "CURRENT" or kind == "REACHABLE") then k[node.nodeID] = true; n = n + 1 end
	end
	if n > 0 then ns.Replan(true) end
end

-- ---------- how fast you go ----------
local function Speed()
	local _, run = GetUnitSpeed("player")
	run = (run and canaccess(run)) and run or P.RUN
	if IsMounted() and run > P.RUN then
		JunhotsTravelCharDB.mount = math.max(JunhotsTravelCharDB.mount or 0, run)
	end
	return math.max(P.RUN, run, JunhotsTravelCharDB.mount or 0)
end

-- ---------- your Hearthstone ----------
-- The game only names your inn, so we keep where you stood when you set it (the innkeeper) or where a Hearthstone
-- last put you down, with that name. Set somewhere else since (before this addon): no Hearthstone until you set it
-- or use it once.
local HEARTHSTONE, HEARTH_SPELL = 6948, 8690
local function Bind()
	local b, name = JunhotsTravelCharDB.bind, GetBindLocation and GetBindLocation()
	if b and name and canaccess(name) and b.name == name then return b end
end
local function Hearth()
	local b = Bind()
	if not b then return nil end
	local count = (C_Item and C_Item.GetItemCount and C_Item.GetItemCount(HEARTHSTONE)) or (GetItemCount and GetItemCount(HEARTHSTONE)) or 0
	if count < 1 then return nil end
	local cd = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
	local start, dur = 0, 0
	if cd then start, dur = cd(HEARTHSTONE) end
	local wait = 0
	if start and dur and start > 0 and dur > 1.5 then wait = math.max(0, start + dur - GetTime()) end
	return { map = b.map, x = b.x, y = b.y, name = b.name, wait = wait }
end
ns.Hearth = Hearth

-- Class teleports. Where they land: classic-db spell_target_position (cmangos, via Shortest Path Forever's
-- Data/Teleports.lua, GPL-3.0); spell ids from the game's SpellEffect (TELEPORT_UNITS). Mage ones use a Rune of Teleportation.
local RUNE = 17031
local PORTS = {
	{ spell = 556, bind = true },                                                   -- Astral Recall (shaman): your inn
	{ spell = 3561, map = 0, x = -9003.46, y = 870.031, rune = true },              -- Teleport: Stormwind
	{ spell = 3562, map = 0, x = -4613.62, y = -915.38, rune = true },              -- Teleport: Ironforge
	{ spell = 3563, map = 0, x = 1773.47, y = 61.121, rune = true },                -- Teleport: Undercity
	{ spell = 3565, map = 1, x = 9664.14, y = 2526.36, rune = true },               -- Teleport: Darnassus
	{ spell = 3566, map = 1, x = -964.98, y = 283.433, rune = true },               -- Teleport: Thunder Bluff
	{ spell = 3567, map = 1, x = 1469.85, y = -4221.52, rune = true },              -- Teleport: Orgrimmar
	{ spell = 18960, map = 1, x = 7991.88, y = -2679.84 },                          -- Teleport: Moonglade (druid)
}
local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return GetSpellInfo and (GetSpellInfo(id)) or nil
end
local function SpellWait(id)
	local start, dur
	if C_Spell and C_Spell.GetSpellCooldown then
		local c = C_Spell.GetSpellCooldown(id)
		if c then start, dur = c.startTime, c.duration end
	elseif GetSpellCooldown then
		start, dur = GetSpellCooldown(id)
	end
	if start and dur and canaccess(start) and canaccess(dur) and start > 0 and dur > 1.5 then return math.max(0, start + dur - GetTime()) end
	return 0
end
local function Ports()
	if JunhotsTravelDB.teleports == false then return nil end
	local out = {}
	local known = IsPlayerSpell or IsSpellKnown
	if not known then return nil end
	local runes
	for _, p in ipairs(PORTS) do
		if known(p.spell) then
			local ok = true
			if p.rune then
				if runes == nil then
					runes = (C_Item and C_Item.GetItemCount and C_Item.GetItemCount(RUNE)) or (GetItemCount and GetItemCount(RUNE)) or 0
				end
				ok = runes > 0
			end
			local to = p
			if p.bind then
				local b = Bind()
				to = b and { map = b.map, x = b.x, y = b.y, name = b.name }
			end
			if ok and to then
				local name = SpellName(p.spell) or "your teleport"
				out[#out + 1] = { map = to.map, x = to.x, y = to.y, name = to.name or name:gsub("^[^:]*:%s*", ""),
					spell = name, wait = SpellWait(p.spell), cd = p.bind }
			end
		end
	end
	return #out > 0 and out or nil
end

-- Live boat times: when you stand still at a dock and start moving anyway, your boat has left. That moment fixes
-- where its route's loop is (saved for the account: JunhotsTravelDB.boats[route] = server ms of the loop's start).
-- A dock on two routes is settled by where the ride ends.
local ride, lastPos
local function WatchBoats(here)
	if not (here and GetServerTime) then lastPos = nil; return end
	local prev = lastPos
	lastPos = { map = here.map, x = here.x, y = here.y }
	local now = GetServerTime()
	if ride and now - ride.t > 900 then ride = nil end
	local function dockNear(r)
		for id, d in pairs(D.docks) do
			if d[1] == here.map and P.dist(here, { x = d[2], y = d[3] }) < r then return id end
		end
	end
	local function setPhase(ri, dock, t)
		local r = D.routes[ri]
		for _, s in ipairs(r[4]) do
			if s[1] == dock then
				JunhotsTravelDB.boats = JunhotsTravelDB.boats or {}
				JunhotsTravelDB.boats[ri] = (t * 1000 - s[3]) % r[3]
			end
		end
	end
	if ride then
		-- the ride ended at another dock of one of the routes it could be: that's the one
		local b = dockNear(150)
		if b and b ~= ride.dock then
			for _, ri in ipairs(ride.routes) do
				for _, s in ipairs(D.routes[ri][4]) do if s[1] == b then setPhase(ri, ride.dock, ride.t) end end
			end
			ride = nil
		end
		return
	end
	if not prev or prev.map ~= here.map then return end
	local moved = P.dist(prev, here)
	local walking = IsPlayerMoving and IsPlayerMoving()
	if walking or moved < 2 or moved > 40 then return end
	local a = dockNear(80)
	if not a then return end
	local routes = {}
	for ri, r in ipairs(D.routes) do
		if r[1] == "boat" or r[1] == "zeppelin" then
			for _, s in ipairs(r[4]) do if s[1] == a then routes[#routes + 1] = ri end end
		end
	end
	if #routes == 0 then return end
	ride = { dock = a, t = now - 1, routes = routes }
	if #routes == 1 then setPhase(routes[1], a, ride.t) end
end

local landing -- after a Hearthstone: the first big jump in your position is where it put you
local function WatchLanding(here)
	if not landing then return end
	if GetTime() > landing.limit then landing = nil; return end
	if not here then return end
	if landing.map and (here.map ~= landing.map or P.dist(here, landing) > 200) then
		local name = GetBindLocation and GetBindLocation()
		if name and canaccess(name) then JunhotsTravelCharDB.bind = { name = name, map = here.map, x = here.x, y = here.y } end
		landing = nil
		return
	end
	landing.map, landing.x, landing.y = here.map, here.x, here.y
end

local function Opts()
	local fac = UnitFactionGroup("player")
	return { known = Known(), fac = fac == "Alliance" and "A" or "H", cls = select(2, UnitClass("player")), speed = Speed(), flyRate = JunhotsTravelCharDB.flyRate,
		level = JunhotsTravelDB.avoidZones ~= false and UnitLevel and UnitLevel("player") or nil,
		hearth = JunhotsTravelDB.hearth ~= false and Hearth() or nil, ports = Ports(),
		phases = JunhotsTravelDB.boats, now = GetServerTime and GetServerTime() or nil }
end

-- ---------- the goal ----------
-- Dungeon and raid doors: a goal inside one goes to its door, and inside one you start from its door.
-- [instance map] = { continent, x, y, name }: the game's own Map table (CorpseMapID, Corpse_0/1: where a ghost walks
-- back in), Forever build 1.60.1.71139.
local ENTRANCES = {
	[33] = { 0, -231.0, 1571.6, "Shadowfang Keep" },
	[34] = { 0, -8762.4, 848.0, "Stormwind Stockade" },
	[36] = { 0, -11207.8, 1681.2, "Deadmines" },
	[43] = { 1, -751.1, -2209.2, "Wailing Caverns" },
	[47] = { 1, -4459.4, -1660.2, "Razorfen Kraul" },
	[48] = { 1, 4249.1, 748.4, "Blackfathom Deeps" },
	[70] = { 0, -6060.2, -2955.0, "Uldaman" },
	[90] = { 0, -5162.7, 931.6, "Gnomeregan" },
	[109] = { 0, -10170.1, -3996.0, "Sunken Temple" },
	[129] = { 1, -4662.9, -2535.9, "Razorfen Downs" },
	[189] = { 0, 2892.2, -811.3, "Scarlet Monastery" },
	[209] = { 1, -6790.6, -2891.3, "Zul'Farrak" },
	[229] = { 0, -7522.5, -1233.0, "Blackrock Spire" },
	[230] = { 0, -7178.1, -928.6, "Blackrock Depths" },
	[249] = { 1, -4753.3, -3752.4, "Onyxia's Lair" },
	[289] = { 0, 1274.8, -2552.6, "Scholomance" },
	[309] = { 0, -11916.1, -1224.6, "Zul'Gurub" },
	[329] = { 0, 3392.3, -3378.5, "Stratholme" },
	[349] = { 1, -1432.7, 2925.0, "Maraudon" },
	[389] = { 1, 1816.8, -4423.4, "Ragefire Chasm" },
	[409] = { 0, -7510.6, -1036.7, "Molten Core" },
	[429] = { 1, -3908.0, 1130.0, "Dire Maul" },
	[469] = { 0, -7663.4, -1218.7, "Blackwing Lair" },
	[509] = { 1, -8114.5, 1526.4, "Ruins of Ahn'Qiraj" },
	[531] = { 1, -8111.7, 1526.8, "Ahn'Qiraj Temple" },
}
ns.ENTRANCES = ENTRANCES

-- ---------- quests: what to do at the spot (from a map icon you Shift+clicked) ----------
-- q = { id = quest id, kind = "turnin" | "pickup" | "objective", title, obj = objective number, otype, text, have, need }
-- Live from the game's quest log when the quest is in it.
local function LogIndex(id)
	if not (GetNumQuestLogEntries and GetQuestLogTitle) then return nil end
	for i = 1, (GetNumQuestLogEntries() or 0) do
		local title, _, _, header, _, complete, _, qid = GetQuestLogTitle(i)
		if not header and qid == id then return i, title, complete end
	end
end
function ns.QuestInLog(id) return LogIndex(id) end
local GOLD = "|cffffd100%s|r"
local lineFor, lineText   -- the arrow asks 20 times a second: work it out again only when the quest log changes
local function QuestLine(q)
	local title = q.title or "the quest"
	if q.kind == "turnin" then return "Turn in " .. GOLD:format(title) end
	if q.kind == "pickup" then return "Pick up " .. GOLD:format(title) end
	-- an objective: the quest log's own line, in plain words ("Kill Raptor 3/8"); done = green
	local text, done = q.text, false
	local i = q.id and LogIndex(q.id)
	if i and q.obj and GetQuestLogLeaderBoard then
		local t, _, fin = GetQuestLogLeaderBoard(q.obj, i)
		if t then text, done = t, fin and true or false end
	end
	if not text then return GOLD:format(title) end
	local what, a, b = text:match("^(.-) slain: (%d+)/(%d+)$")
	if what then text = ("Kill %s %s/%s"):format(what, a, b)
	else
		what, a, b = text:match("^(.-): (%d+)/(%d+)$")
		if what then text = ((q.otype == "object" and "Use %s %s/%s") or (q.otype == "monster" and "Kill %s %s/%s") or "Get %s %s/%s"):format(what, a, b) end
	end
	if done then return "|cff40ff40" .. text .. " (done)|r" end
	return text .. "  |cff999999" .. title .. "|r"
end
function ns.QuestLine(q)
	if type(q) ~= "table" then return nil end
	if lineFor ~= q then lineFor, lineText = q, QuestLine(q) end
	return lineText
end

function ns.SetGoal(g, source)
	local e = g and ENTRANCES[g.map]
	if e then g = { map = e[1], x = e[2], y = e[3], name = e[4] .. " entrance" } end
	-- the same spot again (the game's pin we just followed): keep going, no need to start over
	if g and S.goal and g.map == S.goal.map and P.dist(g, S.goal) < 1 then
		S.goal.name, S.goal.source = g.name or S.goal.name, source
		if g.quest then S.goal.quest = g.quest; ns.Refresh() end
		return
	end
	S.goal = g and { map = g.map, x = g.x, y = g.y, name = g.name, source = source, under = g.under, quest = g.quest } or nil
	-- kept for this character, so the trip carries on after /reload or logging out
	JunhotsTravelCharDB.goal = S.goal and { map = g.map, x = g.x, y = g.y, name = g.name, source = source, under = g.under, quest = g.quest } or nil
	S.plan, S.arrived = nil, nil
	ns.Replan(true)
end

local function GoalFromPin()
	if not (C_Map.HasUserWaypoint and C_Map.HasUserWaypoint()) then return nil end
	local wp = C_Map.GetUserWaypoint()
	if not wp then return nil end
	local mx, my = wp.position:GetXY()
	local g = ns.WorldFromMap(wp.uiMapID, mx, my)
	if not g then return nil end
	local info = C_Map.GetMapInfo(wp.uiMapID)
	g.name = "your map pin" .. (info and info.name and (" in " .. info.name) or "")
	return g
end
local function PinChanged()
	-- our own marker at your next turn (Settings), not a new place to go
	if ns.MarkerOwns and ns.MarkerOwns(C_Map.HasUserWaypoint and C_Map.HasUserWaypoint() and C_Map.GetUserWaypoint() or nil) then return end
	local g = GoalFromPin()
	if g then ns.SetGoal(g, "pin")
	elseif S.goal and S.goal.source == "pin" then ns.SetGoal(nil) end
end

-- You're there: say so for a moment, then everything goes away (the game's map pin too).
local SHOW_THERE = 3 -- seconds
local function Arrive()
	if S.arrived then return end
	S.arrived, S.plan = true, nil
	local g = S.goal
	if JunhotsTravelDB.sound and PlaySound and SOUNDKIT then
		local id = SOUNDKIT.MAP_PING or SOUNDKIT.IG_QUEST_LIST_COMPLETE
		if id then pcall(PlaySound, id, "Master") end
	end
	ns.Refresh()
	C_Timer.After(SHOW_THERE, function()
		if S.goal ~= g then return end
		if g.source == "pin" and C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
		ns.SetGoal(nil)
	end)
end

-- ---------- planning ----------
-- A walk goes through fixed places (path). l.at = the place you head for now; places within 20 yd count as passed,
-- and a passed place stays passed, so walking away from it never sends you back.
local function Advance(plan, here)
	local l = plan and plan.legs[1]
	if not (l and l.k == "walk" and here) then return end
	l.at = l.at or 2
	while l.at < #l.path do
		local q, nx = l.path[l.at], l.path[l.at + 1]
		-- reached it, or already closer to the one after it than it is (you cut the corner)
		if q.map == here.map and (P.dist(here, q) < 20 or (nx.map == here.map and P.dist(here, nx) < P.dist(q, nx))) then
			l.at = l.at + 1
		else
			break
		end
	end
	-- look ahead: head for the furthest spot of the next few you can run to in a straight line (never back to a
	-- spot behind you or round a bend you can cut). Not under ground (the fine detail is the land on top).
	if IsIndoors and IsIndoors() then return end
	local now = GetTime()
	if l.lookT and now - l.lookT < 0.5 and l.lookAt == l.at then return end
	l.lookT = now
	for k = math.min(#l.path, l.at + 6), l.at + 1, -1 do
		local q = l.path[k]
		local ok = q.map == here.map and P.dist(here, q) <= 300
		for j = l.at, k do if ok and P.Covered(l.path[j]) then ok = false end end
		-- along a road: keep to it (a road spot is only passed by when the straight line goes close to it)
		for j = l.at, k - 1 do
			local q = l.path[j]
			if ok and P.OnRoad(q) and P.dist(here, q) > P.ROADKEEP and P.SegDist(q, here, l.path[k]) > P.ROADKEEP then ok = false end
		end
		if ok and P.CanRun(here, q) then l.at = k; break end
	end
	l.lookAt = l.at
end

-- The next place you head for: the place on your walk, or where a ride starts.
local function Waypoint(plan)
	local l = plan and plan.legs[1]
	if not l then return nil end
	if l.k ~= "walk" then return l.from end
	return l.path[l.at or 2]
end
ns.Waypoint = Waypoint

-- Seconds left on the plan you are on, from here.
local function KeepCost(old, here, speed)
	local l = old.legs[1]
	if not l or l.k ~= "walk" then return nil end
	local i = l.at or 2
	local w, before = l.path[i], l.path[i - 1]
	-- at the end of the walk already: the new plan starts from here
	if w.map ~= here.map or P.dist(here, w) < 20 then return nil end
	local toW
	if before.key ~= "S" and before.map == here.map and P.dist(before, w) > 1 then
		-- the part of this stretch still ahead, at the stretch's own walking time
		toW = (l.cum[i] - l.cum[i - 1]) * math.min(1.5, P.dist(here, w) / P.dist(before, w))
	else
		toW = P.dist(here, w) * 1.4 / speed
	end
	return toW + old.secs0 - l.cum[i], toW + l.secs0 - l.cum[i]
end

function ns.Replan(force)
	local g = S.goal
	if not g then S.plan = nil; ns.Refresh(); return end
	if UnitOnTaxi("player") then ns.Refresh(); return end
	local here = ns.Here()
	if not here then ns.Refresh(); return end
	-- inside a dungeon: from its door
	local e = ENTRANCES[here.map]
	if e then here = { map = e[1], x = e[2], y = e[3] }
	else here.under = (IsIndoors and IsIndoors()) and true or false end   -- in a cave, tunnel or the Undercity: start down there
	if here.map == g.map and P.dist(here, g) <= ArriveDist() then return Arrive() end
	S.arrived = nil
	local o = Opts()
	local old = S.plan
	Advance(old, here)
	local new = P.Route(here, g, o)
	if new then
		for _, l in ipairs(new.legs) do if l.leaves then l.leavesAt = GetTime() + l.leaves end end
		new.secs0 = new.secs
		if new.legs[1] then new.legs[1].secs0 = new.legs[1].secs end
	end
	Advance(new, here)
	if new and old and not force then
		local keep, firstLeft = KeepCost(old, here, o.speed)
		-- stay on your plan unless the new one saves real time
		if keep and new.secs + KeepMargin(keep) >= keep then
			old.secs, old.legs[1].secs, old.legs[1].here = keep, firstLeft, here
			new = old
		end
	end
	S.plan = new
	ns.Refresh()
end

-- between replans: tick off the spots you passed, and say when you are there
function ns.Follow()
	local here = ns.Here()
	local g = S.goal
	if not (here and g) then return end
	if here.map == g.map and P.dist(here, g) <= ArriveDist() then return Arrive() end
	local l = S.plan and S.plan.legs[1]
	-- a ride is over (or you went another way): plan again now
	if not l or (l.k ~= "walk" and (here.map ~= l.from.map or P.dist(here, l.from) > 100)) then return ns.Replan(true) end
	Advance(S.plan, here)
	ns.Refresh()
end

-- the spot the arrow points at
-- (goes round a ridge first when the straight line to the waypoint crosses one)
function ns.NextSpot()
	local w = Waypoint(S.plan)
	local here = ns.Here()
	if w and here and w.map == here.map and S.plan.legs[1].k == "walk" then
		if ns.Ras and ns.Ras.Has(here.map) then
			local way = ns.LocalWay(here, w)
			return way and way[1] or w
		end
		return P.Round(here, w) or w
	end
	return w
end

-- When a wall, building or rock stands between you and your next spot: the corners to go round it (last = the spot),
-- from the fine walking detail (Ras.lua). nil when you can run straight. Worked out at most 5 times a second.
local LW = {}
function ns.LocalWay(here, w)
	local R = ns.Ras
	if not (R and R.Has(here.map) and w and w.map == here.map) then return nil end
	-- indoors: only where the fine detail has the building's own floor (not caves without it, or the Undercity)
	local indoor = IsIndoors and IsIndoors() and true or false
	R.indoor = indoor and R.HasIndoor(here.map, here.x)
	if indoor and not R.indoor then return nil end
	if LW.indoor ~= R.indoor then LW.w, LW.way, LW.t, LW.indoor = nil, nil, nil, R.indoor end
	local now = GetTime()
	if LW.w == w and LW.t and now - LW.t < 0.2 then return LW.way end
	LW.t = now
	local map = here.map
	if R.Clear(map, here.x, here.y, w.x, w.y) then LW.w, LW.way = w, nil; return nil end
	local way = LW.w == w and LW.way
	if way then
		-- drop corners you have reached, or can already run straight past
		while #way > 1 and (P.dist(here, way[1]) < 6 or R.Clear(map, here.x, here.y, way[2].x, way[2].y)) do table.remove(way, 1) end
		if not R.Clear(map, here.x, here.y, way[1].x, way[1].y) then way = nil end
	end
	if not way then
		-- no way found round it lately (an island, or the box too small): don't search again for a few seconds
		if LW.failW == w and now - LW.failT < 3 then LW.w, LW.way = w, nil; return nil end
		way = R.Way(map, here.x, here.y, w.x, w.y, 120)
		if not way then LW.failW, LW.failT = w, now end
	end
	if way then way[#way] = w end
	LW.w, LW.way = w, way
	return way
end

-- ---------- events ----------
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self, ev, ...)
	local arg = ...
	if ev == "ADDON_LOADED" and arg == ADDON then
		JunhotsTravelDB = JunhotsTravelDB or {}
		JunhotsTravelCharDB = JunhotsTravelCharDB or {}
	elseif ev == "PLAYER_LOGIN" then
		FromGearSnapshot()
		self:RegisterEvent("TAXIMAP_OPENED")
		self:RegisterEvent("USER_WAYPOINT_UPDATED")
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
		self:RegisterEvent("PLAYER_CONTROL_GAINED")
		self:RegisterEvent("HEARTHSTONE_BOUND")
		self:RegisterEvent("QUEST_LOG_UPDATE")
		if self.RegisterUnitEvent then self:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player") end
		ns.Safe("start", ns.UIInit)
		if ns.MapClickInit then ns.Safe("map click", ns.MapClickInit) end
		if ns.PinClickInit then ns.Safe("pin click", ns.PinClickInit) end
		if ns.MinimapInit then ns.Safe("minimap", ns.MinimapInit) end
		if ns.SettingsInit then ns.SettingsInit() end
		ns.Safe("pin", PinChanged)
		-- carry on with the trip you were on before /reload or logging out
		local kept = JunhotsTravelCharDB.goal
		if not S.goal and kept and kept.map and kept.x and kept.y and kept.source ~= "pin" then
			ns.Safe("resume", ns.SetGoal, kept, kept.source)
		end
		-- every second: follow your plan; every 4 seconds: look for a faster one
		local n = 0
		C_Timer.NewTicker(1, function()
			if landing then ns.Safe("hearth", WatchLanding, ns.Here()) end
			ns.Safe("boats", WatchBoats, ns.Here())
			if not ns.clickInit then ns.Safe("map click", ns.MapClickInit) end   -- the map can load after login
			if not S.goal then ns.Safe("map", ns.Draw); return end
			n = n + 1
			if n % 4 == 0 or not S.plan then ns.Safe("plan", ns.Replan, false) else ns.Safe("follow", ns.Follow) end
		end)
	elseif ev == "HEARTHSTONE_BOUND" then
		-- you just set your inn here (next to the innkeeper)
		local here, name = ns.Here(), GetBindLocation and GetBindLocation()
		if here and name and canaccess(name) then JunhotsTravelCharDB.bind = { name = name, map = here.map, x = here.x, y = here.y } end
	elseif ev == "UNIT_SPELLCAST_SUCCEEDED" then
		local spell = select(3, ...)
		if spell and canaccess(spell) and spell == HEARTH_SPELL then
			local here = ns.Here()
			landing = { limit = GetTime() + 60, map = here and here.map, x = here and here.x, y = here and here.y }
		end
	elseif ev == "TAXIMAP_OPENED" then
		C_Timer.After(0.3, function()
			pcall(ReadTaxiMap)
			if ns.TaxiMark then ns.Safe("taxi", ns.TaxiMark) end
		end)
	elseif ev == "QUEST_LOG_UPDATE" then
		lineFor = nil
		if S.goal and S.goal.quest then ns.Refresh() end
	elseif ev == "USER_WAYPOINT_UPDATED" then
		ns.Safe("pin", PinChanged)
	elseif ev == "PLAYER_ENTERING_WORLD" or ev == "PLAYER_CONTROL_GAINED" then
		-- landed: how fast was that flight? (a whole flight of 30 s or more, not a loading screen in between)
		if ev == "PLAYER_CONTROL_GAINED" and S.flyStart and S.flyBase and not UnitOnTaxi("player") then
			local took = GetTime() - S.flyStart
			local r = S.flyBase / took
			if took >= 30 and r > 0.6 and r < 2 then
				local old = JunhotsTravelCharDB.flyRate
				JunhotsTravelCharDB.flyRate = old and (old * 0.5 + r * 0.5) or r
				if math.abs(JunhotsTravelCharDB.flyRate - 1) < 0.04 then JunhotsTravelCharDB.flyRate = nil end
			end
		end
		if ev == "PLAYER_ENTERING_WORLD" then S.flyStart = nil end
		if ev == "PLAYER_CONTROL_GAINED" then S.flyStart, S.flyBase = nil, nil end
		C_Timer.After(1, function() S.flying = UnitOnTaxi("player") and S.flying or nil; if not S.flying then S.flyEnd = nil end; ns.Safe("plan", ns.Replan, true) end)
	end
end)

-- the flight you just took, for "Flying to X"
if TakeTaxiNode then
	hooksecurefunc("TakeTaxiNode", function(slot)
		S.flying = TaxiNodeName and TaxiNodeName(slot) or "your flight point"
		-- when you land: the flight's time from the game's own flight paths
		S.flyEnd = nil
		pcall(function()
			local from, to
			for _, node in ipairs(C_TaxiMap.GetAllTaxiNodes(GetTaxiMapID()) or {}) do
				if node.slotIndex == slot then to = node.nodeID end
				if node.slotIndex and TaxiNodeGetType(node.slotIndex) == "CURRENT" then from = node.nodeID end
			end
			local secs = from and to and P.FlyTime(from, to, Known())
			if secs then
				-- your own speed (a flight upgrade), learned from your earlier flights
				S.flyBase, S.flyStart = secs, GetTime()
				S.flyEnd = GetTime() + secs / (JunhotsTravelCharDB.flyRate or 1)
			end
		end)
		ns.Refresh()
	end)
end

-- ---------- slash ----------
SLASH_JUNHOTSTRAVEL1, SLASH_JUNHOTSTRAVEL2 = "/jt", "/travel"
SlashCmdList.JUNHOTSTRAVEL = function(msg)
	msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
	local x, y = msg:match("^([%d%.]+)[%s,]+([%d%.]+)$")
	if x then
		local ui = C_Map.GetBestMapForUnit("player")
		local g = ui and ns.WorldFromMap(ui, tonumber(x) / 100, tonumber(y) / 100)
		if g then
			local info = C_Map.GetMapInfo(ui)
			g.name = x .. ", " .. y .. (info and (" in " .. info.name) or "")
			ns.SetGoal(g, "slash")
		end
	elseif msg == "clear" or msg == "stop" then
		if C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
		ns.SetGoal(nil)
	elseif msg == "status" then
		local p = S.plan
		print("|cff66ccffJunhots Travel|r " .. (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON, "Version") or ""))
		print("  Going to: " .. (S.goal and (S.goal.name or "a spot") or "nowhere (Shift+click the world map)"))
		print("  Route: " .. (p and (#p.legs .. " steps, " .. P.Time(p.secs)) or (S.arrived and "you're there" or "none")))
		print("  Flight points known: " .. ns.KnownCount() .. "   Stitched map (OpenMap): " .. (ns.OpenMap and ns.OpenMap() and "yes" or "no"))
		print("  Map click ready: " .. (ns.clickInit and "yes" or "no"))
		print("  Arrow art: " .. tostring(ns.arrowArt) .. ", style " .. ns.ArrowStyle() .. "   Minimap shape: " .. tostring(GetMinimapShape and GetMinimapShape() or "ROUND"))
		local h = Hearth()
		print("  Hearthstone: " .. (h and (h.name .. (h.wait > 0 and (", ready in " .. P.Time(h.wait)) or ", ready")) or "not known yet (set your inn or use it once)"))
		for _, e in ipairs(ns.errors or {}) do print("  |cffff6666" .. e .. "|r") end
	elseif msg == "dots" or msg == "line" then
		JunhotsTravelDB.trail = msg
		print("|cff66ccffJunhots Travel|r: walking way shown as " .. (msg == "dots" and "dots" or "a line") .. ".")
		ns.Refresh()
	elseif msg == "arrow" or msg == "arrow ring" or msg == "arrow plain" then
		local st = msg:match("arrow (%a+)") or (ns.ArrowStyle() == "ring" and "plain" or "ring")
		JunhotsTravelDB.arrowStyle = st
		ns.ArrowLayout()
		print("|cff66ccffJunhots Travel|r: arrow style " .. st .. " (/jt arrow to switch).")
		ns.Refresh()
	elseif msg == "settings" or msg == "options" or msg == "config" then
		if ns.OpenSettings then ns.OpenSettings() end
	elseif msg == "reset" then
		JunhotsTravelDB.arrow = nil
		ns.UIReset()
	else
		ns.TogglePanel()
		if msg ~= "" then
			print("|cff66ccffJunhots Travel|r: Shift+click the world map, or type /jt 45.2 61.8 for a spot in this zone. /jt clear stops. /jt settings for options. /jt status shows what it is doing.")
		end
	end
end

-- For our other addons (the leveling guide later): JunhotsTravel.SetGoal(continent, x, y, "name")
JunhotsTravel = {
	SetGoal = function(map, x, y, name) ns.SetGoal({ map = map, x = x, y = y, name = name }, "api") end,
	Clear = function() ns.SetGoal(nil) end,
	Plan = function() return S.plan end,
}
