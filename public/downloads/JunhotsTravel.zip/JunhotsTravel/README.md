# Junhots Travel

The fastest way to your map pin in WoW Forever: walking, the flights you know, boats, zeppelins, the Deeprun Tram,
lifts and portals. An arrow points to your next stop, and the whole way is drawn on your world map
(flights along their real curves).

## Use

- Shift+click the world map (or Ctrl+click for the game's own pin; it is cleared when you get there). The arrow appears, and your walking way
  shows as small gold dots on the minimap (square minimaps too).
- Shift+click a map icon to go there too. A quest icon (Questie) also says what to do there: turn in, pick up, kill 3/8
  (its glowing objective areas too, and under OpenMap's layer). On the last walk the arrow says what to do there
  ("Turn in …", "Kill … 3/8").
- The arrow circles the game's gold ring, with the distance inside. When you face the right way the ring glows green;
  when the way is behind you it dims. Hover it for help.
- It goes round walls, buildings and cliffs (out through a town's gate), from a fine walking map of the game's own terrain.
  Long walks follow the real 3D way (up the ramp, round a hill too steep to climb), and a flight master up a tower is reached by its stairs.
  Every build is checked by machine against the full 3D walking map on thousands of runs across both continents.
- Inside buildings it leads you out through the door (each building's own floor, not its roof), and steep hills you
  can walk over count as open.
- In caves, tunnels, Ironforge and the Undercity the way starts and ends down there, not on the land above.
- Undercity: from the zeppelins down the lifts to the bat handler (finer walking map there, so its narrow bridges count).
- Trips carry on after /reload or logging out. The step list says what a walk avoids (zones far above you, hostile towns).
- Uses mage, shaman and druid teleports when faster. A goal inside a dungeon or raid goes to its entrance.
- Boat and zeppelin times: once you have ridden a route (or watched it leave), the steps say when it next leaves.
- The game's flight map marks the flight point to pick ("Fly here").
- In the air the ring counts down to landing. Every flight you take is timed, so a faster flight speed (an upgrade)
  is learned by itself and used for the countdown and for planning.
- Walks keep to the game's roads where that costs little extra time (the road textures in the game's terrain).
- Optional: a thin compass bar at the top of the screen, and the game's own waypoint marker at your next turn.
- `/jt settings` (or Esc > Options > AddOns): arrow look and size, distance or time left, dots or line, arrival distance,
  a sound when you arrive, Hearthstone, avoiding high zones.
- Uses your Hearthstone only when it saves at least 5 minutes (it has a long cooldown), learns new flight masters on the way, and walks round enemy towns
  and zones far above your level.
- Works with OpenMap's stitched world map: Shift+click goes to us first, and the way is drawn where OpenMap shows it.
- `/jt status` shows where you are going, the route, and any problem the addon hit. `/jt perf` shows how much time
  each part of the addon used since you last asked.
- Open any flight master's map once per continent so the addon knows your flight points.
  (If you use Gear Snapshot, the points it already saved are used too.)
- Click the arrow: show or hide the steps. Drag: move it. Right-click: stop.
- `/jt 45.2 61.8` goes to a spot in your zone. `/jt clear` stops. `/jt reset` puts the arrow back.

## Data and credits

- Flight points, flight paths and their curves: the game's own files (TaxiNodes, TaxiPath, TaxiPathNode,
  Forever build 1.60.1.71139, read from wago.tools). Flight times are worked out from each curve's length
  (30.03 yards a second), which matches 266 timed flights to within 0.3 seconds (median).
- Walking: our own walking map of both continents, built from the game's terrain, water, rocks, trees and buildings
  (Forever build 1.60.1.71139 map files), with Recast (zlib license) to find where a character can walk. It goes round
  mountains (for example through Blackrock Mountain between Searing Gorge and Burning Steppes) instead of over them.
- Boats, zeppelins, tram, lifts, portals and walking times between fixed places: Shortest Path Forever by cjber,
  GPL-3.0-or-later, https://github.com/cjber/shortest-path-forever . Thank you.

Because it uses that data, this addon is GPL-3.0-or-later too (see LICENSE.txt).
