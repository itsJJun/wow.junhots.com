# Junhots Travel

The fastest way to your map pin in WoW Forever: walking, the flights you know, boats, zeppelins, the Deeprun Tram,
lifts and portals. An arrow points to your next stop, and the whole way is drawn on your world map
(flights along their real curves).

## Use

- Shift+click the world map (or Ctrl+click for the game's own pin; it is cleared when you get there). The arrow appears, and your walking way
  shows as small glowing dots on the minimap (square minimaps too), the same as on the world map.
- Shift+click a map icon to go there too. A quest icon (Questie) also says what to do there: turn in, pick up, kill 3/8
  (its glowing objective areas too, OpenMap's and the game's own quest icons). On the last walk the arrow says what to do there
  ("Turn in …", "Kill … 3/8").
- More than one place: Ctrl+Shift+click adds stops (up to 10), numbered on the map with small badges (4 looks: Settings > Your way > Stop badges).
  The arrow goes to the next stop and moves on when you get there. The fastest order is picked for you, or tick
  "Keep the order I click" on the Route page. `/jt next` skips a stop; a plain Shift+click starts a new trip.
- The arrow circles the game's gold ring, with the distance inside. When you face the right way the ring glows green;
  when the way is behind you it dims. Hover it for help. Place names are gold.
- It goes round walls, buildings and cliffs (out through a town's gate), from a fine walking map of the game's own terrain.
  Long walks follow the real 3D way (up the ramp, round a hill too steep to climb), and a flight master up a tower is reached by its stairs.
  Every build is checked by machine against the full 3D walking map on thousands of runs across both continents,
  starting both outside and inside buildings, basements and caves.
- Inside buildings and caves it knows each floor and follows the one you are on: out of a basement up its stairs and
  through the door, never through the wall, the cave level below or the story above. Steep hills you can walk over
  count as open.
- Outside, straight runs go round hillsides too steep to walk up (the game's own terrain slope), and shallow water you
  wade through (up to 1.75 yards deep, like Witch Hill's pond) is not treated as swimming. The way never starts by
  sending you back to a spot behind you.
- In caves, tunnels, Ironforge and the Undercity the way starts and ends down there, not on the land above
  (in the Undercity also on its canals and open halls, which the game counts as outdoors).
- Undercity: from the zeppelins down the lifts to the bat handler, and along the canals to anyone down there. Its walking
  map is finer and knows each floor; the addon keeps track of which floor you are on, and a goal down there (Shift+click
  someone by the canal) ends on their floor.
- Trips carry on after /reload or logging out. The step list says what a walk avoids (zones far above you, hostile towns).
- Uses mage, shaman and druid teleports when faster. A goal inside a dungeon or raid goes to its entrance.
- Closest spawn: track a quest (or type `/jt quest`) and the arrow goes to the nearest place its monsters, objects
  or item droppers spawn, by walking time, not just a straight line. When you get there (after the fight) it moves on
  to the next nearest you have not been to, and once the quest is done it takes you to hand it in. A quest objective
  you Shift+click on the map goes on the same way. "Follow the quest you track" on the Route page turns it off.
  The world map shows every spawn spot as the game's small gold quest mark. Spots where you killed or looted one
  turn grey with "killed 2 min ago", and the arrow skips them. Once you have seen the same monster come back at the
  same spot a few times, it says "back in about 3 min" instead. No guessed times: only what you saw yourself.
- Boat, zeppelin, lift and tram times: ride one once and the steps say when it next leaves. Your ride is matched
  second by second to the boat's real path, so it is timed exactly (to about a second) and never by mistake.
  The two Menethil-Auberdine boats share a lane; the one you rode is told apart by the time already held.
  Times are shared with your guild and group (newest wins), so you may know a boat you never rode.
  `/jt boats` lists every time held and how far off each one turned out on your next ride. `/jt share` turns
  sharing off or on (also in settings).
- The game's flight map marks the flight point to pick ("Fly here").
- Flights follow the stops the game really flies: each time a flight master's map opens, the addon saves the game's
  route to every place you can fly from there, and its line and time use that. Flights you have not opened yet follow
  the rule worked out from every route saved so far. When getting off midway and taking a new flight is faster, that
  is its own step.
- Glowing colours for your way (a line for flights, dots for walking; the step you are on is brightest). Pick the
  flight colour and the walking colour on their own from 13 colours, and Light, Medium or Bold lines, with a live
  preview of the world map and minimap.
- In the air the ring counts down to landing. Every flight you take is timed, so a faster flight speed (an upgrade)
  is learned by itself and used for the countdown and for planning.
- Walks keep to the game's roads where that costs little extra time (the road textures in the game's terrain).
- Optional: a thin compass bar at the top of the screen, and the game's own waypoint marker at your next turn.
- Its own settings window: the minimap button (left-click; right-click stops the trip; drag it round the edge),
  `/jt settings`, or "Open settings" in Esc > Options > AddOns. Arrow look and size, distance or time left, dots or
  line, colours, line weight, arrival distance, a sound when you arrive, Hearthstone, avoiding high zones.
- Takes a direct flight whenever flights can do the trip (no Hearthstone, boat or zeppelin unless 15+ minutes faster); the Hearthstone also must save 10+ minutes, learns new flight masters on the way, and walks round enemy towns
  and zones far above your level.
- Works with OpenMap's stitched world map: Shift+click goes to us first, and the way is drawn where OpenMap shows it, in combat too (on OpenMap's own combat view).
- `/jt status` shows where you are going, the route, and any problem the addon hit. `/jt perf` shows how much time
  each part of the addon used since you last asked.
- Open any flight master's map once per continent so the addon knows your flight points.
  (If you use Gear Snapshot, the points it already saved are used too.)
- Click the arrow: show or hide the steps. Drag: move it (it snaps to the middle of the screen). Right-click: stop.
  `/jt center` (or the button in settings) centers it left to right.
- `/jt 45.2 61.8` goes to a spot in your zone. `/jt clear` stops. `/jt reset` puts the arrow back.

## Data and credits

- Flight points, flight paths and their curves: the game's own files (TaxiNodes, TaxiPath, TaxiPathNode,
  Forever build 1.60.1.71139, read from wago.tools). Flight times are worked out from each curve's length
  (30.03 yards a second), which matches 266 timed flights to within 0.3 seconds (median).
- Walking: our own walking map of both continents, built from the game's terrain, water, rocks, trees and buildings
  (Forever build 1.60.1.71139 map files), with Recast (zlib license) to find where a character can walk. It goes round
  mountains (for example through Blackrock Mountain between Searing Gorge and Burning Steppes) instead of over them.
- Heights of people and quest objects where floors lie above each other (the Undercity, caves), so the way ends on
  their floor: cmangos classic-db spawns, GPL-3.0, https://github.com/cmangos/classic-db . Thank you.
- Boats, zeppelins, tram, lifts, portals and walking times between fixed places: Shortest Path Forever by cjber,
  GPL-3.0-or-later, https://github.com/cjber/shortest-path-forever . Thank you.
  Timing a ride from where you are along each boat's path (the matching and its numbers) is from Shortest Path
  Forever too (Transport/Model.lua, Observer.lua), with their paths from the game's TaxiPathNode and
  TransportAnimation files timed by the CMaNGOS transport model.

- Where quest monsters, objects and item droppers spawn: QuestieDB for WoW Forever (Questie, GPL-3.0,
  https://github.com/Questie/Questie), with rare droppers left out by CMaNGOS classic-db drop chances. Thank you.

Because it uses that data, this addon is GPL-3.0-or-later too (see LICENSE.txt).
