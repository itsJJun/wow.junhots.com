# Junhots Travel

The fastest way to your map pin in WoW Forever: walking, the flights you know, boats, zeppelins, the Deeprun Tram,
lifts and portals. An arrow points to your next stop, and the whole way is drawn on your world map
(flights along their real curves).

## Use

- Shift+click the world map (or put the game's pin there with Ctrl+click). The arrow appears, and your walking way
  shows as gold dots on the minimap.
- Works with OpenMap's stitched world map: Shift+click goes to us first, and the way is drawn where OpenMap shows it.
- `/jt status` shows where you are going, the route, and any problem the addon hit.
- Open any flight master's map once per continent so the addon knows your flight points.
  (If you use Gear Snapshot, the points it already saved are used too.)
- Click the arrow: show or hide the steps. Drag: move it. Right-click: stop.
- `/jt 45.2 61.8` goes to a spot in your zone. `/jt clear` stops. `/jt reset` puts the arrow back.

## Data and credits

- Flight points, flight paths and their curves: the game's own files (TaxiNodes, TaxiPath, TaxiPathNode,
  Forever build 1.60.1.71139, read from wago.tools). Flight times are worked out from each curve's length
  (30.03 yards a second), which matches 266 timed flights to within 0.3 seconds (median).
- Walking: our own walking map of both continents, built from the game's terrain, water, rocks, trees and buildings
  (Forever build 1.60.1.71139 map files), with Recast (zlib license) to find where a character can walk. It goes round
  mountains (for example through Blackrock Mountain between Searing Gorge and Burning Steppes) instead of over them.
- Boats, zeppelins, tram, lifts, portals and walking times between fixed places: Shortest Path Forever by cjber,
  GPL-3.0-or-later, https://github.com/cjber/shortest-path-forever . Thank you.

Because it uses that data, this addon is GPL-3.0-or-later too (see LICENSE.txt).
