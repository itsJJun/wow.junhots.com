-- Stops (1.10.7, 28 Nov): Ctrl+Shift+click the map adds a stop after the place you are going. The arrow goes to the
-- next stop and moves on by itself when you get there. Order: the fastest (worked out a few ms per frame, from the
-- planner's own trip times), or the order you click (Route page tick box). A plain Shift+click, /jt clear or the
-- minimap button's right-click starts over.
local _, ns = ...
local P = ns.Planner
local S = ns.state

local MAX = 10            -- stops in all, the place you are going to now included
local MOVE_ON = 1.5       -- seconds at a stop ("You're there") before the arrow turns to the next
local SLICE = 2           -- ms per frame for working out the order
local FAR = 1e7           -- no way found between two stops

local rest = {}           -- the stops after the one you are going to now, in order
local legs = {}           -- legs[k]: the plan from stop k to stop k + 1 (stop 1 = where you are going now), for the map
local moving, ready, clearing = false, false, false
local sig, ver = 0, 0     -- sig: the map draws again when it changes; ver: a newer change stops older work
local cache = {}          -- ["a>b"] = plan (or false): stop to stop does not change while you walk

local function DB() return JunhotsTravelDB or {} end
local function KeepClickOrder() return DB().stopOrder == "click" end
local function Key(g) return g.map .. ":" .. math.floor(g.x) .. ":" .. math.floor(g.y) end
local function Copy(g)
	return { map = g.map, x = g.x, y = g.y, name = g.name, under = g.under, quest = g.quest, source = g.source }
end
local function Same(a, b) return a and b and a.map == b.map and P.dist(a, b) < 5 end

local function Save()
	if not JunhotsTravelCharDB then return end
	local t = {}
	for i, g in ipairs(rest) do t[i] = Copy(g) end
	JunhotsTravelCharDB.stops = #t > 0 and t or nil
end
ns.StopsSave = Save
local function Changed()
	sig = sig + 1
	Save()
	ns.Refresh()
end

-- ---------- what the map and the arrow read ----------
function ns.StopsSig() return sig end
function ns.StopsList() return rest end           -- stop 2, 3, ...
function ns.StopLegs() return legs end            -- legs[k]: stop k to stop k + 1 (nil while worked out)
function ns.StopsCount() return #rest end

-- ---------- a new goal starts over (unless it is the next stop) ----------
do
	local SetGoal = ns.SetGoal
	function ns.SetGoal(g, source)
		local same = g and S.goal and g.map == S.goal.map and P.dist(g, S.goal) < 1
		-- the trip's end at a stop (Core clears the goal a few seconds after "You're there"): on to the next instead
		if not g and ready and not moving and not clearing and S.arrived and #rest > 0 then return ns.StopNext() end
		if ready and not moving and not same and (#rest > 0 or #legs > 0) then
			rest, legs = {}, {}
			ver = ver + 1
			Save()
			sig = sig + 1
		end
		if g and JunhotsTravelDB then JunhotsTravelDB.tripped = true end   -- (the first-login tip has done its job)
		return SetGoal(g, source)
	end
end

-- ---------- the order ----------
-- the plan from a to b (stop to stop: kept; no Hearthstone, it may be used on the way there)
local function Plan(a, b, o)
	local k = Key(a) .. ">" .. Key(b)
	local p = cache[k]
	if p == nil then
		local q = {}
		for kk, v in pairs(o) do q[kk] = v end
		q.hearth = nil
		p = P.Route(a, b, q) or false
		cache[k] = p
		ns.Pause()
	end
	return p or nil
end
local function Secs(p) return p and p.secs or FAR end

-- the fastest order of all (from here): every order for up to 7 stops, else nearest first and then 2-opt
local function Best(n, from, cost)
	local idx = {}
	for i = 1, n do idx[i] = i end
	if n <= 7 then
		local best, bestT = nil, math.huge
		local used, cur = {}, {}
		local function go(depth, at, t)
			if t >= bestT then return end
			if depth > n then best, bestT = { unpack(cur) }, t; return end
			for i = 1, n do
				if not used[i] then
					used[i], cur[depth] = true, i
					go(depth + 1, i, t + (at and cost(at, i) or from[i]))
					used[i] = false
				end
			end
		end
		go(1, nil, 0)
		return best
	end
	-- nearest first
	local ord, used, at = {}, {}, nil
	for d = 1, n do
		local bi, bt = nil, math.huge
		for i = 1, n do
			if not used[i] then
				local t = at and cost(at, i) or from[i]
				if t < bt then bi, bt = i, t end
			end
		end
		used[bi], ord[d], at = true, bi, bi
	end
	-- 2-opt: turn a part round while that is faster (an open trip from here)
	local function total(o)
		local t = from[o[1]]
		for d = 2, #o do t = t + cost(o[d - 1], o[d]) end
		return t
	end
	local better = true
	while better do
		better = false
		for i = 1, n - 1 do
			for j = i + 1, n do
				local o = { unpack(ord) }
				for a = i, j do o[a] = ord[j - (a - i)] end
				if total(o) + 0.5 < total(ord) then ord, better = o, true end
			end
		end
	end
	return ord
end

local job
local function Work(v)
	local here = ns.Here()
	if not (S.goal and here) then return end
	local o = ns.PlanOpts and ns.PlanOpts() or {}
	o.slice = ns.async or nil
	local all = { Copy(S.goal) }
	for _, g in ipairs(rest) do all[#all + 1] = g end
	local n = #all
	if not KeepClickOrder() and n > 1 then
		-- trip times: from here to each stop, and between stops (each way the same: half the work)
		local from, between = {}, {}
		for i = 1, n do
			local p = P.Route(here, all[i], o)
			ns.Pause()
			if v ~= ver then return end
			from[i] = Secs(p)
		end
		for i = 1, n do
			between[i] = {}
			for j = 1, i - 1 do
				local t = Secs(Plan(all[j], all[i], o))
				if v ~= ver then return end
				between[i][j], between[j][i] = t, t
			end
		end
		local ord = Best(n, from, function(a, b) return between[a][b] end)
		if v ~= ver then return end
		local first = all[ord[1]]
		rest = {}
		for d = 2, n do rest[#rest + 1] = all[ord[d]] end
		if ord[1] ~= 1 then
			-- a stop on the way is nearer: go there first
			moving = true
			ns.SetGoal(first, first.source == "pin" and "pin" or "stop")
			moving = false
		end
		Changed()
	end
	-- the trips between stops, for the map (faded)
	local nl = {}
	local list = { Copy(S.goal) }
	for _, g in ipairs(rest) do list[#list + 1] = g end
	for k = 1, #list - 1 do
		nl[k] = Plan(list[k], list[k + 1], o)
		if v ~= ver then return end
	end
	legs = nl
	sig = sig + 1
	ns.Refresh()
end

local function Start()
	ver = ver + 1
	legs = {}
	local v = ver
	if not ns.async then job = nil; ns.Safe("stops", Work, v); return end
	job = coroutine.create(function() Work(v) end)
end
ns.StopsReorder = Start

local function Step()
	local ok, err = ns.Resume(job, SLICE)
	if not ok then job = nil; ns.Error("stops", err); return end
	if coroutine.status(job) == "dead" then job = nil end
end

-- ---------- adding a stop ----------
-- g: a world spot { map, x, y, name }. Returns the stop (to name it after a quest icon), or nil.
function ns.StopAdd(g, source)
	if not g then return nil end
	if not S.goal then
		ns.SetGoal(g, source or "click")
		return S.goal
	end
	if Same(g, S.goal) then return S.goal end
	for _, s in ipairs(rest) do if Same(g, s) then return s end end
	if #rest + 1 >= MAX then
		print("|cff66ccffJunhots Travel|r: " .. MAX .. " stops at most. Shift+click starts a new trip.")
		return nil
	end
	local s = Copy(g)
	s.source = source or "click"
	rest[#rest + 1] = s
	Changed()
	Start()
	return s
end

-- the next stop: on to it (the game's map pin goes when you were at it)
local function MoveOn()
	local prev = S.goal
	local nxt = table.remove(rest, 1)
	table.remove(legs, 1)
	if not nxt then return end
	moving = true
	ns.SetGoal(nxt, nxt.source == "pin" and "pin" or "stop")
	moving = false
	if prev and prev.source == "pin" and C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
	Changed()
	if job then Start() end   -- the order was being worked out with that stop in it
end
ns.StopNext = MoveOn

-- ---------- watching for "you're there", saving, logging in ----------
-- every frame: a little of the order work; 4 times a second: at a stop long enough? on to the next
local at, t = nil, 0
local function Watch()
	if not (ready and S.goal and S.arrived and #rest > 0) then at = nil; return end
	at = at or GetTime()
	if GetTime() - at >= MOVE_ON then at = nil; MoveOn() end
end
do
	local drv = CreateFrame("Frame")
	drv:SetScript("OnUpdate", function(_, el)
		if job then Step() end
		t = t + (el or 0)
		if t >= 0.25 then t = 0; ns.Safe("stops", Watch) end
	end)
end
ns.StopsWatch = Watch   -- (tests)

-- another addon's "clear" (JunhotsTravel.Clear) ends the whole trip too
if JunhotsTravel and JunhotsTravel.Clear then
	local clear = JunhotsTravel.Clear
	JunhotsTravel.Clear = function(...)
		clearing = true
		local ok, err = pcall(clear, ...)
		clearing = false
		if not ok then error(err, 0) end
	end
end
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, ev, arg)
	if ev == "ADDON_LOADED" and arg == "JunhotsTravel" then
		local kept = JunhotsTravelCharDB and JunhotsTravelCharDB.stops
		if type(kept) == "table" then
			for _, g in ipairs(kept) do
				if type(g) == "table" and g.map and g.x and g.y and #rest < MAX - 1 then rest[#rest + 1] = g end
			end
		end
	elseif ev == "PLAYER_LOGIN" then
		-- after Core has carried on with your trip
		C_Timer.After(1, function()
			ready = true
			if #rest > 0 then
				if not S.goal then MoveOn() end
				if S.goal then Start() end
			end
		end)
	end
end)

-- /jt next: skip to the next stop
do
	local slash = SlashCmdList.JUNHOTSTRAVEL
	SlashCmdList.JUNHOTSTRAVEL = function(msg)
		local m = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
		if m == "next" or m == "skip" then
			if #rest > 0 then MoveOn() else print("|cff66ccffJunhots Travel|r: no more stops.") end
			return
		end
		clearing = true
		local ok, err = pcall(slash, msg)
		clearing = false
		if not ok then error(err, 0) end
	end
end
