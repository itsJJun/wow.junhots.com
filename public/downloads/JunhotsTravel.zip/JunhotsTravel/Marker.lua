-- Optional (Settings): the game's own waypoint marker - the pin you see out in the world, with its distance - kept at
-- your next turn, so you can follow it without looking at the arrow. It is cleared when you get there or stop.
local _, ns = ...
local S = ns.state
local P = ns.Planner
local mine          -- the pin we placed: { ui, x, y, spot }
local quietUntil = 0

local function Clear()
	if not mine then return end
	local wp = C_Map.GetUserWaypoint and C_Map.GetUserWaypoint()
	if wp and wp.uiMapID == mine.ui then
		quietUntil = GetTime() + 1
		C_Map.ClearUserWaypoint()
	end
	mine = nil
end

-- is the game's pin (or no pin, just after we cleared ours) our own doing? Then it's not a new goal.
function ns.MarkerOwns(wp)
	if not wp then return GetTime() < quietUntil end
	if not mine or wp.uiMapID ~= mine.ui then return false end
	local x, y = wp.position:GetXY()
	return math.abs(x - mine.x) < 1e-4 and math.abs(y - mine.y) < 1e-4
end

function ns.MarkerUpdate()
	local on = JunhotsTravelDB.marker == true and S.goal and not S.arrived and S.plan and not UnitOnTaxi("player")
	if not on then Clear(); return end
	if not (C_Map.GetMapPosFromWorldPos and C_Map.SetUserWaypoint and UiMapPoint) then return end
	local spot = ns.NextSpot()
	if not (spot and spot.map and spot.x) then return end
	if mine and mine.spot.map == spot.map and P.dist(mine.spot, spot) < 3 then return end
	local vec = CreateVector2D(spot.x, spot.y)
	local here = C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
	local ui, pos = C_Map.GetMapPosFromWorldPos(spot.map, vec, here)
	if pos then
		local x, y = pos:GetXY()
		if x < 0 or x > 1 or y < 0 or y > 1 then ui, pos = C_Map.GetMapPosFromWorldPos(spot.map, vec) end
	end
	if not (ui and pos) then return end
	local x, y = pos:GetXY()
	mine = { ui = ui, x = x, y = y, spot = { map = spot.map, x = spot.x, y = spot.y } }
	C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(ui, x, y))
	if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
end
