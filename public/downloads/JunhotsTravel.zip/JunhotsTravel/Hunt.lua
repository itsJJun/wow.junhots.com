-- Closest spawn (1.10.13, 28 Nov): for a quest in your log, the arrow goes to the nearest place its monsters,
-- objects or item droppers spawn (by walking time), moves on to the next nearest when you get there, and takes you
-- to hand it in once it is done. Starts when you track a quest (Settings: on by default), with /jt quest, or when you
-- get to a quest objective you Shift+clicked on the map. Any other trip, /jt clear or the minimap button's
-- right-click stops it. Where things spawn: Spawns.lua (D.quests).
local _, ns = ...
local P, S, D = ns.Planner, ns.state, ns.D
local floor, huge = math.floor, math.huge

local SKIP_FOR = 300   -- s: spots you have been to are skipped this long (they respawn)
local SEEN_R = 35      -- yd: spawns this near a spot you have been to count as seen
local CANDS = 5        -- the nearest few (straight line) get a real trip time
local SLICE = 2        -- ms per frame for those trip times

local H = { seen = {} }   -- seen[i] = { map, x, y, t }
ns.Hunt = H
local function DB() return JunhotsTravelDB or {} end
local function InCombat() return (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player")) end

-- ---------- the data ----------
local cache = {}
local function Decode(s)
	local out = {}
	if type(s) ~= "string" then return out end
	for m, list in s:gmatch("(%d+):([^;]*)") do
		m = tonumber(m)
		for x, y in list:gmatch("(%-?%d+),(%-?%d+)") do out[#out + 1] = { map = m, x = tonumber(x), y = tonumber(y) } end
	end
	return out
end
local function Quest(id)
	if cache[id] ~= nil then return cache[id] or nil end
	local q = D.quests and D.quests[id]
	if not q then cache[id] = false; return nil end
	local t = { ends = Decode(q.e), objs = {} }
	for i, o in ipairs(q) do t.objs[i] = { kind = o[1], label = o[2], pts = Decode(o[3]) } end
	cache[id] = t
	return t
end
H.Quest = Quest

-- the log's objective lines: { text, done }
local function Lines(id)
	local out = {}
	for k = 1, 12 do
		local t, fin = ns.QuestObjective(id, k)
		if not t then break end
		out[k] = { text = t, done = fin }
	end
	return out
end
local function low(s) return (s or ""):lower() end
-- which log line each of the data's objectives is: by name ("Kobold Vermin" in "Kobold Vermin slain: 3/10"), else
-- by order when the counts agree
local function Map(q, lines)
	local m, used = {}, {}
	for i, o in ipairs(q.objs) do
		local l = low(o.label)
		if l ~= "" then
			for n, line in ipairs(lines) do
				if not used[n] and low(line.text):find(l, 1, true) then m[i] = n; used[n] = true; break end
			end
		end
	end
	if #q.objs == #lines then
		for i in ipairs(q.objs) do
			if not m[i] and not used[i] then m[i] = i; used[i] = true end
		end
	end
	return m
end

local OTYPE = { k = "monster", o = "object", i = "item" }
-- every place to go for a quest now: { map, x, y, name, quest = {...} }, or nil and why
local function Targets(id)
	local q = Quest(id)
	if not q then return nil, "no data" end
	local li, title, complete = ns.LogIndex(id)
	if not li then return nil, "not in log" end
	local out = {}
	if complete == 1 or complete == true then
		for _, p in ipairs(q.ends) do
			out[#out + 1] = { map = p.map, x = p.x, y = p.y, name = title or "the quest", quest = { id = id, kind = "turnin", title = title } }
		end
		return out, "turnin"
	end
	if complete == -1 then return nil, "failed" end
	local lines = Lines(id)
	local m = Map(q, lines)
	for i, o in ipairs(q.objs) do
		local n = m[i]
		if n and lines[n] and not lines[n].done then
			for _, p in ipairs(o.pts) do
				out[#out + 1] = { map = p.map, x = p.x, y = p.y, name = o.label,
					quest = { id = id, kind = "objective", obj = n, otype = OTYPE[o.kind], title = title } }
			end
		end
	end
	if #out == 0 then
		local open = false
		for _, l in ipairs(lines) do if not l.done then open = true end end
		return nil, open and "no spawns" or "done"
	end
	return out, "objective"
end
H.Targets = Targets

-- ---------- spots you have been to ----------
local function Seen(g)
	local now = GetTime()
	local keep = {}
	for _, s in ipairs(H.seen) do if now - s.t < SKIP_FOR then keep[#keep + 1] = s end end
	if g then keep[#keep + 1] = { map = g.map, x = g.x, y = g.y, t = now } end
	H.seen = keep
end
local function WasSeen(p)
	for _, s in ipairs(H.seen) do
		if s.map == p.map and P.dist(s, p) < SEEN_R then return true end
	end
	return false
end

-- ---------- picking the closest ----------
local mine = false          -- our own SetGoal calls
local clearing = false      -- /jt clear and other addons' Clear: stop for good
local job, jobFor
local function Go(g)
	mine = true
	ns.SetGoal(g, "hunt")
	mine = false
	H.id = g and g.quest and g.quest.id or nil
end
local function Near(list, here, n)
	local same = {}
	for _, p in ipairs(list) do
		if p.map == here.map then same[#same + 1] = p end
	end
	if #same == 0 then same = list end
	for _, p in ipairs(same) do p.d = p.map == here.map and P.dist(p, here) or huge end
	table.sort(same, function(a, b) return a.d < b.d end)
	local out = {}
	for i = 1, math.min(n, #same) do out[i] = same[i] end
	return out
end
-- the closest by trip time among the nearest few (a river or a cliff between makes the nearest slow)
local function Best(cands, here)
	if #cands <= 1 then return cands[1] end
	local o = ns.PlanOpts and ns.PlanOpts() or {}
	o.slice = ns.async or nil
	local best, bestT = cands[1], huge
	for _, c in ipairs(cands) do
		local p = P.Route(here, c, o)
		if ns.Pause then ns.Pause() end
		local t = p and p.secs or huge
		if t < bestT then best, bestT = c, t end
	end
	return best
end

-- Go to the closest place for quest id. Returns true when there is one (false: nothing left to go to).
function H.Start(id, quiet)
	local here = ns.Here()
	local list, why = Targets(id)
	if not (list and here) then
		if not quiet then
			local _, title = ns.LogIndex(id)
			local name = title and ("|cffffd100" .. title .. "|r") or "that quest"
			local say = { ["no data"] = "no spawn places known for ", ["not in log"] = "not in your quest log: ",
				["no spawns"] = "no spawn places known for what is left of ", ["done"] = "nothing left to find for ", failed = "failed: " }
			print("|cff66ccffJunhots Travel|r: " .. (say[why] or "nothing to go to for ") .. name .. ".")
		end
		return false
	end
	Seen()
	local fresh = {}
	for _, p in ipairs(list) do if not WasSeen(p) then fresh[#fresh + 1] = p end end
	if #fresh == 0 then H.seen = {}; fresh = list end   -- been everywhere: they have respawned by now
	local cands = Near(fresh, here, CANDS)
	-- the nearest at once, then the quickest to get to when the trip times are in
	Go(cands[1])
	if #cands > 1 and cands[1].map == here.map then
		local v = {}
		jobFor = v
		local function work()
			local b = Best(cands, here)
			if jobFor == v and b and b ~= cands[1] and S.goal and S.goal.source == "hunt" and not S.arrived then Go(b) end
		end
		if ns.async then job = coroutine.create(work) else ns.Safe("hunt", work) end
	end
	return true
end

-- the quest of the goal you are on, when it can go on (an objective of a quest in the log)
local function GoalQuest(g)
	local q = g and g.quest
	if not (q and q.id and q.kind == "objective" and D.quests and D.quests[q.id]) then return nil end
	if not ns.LogIndex(q.id) then return nil end
	return q.id
end

-- ---------- when you get there: on to the next ----------
local waitFight
do
	local SetGoal = ns.SetGoal
	function ns.SetGoal(g, source)
		if not mine then
			jobFor = nil
			-- Core ends the trip a few seconds after "You're there": a hunt (or a quest objective you clicked) goes on
			local id = not g and not clearing and S.arrived and S.goal and (S.goal.source == "hunt" or source == nil)
				and not (ns.StopsCount and ns.StopsCount() > 0) and GoalQuest(S.goal)
			if id then
				Seen(S.goal)
				if InCombat() then waitFight = id; return end   -- the fight there first
				if H.Start(id, true) then return end
			end
			if g or clearing then H.id = nil end
		end
		return SetGoal(g, source)
	end
end

-- an objective done (or the whole quest) while on the way: the next thing to do
local lastCheck = 0
local function Check()
	if waitFight and not InCombat() then
		local id = waitFight
		waitFight = nil
		if S.goal and S.arrived then
			if not H.Start(id, true) then
				mine = true; ns.SetGoal(nil); mine = false
			end
		end
		return
	end
	local g = S.goal
	if not (g and g.source == "hunt" and g.quest and g.quest.id) then return end
	local id, q = g.quest.id, g.quest
	local li, _, complete = ns.LogIndex(id)
	if not li then
		-- handed in (or dropped): the trip is over
		mine = true; ns.SetGoal(nil); mine = false; H.id = nil
		return
	end
	local done = complete == 1 or complete == true
	if q.kind == "objective" then
		local _, fin = ns.QuestObjective(id, q.obj or 1)
		if done or fin then H.Start(id, true) end
	end
end
H.Check = Check

-- ---------- starting ----------
-- the quests you track (the game's watch list), in its order
local function Watched()
	local out = {}
	if GetNumQuestWatches and GetQuestIndexForWatch and GetQuestLogTitle then
		for i = 1, (GetNumQuestWatches() or 0) do
			local li = GetQuestIndexForWatch(i)
			local id = li and select(8, GetQuestLogTitle(li))
			if id then out[#out + 1] = id end
		end
	end
	return out
end
-- /jt quest: the tracked quest nearest to something left to do (any quest in your log when none is tracked)
function H.Any()
	local here = ns.Here()
	if not here then return false end
	local ids = Watched()
	if #ids == 0 and GetNumQuestLogEntries and GetQuestLogTitle then
		for i = 1, (GetNumQuestLogEntries() or 0) do
			local _, _, _, header, _, _, _, qid = GetQuestLogTitle(i)
			if not header and qid then ids[#ids + 1] = qid end
		end
	end
	local best, bestD
	for _, id in ipairs(ids) do
		local list = Targets(id)
		if list then
			local c = Near(list, here, 1)[1]
			if c and (not bestD or c.d < bestD) then best, bestD = id, c.d end
		end
	end
	if not best then
		print("|cff66ccffJunhots Travel|r: no quest in your log with spawn places known.")
		return false
	end
	return H.Start(best)
end

-- tracking a quest (Shift+click in the quest log, or the game tracking it for you) starts it, unless you are on
-- another trip
local function Tracked(li)
	if DB().followQuest == false or not li or not GetQuestLogTitle then return end
	local _, _, _, header, _, _, _, id = GetQuestLogTitle(li)
	if header or not id then return end
	if S.goal and S.goal.source ~= "hunt" then return end
	if S.goal and S.goal.source == "hunt" and H.id == id then return end
	C_Timer.After(0, function() ns.Safe("hunt", H.Start, id, true) end)
end
H.Tracked = Tracked

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self, ev)
	if ev == "PLAYER_LOGIN" then
		if hooksecurefunc and AddQuestWatch then hooksecurefunc("AddQuestWatch", function(li) Tracked(li) end) end
		if hooksecurefunc and C_QuestLog and C_QuestLog.AddQuestWatch then
			hooksecurefunc(C_QuestLog, "AddQuestWatch", function(id) Tracked(ns.LogIndex(id)) end)
		end
		self:RegisterEvent("QUEST_LOG_UPDATE")
		self:SetScript("OnUpdate", function(_, el)
			if job then
				local ok, err = ns.Resume(job, SLICE)
				if not ok then job = nil; ns.Error("hunt", err)
				elseif coroutine.status(job) == "dead" then job = nil end
			end
			lastCheck = lastCheck + (el or 0)
			if waitFight and lastCheck >= 0.5 then lastCheck = 0; ns.Safe("hunt", Check) end
		end)
	elseif ev == "QUEST_LOG_UPDATE" then
		-- many at once: one look a moment later
		if not H.pending then
			H.pending = true
			C_Timer.After(0.5, function() H.pending = nil; ns.Safe("hunt", Check) end)
		end
	end
end)

-- /jt quest, and /jt clear stopping it for good
do
	local slash = SlashCmdList.JUNHOTSTRAVEL
	SlashCmdList.JUNHOTSTRAVEL = function(msg)
		local m = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
		if m == "quest" or m == "q" then ns.Safe("hunt", H.Any); return end
		clearing = true
		local ok, err = pcall(slash, msg)
		clearing = false
		if not ok then error(err, 0) end
	end
	if JunhotsTravel and JunhotsTravel.Clear then
		local clear = JunhotsTravel.Clear
		JunhotsTravel.Clear = function(...)
			clearing = true
			local ok, err = pcall(clear, ...)
			clearing = false
			if not ok then error(err, 0) end
		end
	end
end
