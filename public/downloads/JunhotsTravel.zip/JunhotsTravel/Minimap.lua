-- Your walking way on the minimap: the same glowing beads (or one line) as on the world map, in the same colour
-- (Map.lua ns.LookParts: the walking colour).
local _, ns = ...
local P = ns.Planner
local S = ns.state
local canaccess = canaccessvalue or function() return true end
local sin, cos, sqrt, floor = math.sin, math.cos, math.sqrt, math.floor

-- minimap width in yards for each zoom level (the game's own sizes)
local SIZE = {
	outdoor = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 },
	indoor = { [0] = 300, 240, 180, 120, 80, 50 },
}
local MAXSEGS = 120
local GAP = 9          -- the line starts this many pixels from you (clear of your arrow)
local EDGE = 2         -- and stops this far inside the minimap's edge

-- square minimaps (set by minimap addons through GetMinimapShape) let the way run into the corners
local function Square()
	return GetMinimapShape and GetMinimapShape() == "SQUARE"
end
local MEDIA = "Interface\\AddOns\\JunhotsTravel\\media\\"
local frame, lines, used = nil, {}, 0
local TH = 24              -- as Map.lua's lines (the art is made for this thickness)
local BEAD, BEADSTEP = 18, 11   -- as Map.lua's walking beads
local dots, dused = {}, 0
local function Dot(x, y, tex)
	dused = dused + 1
	local t = dots[dused]
	if not t then
		t = ns.NoSnap(frame:CreateTexture(nil, "OVERLAY", nil, 7))
		t:SetSize(BEAD, BEAD)
		dots[dused] = t
	end
	if t.jtTex ~= tex then t:SetTexture(MEDIA .. tex); t.jtTex = tex end
	-- (the same anchor again replaces the old one: no ClearAllPoints; Show only when hidden)
	t:SetPoint("CENTER", Minimap, "CENTER", x, y)
	if not t.jtOn then t:Show(); t.jtOn = true end
end

-- one piece of line (media/ink.tga or media/cream.tga)
local function Seg(ax, ay, bx, by, tex, th, sub)
	used = used + 1
	local l = lines[used]
	if not l then
		l = ns.NoSnap(frame:CreateLine(nil, "OVERLAY"))
		lines[used] = l
	end
	-- only what changed: the ends move every frame, the look stays
	if l.jtTex ~= tex or l.jtTh ~= th or l.jtSub ~= sub then
		l:SetTexture(MEDIA .. tex)
		l:SetDrawLayer("OVERLAY", sub)
		l:SetVertexColor(1, 1, 1, 1)
		l:SetThickness(th)
		l.jtTex, l.jtTh, l.jtSub = tex, th, sub
	end
	l:SetStartPoint("CENTER", Minimap, ax, ay)
	l:SetEndPoint("CENTER", Minimap, bx, by)
	if not l.jtOn then l:Show(); l.jtOn = true end
end

-- the part of segment a-b that is outside r0 (pixels from the centre) and inside the minimap
-- (a circle of radius r1, or a square of half-width r1), or nil
local function Clip(ax, ay, bx, by, r0, r1, sq)
	local dx, dy = bx - ax, by - ay
	local A = dx * dx + dy * dy
	if A < 1e-6 then return nil end
	local t0, t1 = 0, 1
	local B, C1 = 2 * (ax * dx + ay * dy), ax * ax + ay * ay
	if sq then
		for _, pq in ipairs({ { -dx, ax + r1 }, { dx, r1 - ax }, { -dy, ay + r1 }, { dy, r1 - ay } }) do
			local p, q = pq[1], pq[2]
			if p == 0 then
				if q < 0 then return nil end
			else
				local r = q / p
				if p < 0 then t0 = math.max(t0, r) else t1 = math.min(t1, r) end
			end
		end
	else
		local D = B * B - 4 * A * (C1 - r1 * r1)
		if D <= 0 then return nil end
		local s = math.sqrt(D)
		t0, t1 = math.max(t0, (-B - s) / (2 * A)), math.min(t1, (-B + s) / (2 * A))
	end
	if t0 >= t1 then return nil end
	-- outside r0 (only the start of the way is near you, so cut the front)
	local D0 = B * B - 4 * A * (C1 - r0 * r0)
	if D0 > 0 then
		local s0 = math.sqrt(D0)
		local e0, e1 = (-B - s0) / (2 * A), (-B + s0) / (2 * A)
		if e0 <= t0 and e1 >= t1 then return nil end
		if e0 <= t0 and e1 > t0 then t0 = e1 end
		if e1 >= t1 and e0 < t1 then t1 = e0 end
	end
	if t0 >= t1 then return nil end
	return ax + dx * t0, ay + dy * t0, ax + dx * t1, ay + dy * t1
end

-- indoors? The game keeps a separate zoom for each; the one the minimap uses now tells which.
-- When both zooms are the same (Jun's: 5 and 5) that tells nothing, and IsIndoors() flips on and off by buildings
-- (sharp turns in town): the dots jumped between two sizes (133 and 50 yd), a heavy flicker (Jun 28 Nov). So only
-- when the minimap itself says it changed (MINIMAP_UPDATE_ZOOM) we look again: one zoom step and back, as
-- HereBeDragons does.
local indoorSeen   -- the minimap's mode, as last looked at
local probedAt = -10   -- our own zoom step makes the same event: not a change
local function LookIndoors()
	local zoom = Minimap:GetZoom()
	local out = tonumber(GetCVar and GetCVar("minimapZoom") or "") or 0
	local ins = tonumber(GetCVar and GetCVar("minimapInsideZoom") or "") or 0
	if out ~= ins then indoorSeen = ins == zoom; return end
	if not Minimap.SetZoom then indoorSeen = IsIndoors and IsIndoors() or false; return end
	probedAt = GetTime()
	Minimap:SetZoom(zoom < 2 and zoom + 1 or zoom - 1)
	indoorSeen = (tonumber(GetCVar("minimapZoom")) or 0) ~= Minimap:GetZoom()
	Minimap:SetZoom(zoom)
end
local function Indoors()
	if indoorSeen == nil then LookIndoors() end
	return indoorSeen
end
-- yards from the minimap's middle to its edge: the game says it (C_Minimap.GetViewRadius, in Forever's own API
-- list), else from the zoom
local function Radius()
	if C_Minimap and C_Minimap.GetViewRadius then
		local r = C_Minimap.GetViewRadius()
		-- (only a size the minimap can have at this zoom, indoors or out)
		local z = Minimap:GetZoom()
		local a, b = (SIZE.outdoor[z] or 400) / 2, (SIZE.indoor[z] or 150) / 2
		if type(r) == "number" and ((r > a * 0.8 and r < a * 1.25) or (r > b * 0.8 and r < b * 1.25)) then return r end
	end
	return (SIZE[Indoors() and "indoor" or "outdoor"][Minimap:GetZoom()] or 400) / 2
end

-- the spots your walk goes through on this continent, starting where you stand
local function WalkSpots(here)
	local plan = S.plan
	if not plan then return nil end
	local pts = { here }
	for i, l in ipairs(plan.legs) do
		if l.k ~= "walk" then break end
		for j = (i == 1 and l.at or 2), #(l.path or {}) do
			local q = l.path[j]
			if q.map ~= here.map then break end
			local prev = pts[#pts]
			-- from you to your next spot: round walls and buildings first
			local way = i == 1 and j == l.at and ns.LocalWay and ns.LocalWay(here, q)
			if way then
				for k = 1, #way - 1 do pts[#pts + 1] = way[k] end
			else
				local r = P.Round(prev, q)
				if r then pts[#pts + 1] = r end
			end
			pts[#pts + 1] = q
			-- far past the minimap's edge: enough
			if q.map == here.map and P.dist(here, q) > 700 then break end
		end
		local last = pts[#pts]
		if last and last.map == here.map and P.dist(here, last) > 700 then break end
	end
	if #pts < 3 or not ns.SmoothLine then return pts end
	local xy = {}
	for k, q in ipairs(pts) do xy[k] = { q[1] or q.x, q[2] or q.y } end
	local out = {}
	for k, q in ipairs(ns.SmoothLine(xy)) do out[k] = { x = q[1], y = q[2] } end
	return out
end

-- the way's spots are worked out 10 times a second (the walk, the way round walls); every frame only your own spot moves
local cachePts, cacheT, cachePlan = nil, 0, nil
-- (every frame: in arrays kept from frame to frame, no new tables)
local XS, YS = {}, {}
local function AlongXY(n, step, first, put, max, tex)
	local carry, c = first, 0
	for i = 2, n do
		local ax, ay = XS[i - 1], YS[i - 1]
		local dx, dy = XS[i] - ax, YS[i] - ay
		local len = math.sqrt(dx * dx + dy * dy)
		local d = carry
		while d < len do
			c = c + 1
			if c > max then return end
			put(ax + dx * d / len, ay + dy * d / len, tex)
			d = d + step
		end
		carry = d - len
	end
end
local function Update()
	used, dused = 0, 0
	local here = S.goal and not S.arrived and ns.Here()
	local pts
	if here and not UnitOnTaxi("player") then
		local now = GetTime()
		if not cachePts or cachePlan ~= S.plan or now - cacheT > 0.1 then
			cachePts, cacheT, cachePlan = WalkSpots(here), now, S.plan
		end
		pts = cachePts
		if pts and pts[1] then pts[1].x, pts[1].y = here.x, here.y end
	else
		cachePts = nil
	end
	if pts and #pts > 1 then
		local w, h = Minimap:GetWidth(), Minimap:GetHeight()
		local px = w / 2 / Radius()
		local rot = GetCVar and GetCVar("rotateMinimap") == "1"
		local f = rot and GetPlayerFacing and GetPlayerFacing()
		if f and not canaccess(f) then f = nil end
		local cf, sf = f and cos(f) or 1, f and sin(f) or 0
		local R = w / 2 - EDGE
		local sq = Square()
		local n = #pts
		for i = 1, n do
			local q = pts[i]
			local north, east = q.x - here.x, -(q.y - here.y)   -- world x grows north, y grows west
			if f then east, north = east * cf + north * sf, -east * sf + north * cf end
			XS[i], YS[i] = east * px, north * px * (h / w)
		end
		local lineC, beadC = "teal", "teal"
		if ns.LookTex then lineC, beadC = ns.LookTex() end
		if ns.TrailStyle() == "line" then
			for i = 2, n do
				local ax, ay, bx, by = Clip(XS[i - 1], YS[i - 1], XS[i], YS[i], GAP, R, sq)
				if ax then Seg(ax, ay, bx, by, "line_" .. beadC, TH, 7) end
				if used >= MAXSEGS then break end
			end
		else
			-- beads from just outside your arrow to just inside the edge
			AlongXY(n, BEADSTEP, GAP, function(x, y, tex)
				local r2 = x * x + y * y
				if r2 < GAP * GAP * 0.8 then return end
				if sq then
					if math.abs(x) > R or math.abs(y) > R then return end
				elseif r2 > R * R then return end
				Dot(x, y, tex)
			end, 120, "dot_" .. beadC)
		end
	end
	for i = used + 1, #lines do local l = lines[i]; if l.jtOn then l:Hide(); l.jtOn = false end end
	for i = dused + 1, #dots do local t = dots[i]; if t.jtOn then t:Hide(); t.jtOn = false end end
end

function ns.MinimapInit()
	if frame or not Minimap then return end
	frame = CreateFrame("Frame", nil, Minimap)
	frame:SetAllPoints(Minimap)
	-- the minimap went indoors or out, or zoomed: look again (once, not every frame)
	frame:RegisterEvent("MINIMAP_UPDATE_ZOOM")
	frame:RegisterEvent("PLAYER_ENTERING_WORLD")
	frame:SetScript("OnEvent", function() if GetTime() - probedAt > 0.5 then indoorSeen = nil end end)
	frame:SetFrameLevel(Minimap:GetFrameLevel() + 5)
	local t = 0
	frame:SetScript("OnUpdate", function(_, el)
		-- every frame (at most 60 a second), so the way stays glued to you as you run and turn
		t = t + el
		if t < 0.016 then return end
		t = 0
		-- a problem (in /jt status): try again in a second, never stop for good
		if not ns.Safe("minimap", Update) then t = -1 end
	end)
end
ns.MinimapUpdate = function() if frame then Update() end end
