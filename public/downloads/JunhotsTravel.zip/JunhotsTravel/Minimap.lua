-- Your walking way on the minimap: a thin gold line (dark soft edge) along the path to your next stops.
local _, ns = ...
local P = ns.Planner
local S = ns.state
local canaccess = canaccessvalue or function() return true end
local sin, cos, sqrt, floor = math.sin, math.cos, math.sqrt, math.floor

-- minimap width in yards for each zoom level (the game's own sizes)
local SIZE = {
	outdoor = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 },
	indoor = { [0] = 300, 240, 180, 120, 80, 50 },
}
local MAXSEGS = 120
local GAP = 9          -- the line starts this many pixels from you (clear of your arrow)
local EDGE = 4         -- and stops this far inside the minimap's edge
local GOLD = { 1, 0.84, 0.36, 0.95 }
local CASE = { 0.05, 0.035, 0.01, 0.55 }

local frame, lines, used = nil, {}, 0

-- one piece of line (media/soft.tga: soft edges)
local function Seg(ax, ay, bx, by, col, th, sub)
	used = used + 1
	local l = lines[used]
	if not l then
		l = frame:CreateLine(nil, "OVERLAY")
		l:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\aa")
		lines[used] = l
	end
	l:SetDrawLayer("OVERLAY", sub)
	l:SetVertexColor(col[1], col[2], col[3], col[4])
	l:SetThickness(th)
	l:SetStartPoint("CENTER", Minimap, ax, ay)
	l:SetEndPoint("CENTER", Minimap, bx, by)
	l:Show()
end

-- the part of segment a-b that is inside the ring between r0 and r1 (pixels from the centre), or nil
local function Clip(ax, ay, bx, by, r0, r1)
	local dx, dy = bx - ax, by - ay
	local A = dx * dx + dy * dy
	if A < 1e-6 then return nil end
	local t0, t1 = 0, 1
	local B, C1 = 2 * (ax * dx + ay * dy), ax * ax + ay * ay
	-- inside r1
	local D = B * B - 4 * A * (C1 - r1 * r1)
	if D <= 0 then return nil end
	local s = math.sqrt(D)
	t0, t1 = math.max(t0, (-B - s) / (2 * A)), math.min(t1, (-B + s) / (2 * A))
	if t0 >= t1 then return nil end
	-- outside r0 (only the start of the way is near you, so cut the front)
	local D0 = B * B - 4 * A * (C1 - r0 * r0)
	if D0 > 0 then
		local s0 = math.sqrt(D0)
		local e0, e1 = (-B - s0) / (2 * A), (-B + s0) / (2 * A)
		if e0 <= t0 and e1 >= t1 then return nil end
		if e0 <= t0 and e1 > t0 then t0 = e1 end
		if e1 >= t1 and e0 < t1 then t1 = e0 end
	end
	if t0 >= t1 then return nil end
	return ax + dx * t0, ay + dy * t0, ax + dx * t1, ay + dy * t1
end

-- indoors? The game keeps a separate zoom for each; the one the minimap uses now tells which.
local function Indoors()
	local zoom = Minimap:GetZoom()
	local out = tonumber(GetCVar and GetCVar("minimapZoom") or "") or 0
	local ins = tonumber(GetCVar and GetCVar("minimapInsideZoom") or "") or 0
	if out ~= ins then return ins == zoom end
	return IsIndoors and IsIndoors() or false
end

-- the spots your walk goes through on this continent, starting where you stand
local function WalkSpots(here)
	local plan = S.plan
	if not plan then return nil end
	local pts = { here }
	for i, l in ipairs(plan.legs) do
		if l.k ~= "walk" then break end
		for j = (i == 1 and l.at or 2), #(l.path or {}) do
			local q = l.path[j]
			if q.map ~= here.map then break end
			local prev = pts[#pts]
			local r = P.Round(prev, q)
			if r then pts[#pts + 1] = r end
			pts[#pts + 1] = q
		end
	end
	if #pts < 3 or not ns.SmoothLine then return pts end
	local xy = {}
	for k, q in ipairs(pts) do xy[k] = { q[1] or q.x, q[2] or q.y } end
	local out = {}
	for k, q in ipairs(ns.SmoothLine(xy)) do out[k] = { x = q[1], y = q[2] } end
	return out
end

local function Update()
	used = 0
	local here = S.goal and not S.arrived and ns.Here()
	local pts = here and not UnitOnTaxi("player") and WalkSpots(here)
	if pts and #pts > 1 then
		local w, h = Minimap:GetWidth(), Minimap:GetHeight()
		local size = SIZE[Indoors() and "indoor" or "outdoor"][Minimap:GetZoom()] or 400
		local px = w / size
		local rot = GetCVar and GetCVar("rotateMinimap") == "1"
		local f = rot and GetPlayerFacing and GetPlayerFacing()
		if f and not canaccess(f) then f = nil end
		local cf, sf = f and cos(f) or 1, f and sin(f) or 0
		local R = w / 2 - EDGE
		local xy = {}
		for i, q in ipairs(pts) do
			local north, east = q.x - here.x, -(q.y - here.y)   -- world x grows north, y grows west
			if f then east, north = east * cf + north * sf, -east * sf + north * cf end
			xy[i] = { east * px, north * px * (h / w) }
		end
		local segs = {}
		for i = 2, #xy do
			local ax, ay, bx, by = Clip(xy[i - 1][1], xy[i - 1][2], xy[i][1], xy[i][2], GAP, R)
			if ax then segs[#segs + 1] = { ax, ay, bx, by } end
			if #segs >= MAXSEGS then break end
		end
		-- dark soft edge under, gold line on top
		-- (media/aa fades its outer thirds: drawn about 1.8x as wide as it looks, for smooth edges)
		for _, g in ipairs(segs) do Seg(g[1], g[2], g[3], g[4], CASE, 8.5, 6) end
		for _, g in ipairs(segs) do Seg(g[1], g[2], g[3], g[4], GOLD, 4, 7) end
	end
	for i = used + 1, #lines do lines[i]:Hide() end
end

function ns.MinimapInit()
	if frame or not Minimap then return end
	frame = CreateFrame("Frame", nil, Minimap)
	frame:SetAllPoints(Minimap)
	frame:SetFrameLevel(Minimap:GetFrameLevel() + 5)
	local t = 0
	frame:SetScript("OnUpdate", function(_, el)
		t = t + el
		if t < 0.1 then return end
		t = 0
		if not ns.Safe("minimap", Update) then frame:SetScript("OnUpdate", nil) end
	end)
end
ns.MinimapUpdate = function() if frame then Update() end end
