-- Your walking way on the minimap: gold dots along the path to your next stops (like breadcrumbs).
local _, ns = ...
local P = ns.Planner
local S = ns.state
local canaccess = canaccessvalue or function() return true end
local sin, cos, sqrt, floor = math.sin, math.cos, math.sqrt, math.floor

-- minimap width in yards for each zoom level (the game's own sizes)
local SIZE = {
	outdoor = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 },
	indoor = { [0] = 300, 240, 180, 120, 80, 50 },
}
local DOTS = 22        -- about this many dots across the minimap
local MAXDOTS = 80

local frame, dots, used = nil, {}, 0

local function Dot()
	used = used + 1
	local t = dots[used]
	if not t then
		t = frame:CreateTexture(nil, "OVERLAY")
		t:SetTexture("Interface\\COMMON\\Indicator-Gray")
		t:SetVertexColor(1, 0.82, 0.2, 1)
		t:SetSize(7, 7)
		dots[used] = t
	end
	return t
end

-- indoors? The game keeps a separate zoom for each; the one the minimap uses now tells which.
local function Indoors()
	local zoom = Minimap:GetZoom()
	local out = tonumber(GetCVar and GetCVar("minimapZoom") or "") or 0
	local ins = tonumber(GetCVar and GetCVar("minimapInsideZoom") or "") or 0
	if out ~= ins then return ins == zoom end
	return IsIndoors and IsIndoors() or false
end

-- the spots your walk goes through on this continent, starting where you stand
local function WalkSpots(here)
	local plan = S.plan
	if not plan then return nil end
	local pts = { here }
	for i, l in ipairs(plan.legs) do
		if l.k ~= "walk" then break end
		for j = (i == 1 and l.at or 2), #(l.path or {}) do
			local q = l.path[j]
			if q.map ~= here.map then break end
			local prev = pts[#pts]
			local r = P.Round(prev, q)
			if r then pts[#pts + 1] = r end
			pts[#pts + 1] = q
		end
	end
	return pts
end

local function Update()
	used = 0
	local here = S.goal and not S.arrived and ns.Here()
	local pts = here and not UnitOnTaxi("player") and WalkSpots(here)
	if pts and #pts > 1 then
		local w, h = Minimap:GetWidth(), Minimap:GetHeight()
		local size = SIZE[Indoors() and "indoor" or "outdoor"][Minimap:GetZoom()] or 400
		local radius = size / 2
		local px = w / size
		local rot = GetCVar and GetCVar("rotateMinimap") == "1"
		local f = rot and GetPlayerFacing and GetPlayerFacing()
		if f and not canaccess(f) then f = nil end
		local cf, sf = f and cos(f) or 1, f and sin(f) or 0
		local step = size / DOTS
		local carry = step / 2 -- first dot half a step from you
		for i = 2, #pts do
			local a, b = pts[i - 1], pts[i]
			local dx, dy = b.x - a.x, b.y - a.y
			local len = sqrt(dx * dx + dy * dy)
			local d = carry
			while d < len and used < MAXDOTS do
				local x, y = a.x + dx * d / len, a.y + dy * d / len
				local north, east = x - here.x, -(y - here.y)   -- world x grows north, y grows west
				if f then east, north = east * cf + north * sf, -east * sf + north * cf end
				if east * east + north * north < (radius - 6 / px) ^ 2 then
					local t = Dot()
					t:ClearAllPoints()
					t:SetPoint("CENTER", Minimap, "CENTER", east * px, north * px * (h / w))
					t:Show()
				end
				d = d + step
			end
			carry = d - len
			if used >= MAXDOTS then break end
		end
	end
	for i = used + 1, #dots do dots[i]:Hide() end
end

function ns.MinimapInit()
	if frame or not Minimap then return end
	frame = CreateFrame("Frame", nil, Minimap)
	frame:SetAllPoints(Minimap)
	frame:SetFrameLevel(Minimap:GetFrameLevel() + 5)
	local t = 0
	frame:SetScript("OnUpdate", function(_, el)
		t = t + el
		if t < 0.1 then return end
		t = 0
		Update()
	end)
end
ns.MinimapUpdate = function() if frame then Update() end end
