-- Your walking way on the minimap: small spaced gold dots (or a thin line) along the path to your next stops.
local _, ns = ...
local P = ns.Planner
local S = ns.state
local canaccess = canaccessvalue or function() return true end
local sin, cos, sqrt, floor = math.sin, math.cos, math.sqrt, math.floor

-- minimap width in yards for each zoom level (the game's own sizes)
local SIZE = {
	outdoor = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 },
	indoor = { [0] = 300, 240, 180, 120, 80, 50 },
}
local MAXSEGS = 120
local GAP = 9          -- the line starts this many pixels from you (clear of your arrow)
local EDGE = 2         -- and stops this far inside the minimap's edge

-- square minimaps (set by minimap addons through GetMinimapShape) let the way run into the corners
local function Square()
	return GetMinimapShape and GetMinimapShape() == "SQUARE"
end
local GOLD = { 1, 0.84, 0.36, 0.95 }
local CASE = { 0.05, 0.035, 0.01, 0.55 }

local frame, lines, used = nil, {}, 0
local dots, dused = {}, 0
local DOTSTEP, DOTSIZE = 9, 5
local DOTCOL = { 1, 0.85, 0.2, 1 }
local function Dot(x, y)
	dused = dused + 1
	local t = dots[dused]
	if not t then
		t = ns.NoSnap(frame:CreateTexture(nil, "OVERLAY", nil, 7))
		t:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\dot")
		t:SetSize(DOTSIZE, DOTSIZE)
		t:SetVertexColor(DOTCOL[1], DOTCOL[2], DOTCOL[3], DOTCOL[4])
		dots[dused] = t
	end
	t:ClearAllPoints()
	t:SetPoint("CENTER", Minimap, "CENTER", x, y)
	t:Show()
end

-- one piece of line (media/soft.tga: soft edges)
local function Seg(ax, ay, bx, by, col, th, sub)
	used = used + 1
	local l = lines[used]
	if not l then
		l = ns.NoSnap(frame:CreateLine(nil, "OVERLAY"))
		l:SetTexture("Interface\\AddOns\\JunhotsTravel\\media\\aa")
		lines[used] = l
	end
	l:SetDrawLayer("OVERLAY", sub)
	l:SetVertexColor(col[1], col[2], col[3], col[4])
	l:SetThickness(th)
	l:SetStartPoint("CENTER", Minimap, ax, ay)
	l:SetEndPoint("CENTER", Minimap, bx, by)
	l:Show()
end

-- the part of segment a-b that is outside r0 (pixels from the centre) and inside the minimap
-- (a circle of radius r1, or a square of half-width r1), or nil
local function Clip(ax, ay, bx, by, r0, r1, sq)
	local dx, dy = bx - ax, by - ay
	local A = dx * dx + dy * dy
	if A < 1e-6 then return nil end
	local t0, t1 = 0, 1
	local B, C1 = 2 * (ax * dx + ay * dy), ax * ax + ay * ay
	if sq then
		for _, pq in ipairs({ { -dx, ax + r1 }, { dx, r1 - ax }, { -dy, ay + r1 }, { dy, r1 - ay } }) do
			local p, q = pq[1], pq[2]
			if p == 0 then
				if q < 0 then return nil end
			else
				local r = q / p
				if p < 0 then t0 = math.max(t0, r) else t1 = math.min(t1, r) end
			end
		end
	else
		local D = B * B - 4 * A * (C1 - r1 * r1)
		if D <= 0 then return nil end
		local s = math.sqrt(D)
		t0, t1 = math.max(t0, (-B - s) / (2 * A)), math.min(t1, (-B + s) / (2 * A))
	end
	if t0 >= t1 then return nil end
	-- outside r0 (only the start of the way is near you, so cut the front)
	local D0 = B * B - 4 * A * (C1 - r0 * r0)
	if D0 > 0 then
		local s0 = math.sqrt(D0)
		local e0, e1 = (-B - s0) / (2 * A), (-B + s0) / (2 * A)
		if e0 <= t0 and e1 >= t1 then return nil end
		if e0 <= t0 and e1 > t0 then t0 = e1 end
		if e1 >= t1 and e0 < t1 then t1 = e0 end
	end
	if t0 >= t1 then return nil end
	return ax + dx * t0, ay + dy * t0, ax + dx * t1, ay + dy * t1
end

-- indoors? The game keeps a separate zoom for each; the one the minimap uses now tells which.
local function Indoors()
	local zoom = Minimap:GetZoom()
	local out = tonumber(GetCVar and GetCVar("minimapZoom") or "") or 0
	local ins = tonumber(GetCVar and GetCVar("minimapInsideZoom") or "") or 0
	if out ~= ins then return ins == zoom end
	return IsIndoors and IsIndoors() or false
end

-- the spots your walk goes through on this continent, starting where you stand
local function WalkSpots(here)
	local plan = S.plan
	if not plan then return nil end
	local pts = { here }
	for i, l in ipairs(plan.legs) do
		if l.k ~= "walk" then break end
		for j = (i == 1 and l.at or 2), #(l.path or {}) do
			local q = l.path[j]
			if q.map ~= here.map then break end
			local prev = pts[#pts]
			-- from you to your next spot: round walls and buildings first
			local way = i == 1 and j == l.at and ns.LocalWay and ns.LocalWay(here, q)
			if way then
				for k = 1, #way - 1 do pts[#pts + 1] = way[k] end
			else
				local r = P.Round(prev, q)
				if r then pts[#pts + 1] = r end
			end
			pts[#pts + 1] = q
		end
	end
	if #pts < 3 or not ns.SmoothLine then return pts end
	local xy = {}
	for k, q in ipairs(pts) do xy[k] = { q[1] or q.x, q[2] or q.y } end
	local out = {}
	for k, q in ipairs(ns.SmoothLine(xy)) do out[k] = { x = q[1], y = q[2] } end
	return out
end

local function Update()
	used, dused = 0, 0
	local here = S.goal and not S.arrived and ns.Here()
	local pts = here and not UnitOnTaxi("player") and WalkSpots(here)
	if pts and #pts > 1 then
		local w, h = Minimap:GetWidth(), Minimap:GetHeight()
		local size = SIZE[Indoors() and "indoor" or "outdoor"][Minimap:GetZoom()] or 400
		local px = w / size
		local rot = GetCVar and GetCVar("rotateMinimap") == "1"
		local f = rot and GetPlayerFacing and GetPlayerFacing()
		if f and not canaccess(f) then f = nil end
		local cf, sf = f and cos(f) or 1, f and sin(f) or 0
		local R = w / 2 - EDGE
		local sq = Square()
		local xy = {}
		for i, q in ipairs(pts) do
			local north, east = q.x - here.x, -(q.y - here.y)   -- world x grows north, y grows west
			if f then east, north = east * cf + north * sf, -east * sf + north * cf end
			xy[i] = { east * px, north * px * (h / w) }
		end
		local segs = {}
		for i = 2, #xy do
			local ax, ay, bx, by = Clip(xy[i - 1][1], xy[i - 1][2], xy[i][1], xy[i][2], GAP, R, sq)
			if ax then segs[#segs + 1] = { ax, ay, bx, by } end
			if #segs >= MAXSEGS then break end
		end
		if ns.TrailStyle() == "line" then
			-- dark soft edge under, gold line on top
			-- (media/aa fades its outer thirds: drawn about 1.8x as wide as it looks, for smooth edges)
			for _, g in ipairs(segs) do Seg(g[1], g[2], g[3], g[4], CASE, 8.5, 6) end
			for _, g in ipairs(segs) do Seg(g[1], g[2], g[3], g[4], GOLD, 4, 7) end
		else
			-- small dots 9 px apart, from just outside your arrow to just inside the edge
			ns.Along(xy, DOTSTEP, GAP, function(x, y)
				local r2 = x * x + y * y
				if r2 < GAP * GAP * 0.8 then return end
				if sq then
					if math.abs(x) > R or math.abs(y) > R then return end
				elseif r2 > R * R then return end
				Dot(x, y)
			end, 120)
		end
	end
	for i = used + 1, #lines do lines[i]:Hide() end
	for i = dused + 1, #dots do dots[i]:Hide() end
end

function ns.MinimapInit()
	if frame or not Minimap then return end
	frame = CreateFrame("Frame", nil, Minimap)
	frame:SetAllPoints(Minimap)
	frame:SetFrameLevel(Minimap:GetFrameLevel() + 5)
	local t = 0
	frame:SetScript("OnUpdate", function(_, el)
		-- every frame (at most 60 a second), so the way stays glued to you as you run and turn
		t = t + el
		if t < 0.016 then return end
		t = 0
		if not ns.Safe("minimap", Update) then frame:SetScript("OnUpdate", nil) end
	end)
end
ns.MinimapUpdate = function() if frame then Update() end end
