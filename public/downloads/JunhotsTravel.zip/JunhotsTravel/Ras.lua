-- Fine walking detail: where you can step between 4-yard squares (from the game's terrain, buildings, rocks and walls;
-- data in Ras_0.lua / Ras_1.lua). Used to check that a straight run is really clear, and to find the way round a wall
-- (out through a town gate, round a building) near you.
local _, ns = ...
local floor, sqrt, abs, max, min = math.floor, math.sqrt, math.abs, math.max, math.min
local byte = string.byte
local R = {}
ns.Ras = R
R.data = R.data or {}   -- [map] = { cell = 4, x0 = first row, y0 = first column, rows = { "runs", ... } }

-- Each square has two bits: 1 = you can walk to the square north of it, 2 = to the square west of it (from real steps
-- in the game's terrain, so walls, cliffs and buildings cut them). A row is runs of the same value; a run is base-32
-- digits "W".."_" (high part of its length) then one digit "0".."V" = value * 8 + the low 3 bits of the length.
-- Past a row's end, and where there is no data: open both ways.
local DIG = {}
do
	local s = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_"
	for i = 1, #s do DIG[byte(s, i)] = i - 1 end
end
local cache, cached, CACHEMAX = {}, 0, 3000
-- R.indoor (set while you are indoors): inside buildings use their own rows (d.inrows: the floor you are on, not the
-- roof or the land above)
R.indoor = false
local function Row(d, map, i)
	local ins = R.indoor and d.inrows and d.inrows[i - d.x0 + 1]
	local key = map * 100000 + i + (ins and 50000000 or 0)
	local r = cache[key]
	if r then return r end
	local s = ins or d.rows[i - d.x0 + 1]
	if not s then return nil end
	local ends, vals = {}, {}
	local n, at = 0, 0
	for k = 1, #s do
		local v = DIG[byte(s, k)]
		if v >= 32 then n = n * 32 + (v - 32)
		else
			at = at + n * 8 + v % 8
			ends[#ends + 1], vals[#vals + 1] = at, floor(v / 8)
			n = 0
		end
	end
	r = { ends, vals }
	if cached >= CACHEMAX then cache, cached = {}, 0 end
	cache[key], cached = r, cached + 1
	return r
end

local function Bits(d, map, i, j)
	local r = Row(d, map, i)
	if not r then return 3 end
	local ends = r[1]
	local c = j - d.y0
	if c < 0 or c >= (ends[#ends] or 0) then return 3 end
	local lo, hi = 1, #ends
	while lo < hi do
		local m = floor((lo + hi) / 2)
		if ends[m] > c then hi = m else lo = m + 1 end
	end
	return r[2][lo]
end

-- can you step from square (i, j) to the next square (di, dj each -1, 0 or 1)?
local function Step(d, map, i, j, di, dj)
	if di ~= 0 and dj ~= 0 then
		-- a corner: round either side
		return (Step(d, map, i, j, di, 0) and Step(d, map, i + di, j, 0, dj))
			or (Step(d, map, i, j, 0, dj) and Step(d, map, i, j + dj, di, 0))
	end
	if di == 1 then return Bits(d, map, i, j) % 2 == 1 end
	if di == -1 then return Bits(d, map, i - 1, j) % 2 == 1 end
	if dj == 1 then return Bits(d, map, i, j) >= 2 end
	return Bits(d, map, i, j - 1) >= 2
end

function R.Has(map) return R.data[map] ~= nil end
-- inside-building detail near (x, y): rows of their own within 12 yd
function R.HasIndoor(map, x)
	local d = R.data[map]
	if not (d and d.inrows) then return false end
	local i = floor(x / d.cell) - d.x0 + 1
	for k = i - 3, i + 3 do if d.inrows[k] then return true end end
	return false
end

-- can you run straight from a to b? (squares within `skip` yards of either end don't count: you stand there)
function R.Clear(map, ax, ay, bx, by, skip)
	local d = R.data[map]
	if not d then return true end
	skip = skip or 2
	local dx, dy = bx - ax, by - ay
	local len = sqrt(dx * dx + dy * dy)
	if len < 1 then return true end
	local c = d.cell
	local n = floor(len / 2) + 1   -- every 2 yards: at most one square on in each direction
	local li, lj = floor(ax / c), floor(ay / c)
	for k = 1, n do
		local t = k / n
		local i, j = floor((ax + dx * t) / c), floor((ay + dy * t) / c)
		if i ~= li or j ~= lj then
			local s = t * len
			if s >= skip and len - s >= skip then
				local di, dj = i - li, j - lj
				if abs(di) > 1 or abs(dj) > 1 or not Step(d, map, li, lj, di, dj) then return false end
			end
			li, lj = i, j
		end
	end
	return true
end

-- a square near (x, y) (within r yards) you can walk out of: its i, j
local function NearOpen(d, map, x, y, r)
	local c = d.cell
	local i0, j0 = floor(x / c), floor(y / c)
	local function out(i, j) return Bits(d, map, i, j) > 0 or Bits(d, map, i - 1, j) % 2 == 1 or Bits(d, map, i, j - 1) >= 2 end
	if out(i0, j0) then return i0, j0 end
	for s = 1, floor(r / c) do
		local best, bi, bj = nil, nil, nil
		for di = -s, s do
			for dj = -s, s do
				if (abs(di) == s or abs(dj) == s) and out(i0 + di, j0 + dj) then
					local e = di * di + dj * dj
					if not best or e < best then best, bi, bj = e, i0 + di, j0 + dj end
				end
			end
		end
		if best then return bi, bj end
	end
	return nil
end

-- binary heap on f
local function hpush(h, f, v)
	local n = #h + 1
	h[n] = { f, v }
	while n > 1 do
		local p = floor(n / 2)
		if h[p][1] <= h[n][1] then break end
		h[p], h[n] = h[n], h[p]
		n = p
	end
end
local function hpop(h)
	local top = h[1]
	local last = table.remove(h)
	if #h > 0 then
		h[1] = last
		local n = 1
		while true do
			local l, r, m = 2 * n, 2 * n + 1, n
			if h[l] and h[l][1] < h[m][1] then m = l end
			if h[r] and h[r][1] < h[m][1] then m = r end
			if m == n then break end
			h[m], h[n] = h[n], h[m]
			n = m
		end
	end
	return top
end

local SQ2 = sqrt(2)
-- The walking way from a to b through open squares (inside a box round them, `margin` yards bigger), as a few
-- corner spots { x, y } ending at b; nil if there is none in the box or it is too big to look at.
function R.Way(map, ax, ay, bx, by, margin)
	local d = R.data[map]
	if not d then return nil end
	local c = d.cell
	margin = margin or 120
	local si, sj = NearOpen(d, map, ax, ay, 16)
	local ti, tj = NearOpen(d, map, bx, by, 16)
	if not (si and ti) then return nil end
	local i0, i1 = min(si, ti) - floor(margin / c), max(si, ti) + floor(margin / c)
	local j0, j1 = min(sj, tj) - floor(margin / c), max(sj, tj) + floor(margin / c)
	local W = j1 - j0 + 1
	if (i1 - i0 + 1) * W > 90000 then return nil end
	local g, from, done = {}, {}, {}
	local function id(i, j) return (i - i0) * W + (j - j0) end
	local function hdist(i, j)
		local di, dj = abs(i - ti), abs(j - tj)
		return (di + dj) + (SQ2 - 2) * min(di, dj)
	end
	local s, t = id(si, sj), id(ti, tj)
	g[s] = 0
	local h = {}
	hpush(h, hdist(si, sj), s)
	local found, n = false, 0
	while #h > 0 do
		local top = hpop(h)
		local u = top[2]
		if not done[u] then
			done[u] = true
			n = n + 1
			if u == t then found = true; break end
			if n > 40000 then break end
			local ui, uj = floor(u / W) + i0, u % W + j0
			local gu = g[u]
			for di = -1, 1 do
				for dj = -1, 1 do
					if di ~= 0 or dj ~= 0 then
						local vi, vj = ui + di, uj + dj
						if vi >= i0 and vi <= i1 and vj >= j0 and vj <= j1 and Step(d, map, ui, uj, di, dj) then
							local v = id(vi, vj)
							local ng = gu + ((di == 0 or dj == 0) and 1 or SQ2)
							if not done[v] and (not g[v] or ng < g[v]) then
								g[v], from[v] = ng, u
								hpush(h, ng + hdist(vi, vj), v)
							end
						end
					end
				end
			end
		end
	end
	if not found then return nil end
	-- squares back to the start, then keep only the corners you must go round
	local cells = {}
	local u = t
	while u do
		cells[#cells + 1] = { (floor(u / W) + i0 + 0.5) * c, (u % W + j0 + 0.5) * c }
		u = from[u]
	end
	local pts = { { ax, ay } }
	for k = #cells - 1, 1, -1 do pts[#pts + 1] = cells[k] end
	pts[#pts] = { bx, by }
	local out, i = {}, 1
	while i < #pts do
		local j = i + 1
		for k = #pts, i + 2, -1 do
			if R.Clear(map, pts[i][1], pts[i][2], pts[k][1], pts[k][2], i == 1 and 2 or 0) then j = k; break end
		end
		out[#out + 1] = { x = pts[j][1], y = pts[j][2], map = map }
		i = j
	end
	return out, g[t] * c
end
