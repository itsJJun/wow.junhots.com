-- Fine walking detail: where you can step between 4-yard squares (from the game's terrain, buildings, rocks and walls;
-- data in Ras_0.lua / Ras_1.lua). Used to check that a straight run is really clear, and to find the way round a wall
-- (out through a town gate, round a building) near you.
local _, ns = ...
local floor, sqrt, abs, max, min = math.floor, math.sqrt, math.abs, math.max, math.min
local byte = string.byte
local R = {}
ns.Ras = R
R.data = R.data or {}   -- [map] = { cell = 4, x0 = first row, y0 = first column, rows = { "runs", ... } }

-- Each square has two bits: 1 = you can walk to the square north of it, 2 = to the square west of it (from real steps
-- in the game's terrain, so walls, cliffs and buildings cut them). A row is runs of the same value; a run is base-32
-- digits "W".."_" (high part of its length) then one digit "0".."V" = value * 8 + the low 3 bits of the length.
-- Past a row's end, and where there is no data: open both ways.
local DIG = {}
do
	local s = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_"
	for i = 1, #s do DIG[byte(s, i)] = i - 1 end
end
local cache, cached, CACHEMAX = {}, 0, 3000
-- R.indoor (set while you are indoors): inside buildings use their own rows (d.inrows: the floor you are on, not the
-- roof or the land above)
R.indoor = false
local function Row(d, map, i)
	local ins = R.indoor and d.inrows and d.inrows[i - d.x0 + 1]
	local key = map * 100000 + i + (ins and 50000000 or 0)
	local r = cache[key]
	if r then return r end
	local s = ins or d.rows[i - d.x0 + 1]
	if not s then return nil end
	local ends, vals = {}, {}
	local n, at = 0, 0
	for k = 1, #s do
		local v = DIG[byte(s, k)]
		if v >= 32 then n = n * 32 + (v - 32)
		else
			at = at + n * 8 + v % 8
			ends[#ends + 1], vals[#vals + 1] = at, floor(v / 8)
			n = 0
		end
	end
	r = { ends, vals }
	if cached >= CACHEMAX then cache, cached = {}, 0 end
	cache[key], cached = r, cached + 1
	return r
end

local function Bits(d, map, i, j)
	local r = Row(d, map, i)
	if not r then return 3 end
	local ends = r[1]
	local c = j - d.y0
	if c < 0 or c >= (ends[#ends] or 0) then return 3 end
	local lo, hi = 1, #ends
	while lo < hi do
		local m = floor((lo + hi) / 2)
		if ends[m] > c then hi = m else lo = m + 1 end
	end
	return r[2][lo]
end

-- Deep water (Water_<map>.lua: you would swim; piers, decks and bridges over it are not water). R.dry (on unless the
-- step of your way swims): a step from dry land into deep water is shut, so the arrow keeps to piers and bridges and
-- never sends you for a swim the way doesn't plan. Out of the water (you fell in, or stand on its very edge) the way
-- starts on the nearest dry square: a step out of the water is always open.
R.water = R.water or {}
R.dry = true
local wrows, wrowsN = {}, 0
local function WetRow(map, i)
	local W = R.water[map]
	local s = W and W[i]
	if not s then return nil end
	local key = map * 1000000 + i
	local r = wrows[key]
	if r then return r end
	local st, en = {}, {}
	for a, n in s:gmatch("(-?%d+),(%d+)") do
		a = tonumber(a)
		st[#st + 1], en[#en + 1] = a, a + tonumber(n) - 1
	end
	r = { st, en }
	if wrowsN >= 2000 then wrows, wrowsN = {}, 0 end
	wrows[key], wrowsN = r, wrowsN + 1
	return r
end
local function Wet(map, i, j)
	local r = WetRow(map, i)
	if not r then return false end
	local st, en = r[1], r[2]
	local lo, hi = 1, #st
	while lo <= hi do
		local m = floor((lo + hi) / 2)
		if j < st[m] then hi = m - 1 elseif j > en[m] then lo = m + 1 else return true end
	end
	return false
end
R.Wet = Wet
function R.WetAt(map, x, y) return Wet(map, floor(x / 4), floor(y / 4)) end

-- Steep ground (Steep_<map>.lua: the land's own slope over 35 degrees, still walkable): you can run up it, but a way
-- round over flatter ground is better (the game's paths go round hills too). A straight run may cross a little of it
-- (STEEPMAX yards: a bank, a bump); a way round costs it 3 times. R.flat = false: ignore it.
R.steep = R.steep or {}
R.flat = true
local STEEPMAX = 10
local srows, srowsN = {}, 0
local function Steep(map, i, j)
	local T = R.steep[map]
	local s = T and T[i]
	if not s then return false end
	local key = map * 1000000 + i
	local r = srows[key]
	if not r then
		local st, en = {}, {}
		for a, n in s:gmatch("(-?%d+),(%d+)") do
			a = tonumber(a)
			st[#st + 1], en[#en + 1] = a, a + tonumber(n) - 1
		end
		r = { st, en }
		if srowsN >= 2000 then srows, srowsN = {}, 0 end
		srows[key], srowsN = r, srowsN + 1
	end
	local st, en = r[1], r[2]
	local lo, hi = 1, #st
	while lo <= hi do
		local m = floor((lo + hi) / 2)
		if j < st[m] then hi = m - 1 elseif j > en[m] then lo = m + 1 else return true end
	end
	return false
end
R.Steep = Steep
function R.SteepAt(map, x, y) return Steep(map, floor(x / 4), floor(y / 4)) end

-- Piers, docks and bridges over deep water (Deck_<map>.lua): the fine map only knows the sea floor under them, so the
-- arrow walks them by their own deck heights: deck to deck within a step (3 yd up or down), deck to land only where
-- the land there is a step from the deck (the way on and off); never through a wall on the deck (houses, railings).
-- (Swimming, under it: as the fine map.)
R.deck = R.deck or {}
local drows, drowsN = {}, 0
local function DeckRow(map, i)
	local D = R.deck[map]
	local s = D and D[i]
	if not s then return nil end
	local key = map * 1000000 + i
	local r = drows[key]
	if r then return r end
	r = {}
	for j, zs, m in s:gmatch("(-?%d+):([^:]*):(%d+)") do
		local q = { m = tonumber(m) }
		for z in zs:gmatch("[^/]+") do q[#q + 1] = tonumber(z) end
		r[tonumber(j)] = q
	end
	if drowsN >= 2000 then drows, drowsN = {}, 0 end
	drows[key], drowsN = r, drowsN + 1
	return r
end
local function Deck(map, i, j) local r = DeckRow(map, i) return r and r[j] end
R.Deck = Deck
local function Linked(q, di, dj)
	local b = (di + 1) * 3 + (dj + 1)
	if b > 4 then b = b - 1 end
	return floor(q.m / 2 ^ b) % 2 == 1
end
-- no wall on that side of a deck square (bits 8-11: di, dj = -1,0 / 1,0 / 0,-1 / 0,1)
local function Open(q, di, dj)
	local b = di == -1 and 8 or di == 1 and 9 or dj == -1 and 10 or 11
	return floor(q.m / 2 ^ b) % 2 == 1
end
local function Near(a, b)
	for x = 1, #a do for y = 1, #b do if abs(a[x] - b[y]) <= 3 then return true end end end
	return false
end

-- can you step from square (i, j) to the next square (di, dj each -1, 0 or 1)?
local Step0
local function Step(d, map, i, j, di, dj)
	if R.deck[map] and (di == 0 or dj == 0) then
		local a, b = Deck(map, i, j), Deck(map, i + di, j + dj)
		if a or b then
			if a and b then return Near(a, b) and Open(a, di, dj) and Open(b, -di, -dj) end
			if (a and Linked(a, di, dj) and Open(a, di, dj)) or (b and Linked(b, -di, -dj) and Open(b, -di, -dj)) then return true end
			if R.dry then return false end
		end
	end
	-- (in the water, only a step onto dry land: the way out, never a swim along)
	if R.dry and R.water[map] and Wet(map, i + di, j + dj) then return false end
	return Step0(d, map, i, j, di, dj)
end
function Step0(d, map, i, j, di, dj)
	if di ~= 0 and dj ~= 0 then
		-- a corner: round either side
		return (Step(d, map, i, j, di, 0) and Step(d, map, i + di, j, 0, dj))
			or (Step(d, map, i, j, 0, dj) and Step(d, map, i, j + dj, di, 0))
	end
	if di == 1 then return Bits(d, map, i, j) % 2 == 1 end
	if di == -1 then return Bits(d, map, i - 1, j) % 2 == 1 end
	if dj == 1 then return Bits(d, map, i, j) >= 2 end
	return Bits(d, map, i, j - 1) >= 2
end

function R.Has(map) return R.data[map] ~= nil end
-- inside-building detail near (x, y): rows of their own within 12 yd
function R.HasIndoor(map, x)
	local d = R.data[map]
	if not (d and d.inrows) then return false end
	local i = floor(x / d.cell) - d.x0 + 1
	for k = i - 3, i + 3 do if d.inrows[k] then return true end end
	return false
end

-- can you run straight from a to b? (squares within `skip` yards of either end don't count: you stand there)
function R.Clear(map, ax, ay, bx, by, skip)
	local d = R.data[map]
	if not d then return true end
	skip = skip or 2
	local dx, dy = bx - ax, by - ay
	local len = sqrt(dx * dx + dy * dy)
	if len < 1 then return true end
	local c = d.cell
	local n = floor(len / 2) + 1   -- every 2 yards: at most one square on in each direction
	local li, lj = floor(ax / c), floor(ay / c)
	local steep = R.flat and not R.indoor and R.steep[map] and 0
	for k = 1, n do
		local t = k / n
		local i, j = floor((ax + dx * t) / c), floor((ay + dy * t) / c)
		if i ~= li or j ~= lj then
			local s = t * len
			if s >= skip and len - s >= skip then
				local di, dj = i - li, j - lj
				if abs(di) > 1 or abs(dj) > 1 or not Step(d, map, li, lj, di, dj) then return false end
				if steep and Steep(map, i, j) then
					steep = steep + c
					if steep > STEEPMAX then return false end
				end
			end
			li, lj = i, j
		end
	end
	return true
end

-- a square near (x, y) (within r yards) you can walk out of: its i, j
local function NearOpen(d, map, x, y, r)
	local c = d.cell
	local i0, j0 = floor(x / c), floor(y / c)
	-- (not deep water the way doesn't swim: a dock's spot at the deck's edge, over the water)
	local wet = R.dry and R.water[map]
	local function out(i, j)
		if wet and Wet(map, i, j) then return false end
		return Bits(d, map, i, j) > 0 or Bits(d, map, i - 1, j) % 2 == 1 or Bits(d, map, i, j - 1) >= 2
	end
	if out(i0, j0) then return i0, j0 end
	for s = 1, floor(r / c) do
		local best, bi, bj = nil, nil, nil
		for di = -s, s do
			for dj = -s, s do
				if (abs(di) == s or abs(dj) == s) and out(i0 + di, j0 + dj) then
					local e = di * di + dj * dj
					if not best or e < best then best, bi, bj = e, i0 + di, j0 + dj end
				end
			end
		end
		if best then return bi, bj end
	end
	return nil
end

-- binary heap on f
local function hpush(h, f, v)
	local n = #h + 1
	h[n] = { f, v }
	while n > 1 do
		local p = floor(n / 2)
		if h[p][1] <= h[n][1] then break end
		h[p], h[n] = h[n], h[p]
		n = p
	end
end
local function hpop(h)
	local top = h[1]
	local last = table.remove(h)
	if #h > 0 then
		h[1] = last
		local n = 1
		while true do
			local l, r, m = 2 * n, 2 * n + 1, n
			if h[l] and h[l][1] < h[m][1] then m = l end
			if h[r] and h[r][1] < h[m][1] then m = r end
			if m == n then break end
			h[m], h[n] = h[n], h[m]
			n = m
		end
	end
	return top
end

local SQ2 = sqrt(2)
-- hand back to the game when this frame's time is used (ns.Pause); meanwhile others use the outdoor rows
local function Pause()
	local mine, dry = R.indoor, R.dry
	R.indoor, R.dry = false, true
	if ns.Pause then ns.Pause() end
	R.indoor, R.dry = mine, dry
end
-- The walking way from a to b through open squares (inside a box round them, `margin` yards bigger), as a few
-- corner spots { x, y } ending at b; nil if there is none in the box or it is too big to look at.
function R.Way(map, ax, ay, bx, by, margin)
	local d = R.data[map]
	if not d then return nil end
	local c = d.cell
	margin = margin or 120
	local si, sj = NearOpen(d, map, ax, ay, 16)
	local ti, tj = NearOpen(d, map, bx, by, 16)
	if not (si and ti) then return nil end
	local i0, i1 = min(si, ti) - floor(margin / c), max(si, ti) + floor(margin / c)
	local j0, j1 = min(sj, tj) - floor(margin / c), max(sj, tj) + floor(margin / c)
	local W = j1 - j0 + 1
	if (i1 - i0 + 1) * W > 90000 then return nil end
	local g, from, done = {}, {}, {}
	local function id(i, j) return (i - i0) * W + (j - j0) end
	local function hdist(i, j)
		local di, dj = abs(i - ti), abs(j - tj)
		return (di + dj) + (SQ2 - 2) * min(di, dj)
	end
	local s, t = id(si, sj), id(ti, tj)
	local steepW = R.flat and not R.indoor and R.steep[map]
	g[s] = 0
	local h = {}
	hpush(h, hdist(si, sj), s)
	local found, n = false, 0
	while #h > 0 do
		local top = hpop(h)
		local u = top[2]
		if not done[u] then
			done[u] = true
			n = n + 1
			if u == t then found = true; break end
			if n > 40000 then break end
			if n % 32 == 0 then Pause() end
			local ui, uj = floor(u / W) + i0, u % W + j0
			local gu = g[u]
			for di = -1, 1 do
				for dj = -1, 1 do
					if di ~= 0 or dj ~= 0 then
						local vi, vj = ui + di, uj + dj
						if vi >= i0 and vi <= i1 and vj >= j0 and vj <= j1 and Step(d, map, ui, uj, di, dj) then
							local v = id(vi, vj)
							local ng = gu + ((di == 0 or dj == 0) and 1 or SQ2) * (steepW and Steep(map, vi, vj) and 3 or 1)
							if not done[v] and (not g[v] or ng < g[v]) then
								g[v], from[v] = ng, u
								hpush(h, ng + hdist(vi, vj), v)
							end
						end
					end
				end
			end
		end
	end
	-- no way close by (a camp's gate on the far side): look wider once
	if not found then
		if margin < 300 then return R.Way(map, ax, ay, bx, by, 300) end
		return nil
	end
	-- squares back to the start, then keep only the corners you must go round
	local cells = {}
	local u = t
	while u do
		cells[#cells + 1] = { (floor(u / W) + i0 + 0.5) * c, (u % W + j0 + 0.5) * c }
		u = from[u]
	end
	local pts = { { ax, ay } }
	for k = #cells - 1, 1, -1 do pts[#pts + 1] = cells[k] end
	pts[#pts] = { bx, by }
	local out, i = {}, 1
	while i < #pts do
		Pause()
		local j = i + 1
		for k = #pts, i + 2, -1 do
			if R.Clear(map, pts[i][1], pts[i][2], pts[k][1], pts[k][2], i == 1 and 2 or 0) then j = k; break end
		end
		out[#out + 1] = { x = pts[j][1], y = pts[j][2], map = map }
		i = j
	end
	if steepW then
		-- (steep squares cost more while searching: the way's own yards)
		local yd, px, py = 0, ax, ay
		for _, q in ipairs(out) do yd = yd + sqrt((q.x - px) ^ 2 + (q.y - py) ^ 2); px, py = q.x, q.y end
		return out, yd
	end
	return out, g[t] * c
end

-- ---------- floors (inside buildings and caves) ----------
-- The squares above are flat: inside a cave with a level above it, or a house with an upper story, their bits mix
-- the floors. R.lay[map] (Lay_0.lua / Lay_1.lua) has each indoor square's own floors: { z, indoor, n, s, w, e }, where
-- n/s/w/e says which floor of the next square you step onto that way: 0 = none (shut), -1 = a plain square, -2 = the
-- usual (its floor nearest in height, or a plain square), k = its floor k, or a list of them (a slope that meets two).
-- The arrow follows the floor you are on (R.TrackFloor) and checks runs on that floor only.
-- (a row is read once into an index: column -> where its square starts; a square's floors are read when asked for.
-- Both kept in two generations: a full cache starts a new one and keeps the last, so a square still in use is not
-- read again. A big search over a town then reads only the squares it steps on, never whole rows.)
local RI, RI0, RIn = {}, {}, 0
local SQ, SQ0, SQn = {}, {}, 0
local function RowIndex(map, i, s)
	local key = map * 1000000 + i
	local idx = RI[key]
	if idx then return idx end
	idx = RI0[key]
	if not idx then
		idx = {}
		local p, len, col = 1, #s, nil
		while p <= len do
			local g, v = 0, DIG[byte(s, p)]
			while v >= 32 do g = g * 32 + (v - 32); p = p + 1; v = DIG[byte(s, p)] end
			g = g * 32 + v; p = p + 1
			col = col and (col + g + 1) or (g - 65536)
			idx[col] = p
			local n = DIG[byte(s, p)]; p = p + 1
			for _ = 1, n do
				local mask = floor(DIG[byte(s, p + 2)] / 2)
				p = p + 3
				for _ = 3, 6 do
					if mask % 2 == 1 then p = p + (byte(s, p) == 45 and 2 or 1) end
					mask = floor(mask / 2)
				end
			end
		end
	end
	if RIn >= 300 then RI0, RI, RIn = RI, {}, 0 end
	RI[key], RIn = idx, RIn + 1
	return idx
end
local function Floors(map, i, j)
	local L = R.lay and R.lay[map]
	local s = L and L[i]
	if not s then return nil end
	local key = (map * 1000000 + i) * 262144 + j + 131072
	local parts = SQ[key]
	if parts then return parts end
	if parts == false then return nil end
	parts = SQ0[key]
	if parts == nil then
		local p = RowIndex(map, i, s)[j]
		if p then
			local n = DIG[byte(s, p)]; p = p + 1
			parts = {}
			for k = 1, n do
				local code = DIG[byte(s, p + 2)]
				local part = { DIG[byte(s, p)] * 64 + DIG[byte(s, p + 1)] - 2048, code % 2 == 1, -2, -2, -2, -2 }
				p = p + 3
				local mask = floor(code / 2)
				for q = 3, 6 do
					if mask % 2 == 1 then
						local c = byte(s, p)
						if c == 45 then   -- "-": several, then a mask of floors 1-6
							local m, list = DIG[byte(s, p + 1)], {}
							for f = 1, 6 do if m % 2 == 1 then list[#list + 1] = f end; m = floor(m / 2) end
							part[q] = list; p = p + 2
						else part[q] = c == 95 and -1 or DIG[c]; p = p + 1 end
					end
					mask = floor(mask / 2)
				end
				parts[k] = part
			end
		else
			parts = false
		end
	end
	if SQn >= 20000 then SQ0, SQ, SQn = SQ, {}, 0 end
	SQ[key], SQn = parts, SQn + 1
	return parts or nil
end
R.Floors = Floors
-- the heights you can stand at on a square round the floored ones (from the map files' R.lz; nil when not known)
local ZC, ZCn = {}, 0
local function PlainZ(map, i, j)
	local L = R.lz and R.lz[map]
	local s = L and L[i]
	if not s then return nil end
	local key = map * 1000000 + i
	local r = ZC[key]
	if not r then
		r = {}
		local p, len, col = 1, #s, nil
		while p <= len do
			local g, v = 0, DIG[byte(s, p)]
			while v >= 32 do g = g * 32 + (v - 32); p = p + 1; v = DIG[byte(s, p)] end
			g = g * 32 + v; p = p + 1
			col = col and (col + g + 1) or (g - 65536)
			local n, zl = DIG[byte(s, p)], {}
			p = p + 1
			for q = 1, n do zl[q] = DIG[byte(s, p)] * 64 + DIG[byte(s, p + 1)] - 2048; p = p + 2 end
			r[col] = zl
		end
		if ZCn >= 400 then ZC, ZCn = {}, 0 end
		ZC[key], ZCn = r, ZCn + 1
	end
	return r[j]
end
R.PlainZ = PlainZ
-- your height on a plain square: the listed one nearest the height you came at (z), when within a step (you climb
-- at most ~6 yd over 4 yd); else you are on ground the list lacks: keep z
local function PlainAt(map, i, j, z)
	local zl = PlainZ(map, i, j)
	if not zl then return z end
	if not z then return zl[1] end
	local best, bz
	for _, v in ipairs(zl) do local e = abs(v - z); if not best or e < best then best, bz = e, v end end
	return best <= 6 and bz or z
end
local ZH   -- while the tracker steps off a plain square: its height (picks the floor you walk onto)
function R.HasFloors(map) return R.lay ~= nil and R.lay[map] ~= nil end

-- the floor of a square to stand on when you come onto it from a plain square on `side` (or anyhow: side nil): one
-- that matches indoors / outdoors (`inside`, when given), then the one nearest height z, else the lowest
local function Pick(fl, side, z, inside)
	local best, bk
	for k, p in ipairs(fl) do
		if not side or p[side] == -1 or p[side] == -2 then
			local e = ((inside ~= nil and p[2] ~= inside) and 1000 or 0) + (z and abs(p[1] - z) or p[1] * 0.001)
			if not best or e < best then best, bk = e, k end
		end
	end
	return bk
end
local OPP = { 4, 3, 6, 5 }   -- side index (3 n, 4 s, 5 w, 6 e) -> the side you come in from
-- from floor k of square (i, j) (0 = a plain square) one square on (orthogonal): the floors you can be on there are
-- set in `out` (out[k] = true; 0 = a plain square). None = shut.
local function FStepInto(d, map, i, j, k, di, dj, out)
	local side = di == 1 and 3 or di == -1 and 4 or dj == 1 and 5 or 6
	local to = Floors(map, i + di, j + dj)
	local fl = k > 0 and Floors(map, i, j)
	local p = fl and fl[k]
	if p then
		local l = p[side]
		if l == -2 then
			-- the usual: the next square's floor nearest in height, or a plain square
			l = -1
			if to then
				local best
				for q, f in ipairs(to) do local e = abs(f[1] - p[1]); if not best or e < best then best, l = e, q end end
			end
		end
		if type(l) == "table" then
			for _, q in ipairs(l) do if to and to[q] then out[q] = true end end
			if not to then out[0] = true end
			return
		end
		if l == 0 then return end
		if l > 0 then out[(to and to[l]) and l or 0] = true; return end
		-- onto a plain square (or a block edge where the next square has floors: come in from this side, same height)
		if to then local q = Pick(to, OPP[side - 2], p[1]); if q then out[q] = true end; return end
		out[0] = true
		return
	end
	if not to then if Step(d, map, i, j, di, dj) then out[0] = true end; return end
	local q = Pick(to, OPP[side - 2], ZH, R.inside)
	-- your height (known on the plain square) beats a missing step in the data: a floor right at your height,
	-- when the one the data allows is far off it (a corner of the floor too small for the 4-yd square)
	if ZH and not (q and abs(to[q][1] - ZH) <= 6) then
		local n = Pick(to, nil, ZH, R.inside)
		if n and abs(to[n][1] - ZH) <= 3 then q = n end
	end
	if q then out[q] = true end
end
local MID = {}
local function FStep2Into(d, map, i, j, k, di, dj, out)
	if di == 0 or dj == 0 then return FStepInto(d, map, i, j, k, di, dj, out) end
	-- a corner: round either side
	for q in pairs(MID) do MID[q] = nil end
	FStepInto(d, map, i, j, k, di, 0, MID)
	local a = {}
	for q in pairs(MID) do a[#a + 1] = q end
	for _, q in ipairs(a) do FStepInto(d, map, i + di, j, q, 0, dj, out) end
	for q in pairs(MID) do MID[q] = nil end
	FStepInto(d, map, i, j, k, 0, dj, MID)
	a = {}
	for q in pairs(MID) do a[#a + 1] = q end
	for _, q in ipairs(a) do FStepInto(d, map, i, j + dj, q, di, 0, out) end
end
-- one floor from a set: the one nearest height z (none: the lowest)
local function Nearest(map, i, j, set, z)
	local fl = Floors(map, i, j)
	local best, bk
	for q in pairs(set) do
		local e = (fl and fl[q] and z) and abs(fl[q][1] - z) or (fl and fl[q] and fl[q][1] * 0.001 or 0)
		if not best or e < best then best, bk = e, q end
	end
	return bk
end
local ONE = {}
-- (zh: the height to pick by, else this floor's own)
local function FStep2(d, map, i, j, k, di, dj, zh)
	for q in pairs(ONE) do ONE[q] = nil end
	FStep2Into(d, map, i, j, k, di, dj, ONE)
	local fl = k > 0 and Floors(map, i, j)
	return Nearest(map, i + di, j + dj, ONE, zh or (fl and fl[k] and fl[k][1]) or nil)
end

-- Which floor you are on (call it often: it follows you square by square). inside = IsIndoors(); z = a height hint
-- (the walking map's floor) or nil. Returns the floor index of your square (0 = a plain square).
local TF = {}
function R.TrackFloor(map, x, y, inside, z)
	local d = R.data[map]
	R.inside = inside
	if not d then return 0 end
	local c = d.cell
	local i, j = floor(x / c), floor(y / c)
	local fl = Floors(map, i, j)
	local k, tracked
	if TF.map == map and TF.i then
		local di, dj = i - TF.i, j - TF.j
		if di == 0 and dj == 0 then k, tracked = TF.k, true
		elseif abs(di) <= 8 and abs(dj) <= 8 then
			tracked = true
			-- square by square along the way you went
			local n = max(abs(di), abs(dj))
			-- where a square leads onto two floors (the foot of a stair: the floor under it and the steps), the one
			-- that carries on the way you were going (up or down the stairs)
			local li, lj, lk = TF.i, TF.j, TF.k
			for s = 1, n do
				local ni, nj = TF.i + floor(di * s / n + 0.5), TF.j + floor(dj * s / n + 0.5)
				local f0 = lk and lk > 0 and Floors(map, li, lj)
				local z0 = f0 and f0[lk] and f0[lk][1]
				if lk == 0 then z0 = TF.pz end
				ZH = lk == 0 and z0 and z0 + (TF.trend or 0) or nil
				lk = lk and FStep2(d, map, li, lj, lk, ni - li, nj - lj, z0 and z0 + (TF.trend or 0))
				ZH = nil
				local f1 = lk and lk > 0 and Floors(map, ni, nj)
				local z1 = f1 and f1[lk] and f1[lk][1]
				if lk == 0 then z1 = PlainAt(map, ni, nj, (z0 or TF.pz) and (z0 or TF.pz) + (TF.trend or 0)); TF.pz = z1 end
				if z0 and z1 and abs(z1 - z0) > 0.5 then TF.trend = max(-3, min(3, z1 - z0)) else TF.trend = (TF.trend or 0) * 0.5 end
				li, lj = ni, nj
			end
			k = lk
		end
	end
	if not fl then k = 0
	elseif not (k and k > 0 and fl[k]) then
		-- lost it (a jump, a lift, logging in here): one that matches indoors / outdoors, nearest the last floor you
		-- were on (or the hint), else the lowest. While it follows you step by step it trusts that over indoors /
		-- outdoors (a doorway or a stair top can be either)
		k = Pick(fl, nil, z or TF.z, inside)
		-- a height hint right at one of its floors beats the indoors / outdoors flag (Orgrimmar's streets are the
		-- town's "indoor" floors in the data, but outdoors in the game)
		-- (outdoors only the top floor of those: under the open sky, never a cave or a room under you, which a hint
		-- from the walking map near you can be: Un'Goro's caves under its ground)
		if z then
			local n = Pick(fl, nil, z, nil)
			if n and inside == false and fl[n][2] then
				for q = 1, #fl do if fl[q][1] > fl[n][1] then n = nil; break end end
			end
			if n and abs(fl[n][1] - z) <= 12 and not (k and abs(fl[k][1] - z) <= abs(fl[n][1] - z) + 8) then k = n end
		end
	end
	if TF.map ~= map then TF.pz = nil end
	if k == 0 and not tracked then TF.pz = PlainAt(map, i, j, z or TF.pz) end
	TF.map, TF.i, TF.j, TF.k = map, i, j, k
	TF.z = (fl and fl[k] and fl[k][1]) or (k == 0 and TF.pz) or nil
	return k
end
function R.FloorZ(map, x, y, k)
	local d = R.data[map]
	local fl = d and Floors(map, floor(x / d.cell), floor(y / d.cell))
	return fl and fl[k] and fl[k][1] or nil
end

-- R.Clear on floor k0 of a's square; with bz: b must be on a floor within 5 yd of that height
local function ClearF(map, ax, ay, bx, by, k0, bz, skip)
	local d = R.data[map]
	if not d then return true end
	skip = skip or 2
	local dx, dy = bx - ax, by - ay
	local len = sqrt(dx * dx + dy * dy)
	local c = d.cell
	local n = floor(len / 2) + 1
	local li, lj = floor(ax / c), floor(ay / c)
	local cur = { [k0 or 0] = true }
	for s = 1, n do
		local t = s / n
		local i, j = floor((ax + dx * t) / c), floor((ay + dy * t) / c)
		if i ~= li or j ~= lj then
			local di, dj = i - li, j - lj
			if abs(di) > 1 or abs(dj) > 1 then return false end
			local nxt = {}
			for k in pairs(cur) do FStep2Into(d, map, li, lj, k, di, dj, nxt) end
			if next(nxt) == nil then
				local at = t * len
				if at >= skip and len - at >= skip then return false end
				-- next to an end (you stand there, on the edge): from another floor of this square at about your
				-- height, else onto the floor of about the same height there; never onto a plain square no floor
				-- here steps onto
				local here, fl = Floors(map, li, lj), Floors(map, i, j)
				local kz
				for k in pairs(cur) do kz = kz or (here and here[k] and here[k][1]) end
				for q = 1, here and #here or 0 do
					if not cur[q] and (not kz or abs(here[q][1] - kz) <= 4) then FStep2Into(d, map, li, lj, q, di, dj, nxt) end
				end
				if next(nxt) == nil then
					if here and not fl then return false end
					if fl then
						local q = Pick(fl, nil, kz, R.inside)
						if kz and abs(fl[q][1] - kz) > 4 then return false end
						nxt[q] = true
					else nxt[0] = true end
				end
			end
			cur, li, lj = nxt, i, j
		end
	end
	if bz then
		local fl = Floors(map, li, lj)
		if not fl then return true end
		for k in pairs(cur) do
			if k == 0 or not fl[k] or abs(fl[k][1] - bz) <= 5 then return true end
		end
		return false
	end
	return true
end

-- R.Way on floors: from floor k0 at a to b (on a floor within 5 yd of bz, when given)
local function WayF(map, ax, ay, bx, by, k0, bz, margin, nowiden)
	local d = R.data[map]
	if not d then return nil end
	local c = d.cell
	margin = margin or 120
	local si, sj = floor(ax / c), floor(ay / c)
	local ti, tj = floor(bx / c), floor(by / c)
	-- a plain square at either end you can't walk out of (a rock, a post): the nearest open one, as R.Way
	if not Floors(map, si, sj) then si, sj = NearOpen(d, map, ax, ay, 16) end
	if not Floors(map, ti, tj) then ti, tj = NearOpen(d, map, bx, by, 16) end
	if not (si and ti) then return nil end
	-- no floor of the end square near the given height (a guess, off): any floor there (else a whole search for nothing)
	local tf = bz and Floors(map, ti, tj)
	if tf then
		local near = false
		for k = 1, #tf do if abs(tf[k][1] - bz) <= 5 then near = true; break end end
		if not near then bz = nil end
	end
	local i0, i1 = min(si, ti) - floor(margin / c), max(si, ti) + floor(margin / c)
	local j0, j1 = min(sj, tj) - floor(margin / c), max(sj, tj) + floor(margin / c)
	local W = j1 - j0 + 1
	if (i1 - i0 + 1) * W > 90000 then return nil end
	local function id(i, j, k) return ((i - i0) * W + (j - j0)) * 64 + k end
	local function hdist(i, j)
		local di, dj = abs(i - ti), abs(j - tj)
		return (di + dj) + (SQ2 - 2) * min(di, dj)
	end
	local function atEnd(i, j, k)
		if i ~= ti or j ~= tj then return false end
		if not bz or k == 0 then return true end
		local fl = Floors(map, i, j)
		return not (fl and fl[k]) or abs(fl[k][1] - bz) <= 5
	end
	local g, from, done, h = {}, {}, {}, {}
	local s = id(si, sj, k0 or 0)
	g[s] = 0
	hpush(h, hdist(si, sj), s)
	local t, n = nil, 0
	local nxt = {}
	while #h > 0 do
		local top = hpop(h)
		local u = top[2]
		if not done[u] then
			done[u] = true
			n = n + 1
			local cell, uk = floor(u / 64), u % 64
			local ui, uj = floor(cell / W) + i0, cell % W + j0
			if atEnd(ui, uj, uk) then t = u; break end
			if n > 40000 then break end
			if n % 32 == 0 then Pause() end
			local gu = g[u]
			for di = -1, 1 do
				for dj = -1, 1 do
					if di ~= 0 or dj ~= 0 then
						local vi, vj = ui + di, uj + dj
						if vi >= i0 and vi <= i1 and vj >= j0 and vj <= j1 then
							for q in pairs(nxt) do nxt[q] = nil end
							FStep2Into(d, map, ui, uj, uk, di, dj, nxt)
							local ng = gu + ((di == 0 or dj == 0) and 1 or SQ2) * (steepW and Steep(map, vi, vj) and 3 or 1)
							for vk in pairs(nxt) do
								local v = id(vi, vj, vk)
								if not done[v] and (not g[v] or ng < g[v]) then
									g[v], from[v] = ng, u
									hpush(h, ng + hdist(vi, vj), v)
								end
							end
						end
					end
				end
			end
		end
	end
	if not t then
		if margin < 300 and not nowiden then return WayF(map, ax, ay, bx, by, k0, bz, 300) end
		return nil
	end
	-- squares back to the start (with their floors), then keep only the corners you must go round
	local cells = {}
	local u = t
	while u do
		local cell = floor(u / 64)
		cells[#cells + 1] = { (floor(cell / W) + i0 + 0.5) * c, (cell % W + j0 + 0.5) * c, u % 64 }
		u = from[u]
	end
	local pts = { { ax, ay, k0 or 0 } }
	for q = #cells - 1, 1, -1 do pts[#pts + 1] = cells[q] end
	pts[#pts] = { bx, by, cells[1][3] }
	local out, i = {}, 1
	while i < #pts do
		Pause()
		local j = i + 1
		for q = #pts, i + 2, -1 do
			if ClearF(map, pts[i][1], pts[i][2], pts[q][1], pts[q][2], pts[i][3], R.FloorZ(map, pts[q][1], pts[q][2], pts[q][3]), i == 1 and 2 or 0) then j = q; break end
		end
		out[#out + 1] = { x = pts[j][1], y = pts[j][2], map = map, k = pts[j][3] }
		i = j
	end
	return out, g[t] * c
end

-- plain squares on the way use the indoor rows (no floors there; the outdoor rows also keep apart the parts of a
-- square on a slope, which shuts real steps near buildings)
-- (R.outF: you are outside, on a square with floors (a town on floors, a ledge): plain squares use the outdoor rows,
-- the indoor ones are a little more open and would let a run through a rock or a ruin wall outside)
function R.ClearF(...)
	local was = R.indoor
	R.indoor = not R.outF
	local ok = ClearF(...)
	R.indoor = was
	return ok
end
function R.WayF(...)
	local was = R.indoor
	R.indoor = not R.outF
	local w, len = WayF(...)
	R.indoor = was
	return w, len
end
